from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

styles = getSampleStyleSheet()
styles.add(ParagraphStyle("TitleX", parent=styles["Title"], alignment=TA_CENTER, fontSize=25, leading=31, textColor=colors.HexColor("#111827")))
styles.add(ParagraphStyle("SubX", parent=styles["BodyText"], alignment=TA_CENTER, fontSize=12, leading=16, textColor=colors.HexColor("#4B5563")))
styles.add(ParagraphStyle("H1X", parent=styles["Heading1"], fontSize=15, leading=19, textColor=colors.HexColor("#B91C1C"), spaceBefore=8, spaceAfter=6))
styles.add(ParagraphStyle("BodyX", parent=styles["BodyText"], fontSize=9.1, leading=12.5, textColor=colors.HexColor("#1F2937"), spaceAfter=4))
styles.add(ParagraphStyle("SmallX", parent=styles["BodyText"], fontSize=7.2, leading=9, textColor=colors.HexColor("#111827")))


def p(text, style="BodyX"):
    return Paragraph(text, styles[style])


def h(text):
    return Paragraph(text, styles["H1X"])


def tbl(rows, widths):
    t = Table([[p(str(c), "SmallX") for c in r] for r in rows], colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#FEE2E2")),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


story = []
story.append(Spacer(1, 3 * cm))
story.append(p("Flix First", "TitleX"))
story.append(p("Projet BDD - Application de streaming avec MySQL", "SubX"))
story.append(p("Schema relationnel + application Java Swing + MySQL Workbench", "SubX"))
story.append(Spacer(1, 1 * cm))
story.append(tbl([
    ["Element", "Choix"],
    ["SGBD", "MySQL"],
    ["Outil BD", "MySQL Workbench"],
    ["Application", "Java Swing"],
    ["Specialisation", "Contenu ISA Film / Serie"],
    ["Relations", "16 relations principales"],
], [5 * cm, 10 * cm]))
story.append(PageBreak())

story.append(h("1. Description de l'application"))
story.append(p("Flix First est une application de streaming video inspiree des plateformes de VOD. Elle permet de creer un compte, se connecter, consulter un catalogue de films et series, afficher les fiches contenus, voir les acteurs, realisateurs et producteurs, simuler le visionnage, gerer une liste personnelle et noter les contenus."))
story.append(p("Le projet reste d'abord un projet BDD : la base MySQL modelise les utilisateurs, profils, abonnements, contenus, films, series, saisons, episodes, genres, personnes, historiques et evaluations."))

story.append(h("2. Contraintes principales"))
for item in [
    "Deux utilisateurs ne peuvent pas avoir la meme adresse e-mail.",
    "Une formule d'abonnement possede un nom unique, un prix, une qualite maximale et un nombre d'ecrans.",
    "Un utilisateur peut avoir plusieurs abonnements dans le temps, mais au plus un abonnement actif.",
    "Chaque contenu est soit un film soit une serie.",
    "Un film possede une duree, un realisateur et un producteur.",
    "Une serie possede un createur et des saisons.",
    "Dans une meme serie, deux saisons ne peuvent pas avoir le meme numero.",
    "Dans une meme saison, deux episodes ne peuvent pas avoir le meme numero.",
    "Un contenu peut appartenir a plusieurs genres.",
    "Un contenu peut avoir plusieurs acteurs, realisateurs, producteurs ou createurs.",
    "Un historique de visionnage concerne un utilisateur et un contenu.",
    "La progression ne peut pas etre negative.",
    "Un utilisateur peut noter un contenu au maximum une fois.",
    "Une note est comprise entre 1 et 5.",
    "Un contenu ne peut pas etre ajoute deux fois a la meme liste personnelle.",
]:
    story.append(p("- " + item))

story.append(h("3. Entites, identifiants et DFs"))
story.append(tbl([
    ["Entite", "Attributs", "Identifiant", "DF induite"],
    ["Utilisateur", "id_utilisateur, email, mot_de_passe_hash, nom, prenom, date_inscription", "id_utilisateur", "id_utilisateur -> email, mot_de_passe_hash, nom, prenom, date_inscription"],
    ["Profil", "id_profil, pseudo, avatar, id_utilisateur", "id_profil", "id_profil -> pseudo, avatar, id_utilisateur"],
    ["FormuleAbonnement", "id_formule, nom, prix_mensuel, qualite_max, nb_ecrans_max", "id_formule", "id_formule -> nom, prix_mensuel, qualite_max, nb_ecrans_max"],
    ["Abonnement", "id_abonnement, id_utilisateur, id_formule, date_debut, date_fin, statut", "id_abonnement", "id_abonnement -> id_utilisateur, id_formule, date_debut, date_fin, statut"],
    ["Contenu", "id_contenu, titre, type_contenu, annee_sortie, classification_age, pays_origine, synopsis", "id_contenu", "id_contenu -> titre, type_contenu, annee_sortie, classification_age, pays_origine, synopsis"],
    ["Film", "id_contenu, duree_minutes, realisateur, producteur", "id_contenu", "id_contenu -> duree_minutes, realisateur, producteur"],
    ["Serie", "id_contenu, createur, nb_saisons", "id_contenu", "id_contenu -> createur, nb_saisons"],
    ["Saison", "id_saison, id_contenu, numero_saison, titre", "id_saison", "id_saison -> id_contenu, numero_saison, titre"],
    ["Episode", "id_episode, id_saison, numero_episode, titre, duree_minutes", "id_episode", "id_episode -> id_saison, numero_episode, titre, duree_minutes"],
    ["Genre", "id_genre, nom", "id_genre", "id_genre -> nom"],
    ["Personne", "id_personne, nom_complet, pays, date_naissance", "id_personne", "id_personne -> nom_complet, pays, date_naissance"],
], [2.9 * cm, 5.1 * cm, 2.5 * cm, 6 * cm]))

story.append(h("4. Specialisation ISA"))
story.append(p("Contenu est specialise en Film et Serie. La specialisation est disjointe : un contenu de type film est stocke dans Film, un contenu de type serie est stocke dans Serie. Les triggers MySQL verifient que Film reference uniquement les contenus de type film et que Serie reference uniquement les contenus de type serie."))

story.append(h("5. Schema relationnel final"))
story.append(tbl([
    ["Relation", "PK", "Contraintes principales"],
    ["Utilisateur", "id_utilisateur", "UNIQUE(email)"],
    ["Profil", "id_profil", "FK Utilisateur"],
    ["FormuleAbonnement", "id_formule", "UNIQUE(nom), CHECK prix/ecrans"],
    ["Abonnement", "id_abonnement", "FK Utilisateur, FK Formule, UNIQUE abonnement actif, triggers dates"],
    ["Contenu", "id_contenu", "ENUM type, age, pays, synopsis"],
    ["Film", "id_contenu", "FK Contenu, CHECK duree"],
    ["Serie", "id_contenu", "FK Contenu, CHECK nb_saisons"],
    ["Saison", "id_saison", "FK Serie, UNIQUE(id_contenu, numero_saison)"],
    ["Episode", "id_episode", "FK Saison, UNIQUE(id_saison, numero_episode)"],
    ["Genre", "id_genre", "UNIQUE(nom)"],
    ["ContenuGenre", "(id_contenu,id_genre)", "FK Contenu, FK Genre"],
    ["Personne", "id_personne", "Personnes du catalogue"],
    ["ContenuPersonne", "(id_contenu,id_personne,participation)", "N:M contenus/personnes"],
    ["HistoriqueVisionnage", "id_historique", "FK Utilisateur, FK Contenu, FK Episode"],
    ["Evaluation", "(id_utilisateur,id_contenu)", "CHECK note 1..5"],
    ["MaListe", "(id_utilisateur,id_contenu)", "liste personnelle sans doublon"],
], [4.7 * cm, 4.3 * cm, 7.3 * cm]))

story.append(h("6. Normalisation"))
story.append(p("Les relations finales sont en BCNF pour les dependances principales : chaque DF non triviale a pour determinant une cle ou super-cle. Les relations N:M ContenuGenre, ContenuPersonne et MaListe evitent les repetitions. HistoriqueVisionnage et Evaluation separent les interactions utilisateur/contenu du catalogue."))

story.append(h("7. Tracabilite finale"))
story.append(tbl([
    ["Contrainte", "Implementation", "Preservee"],
    ["Email unique", "UNIQUE Utilisateur.email", "Oui"],
    ["Formule unique", "UNIQUE FormuleAbonnement.nom", "Oui"],
    ["Un seul abonnement actif", "colonne generee id_utilisateur_actif + UNIQUE", "Oui"],
    ["Dates abonnement coherentes", "triggers INSERT/UPDATE date_fin >= date_debut", "Oui"],
    ["Contenu film ou serie", "ENUM + Film/Serie + triggers", "Oui"],
    ["Saisons numerotees par serie", "UNIQUE(id_contenu, numero_saison)", "Oui"],
    ["Episodes numerotes par saison", "UNIQUE(id_saison, numero_episode)", "Oui"],
    ["Genres N:M", "ContenuGenre", "Oui"],
    ["Acteurs/producteurs N:M", "ContenuPersonne", "Oui"],
    ["Personne multi-roles", "PK (id_contenu,id_personne,participation)", "Oui"],
    ["Progression non negative", "CHECK progression_minutes >= 0", "Oui"],
    ["Note 1 a 5", "CHECK(note BETWEEN 1 AND 5)", "Oui"],
    ["Une note par utilisateur/contenu", "PK Evaluation(id_utilisateur,id_contenu)", "Oui"],
    ["Ma liste sans doublon", "PK MaListe(id_utilisateur,id_contenu)", "Oui"],
], [5.2 * cm, 8.1 * cm, 2.3 * cm]))

story.append(h("8. Livrables"))
for item in ["src/", "sql/flix_first_mysql.sql", "sql/demo_queries_mysql.sql", "lib/mysql-connector-j-9.7.0.jar", "assets/flix_first_logo.svg", "README.txt", "video de presentation"]:
    story.append(p("- " + item))

doc = SimpleDocTemplate("RAPPORT_FlixFirst_MySQL.pdf", pagesize=A4, rightMargin=1.4 * cm, leftMargin=1.4 * cm, topMargin=1.3 * cm, bottomMargin=1.3 * cm)
doc.build(story)
