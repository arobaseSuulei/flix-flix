USE flix_first;

-- 1. Nombre de tuples par relation
SELECT 'Utilisateur' AS relation, COUNT(*) AS lignes FROM Utilisateur
UNION ALL SELECT 'Profil', COUNT(*) FROM Profil
UNION ALL SELECT 'FormuleAbonnement', COUNT(*) FROM FormuleAbonnement
UNION ALL SELECT 'Abonnement', COUNT(*) FROM Abonnement
UNION ALL SELECT 'Contenu', COUNT(*) FROM Contenu
UNION ALL SELECT 'Film', COUNT(*) FROM Film
UNION ALL SELECT 'Serie', COUNT(*) FROM Serie
UNION ALL SELECT 'Saison', COUNT(*) FROM Saison
UNION ALL SELECT 'Episode', COUNT(*) FROM Episode
UNION ALL SELECT 'Genre', COUNT(*) FROM Genre
UNION ALL SELECT 'ContenuGenre', COUNT(*) FROM ContenuGenre
UNION ALL SELECT 'Personne', COUNT(*) FROM Personne
UNION ALL SELECT 'ContenuPersonne', COUNT(*) FROM ContenuPersonne
UNION ALL SELECT 'HistoriqueVisionnage', COUNT(*) FROM HistoriqueVisionnage
UNION ALL SELECT 'Evaluation', COUNT(*) FROM Evaluation
UNION ALL SELECT 'MaListe', COUNT(*) FROM MaListe
ORDER BY relation;

-- 2. Catalogue detaille avec genres et notes
SELECT c.titre, c.type_contenu, c.annee_sortie,
       GROUP_CONCAT(DISTINCT g.nom ORDER BY g.nom SEPARATOR ', ') AS genres,
       COALESCE(ROUND(AVG(e.note), 1), 'Non note') AS note_moyenne
FROM Contenu c
LEFT JOIN ContenuGenre cg ON cg.id_contenu = c.id_contenu
LEFT JOIN Genre g ON g.id_genre = cg.id_genre
LEFT JOIN Evaluation e ON e.id_contenu = c.id_contenu
GROUP BY c.id_contenu, c.titre, c.type_contenu, c.annee_sortie
ORDER BY c.type_contenu, c.titre;

-- 3. Films avec leur duree et leur realisateur
SELECT c.titre, c.annee_sortie, f.duree_minutes, f.realisateur, f.producteur
FROM Contenu c
JOIN Film f ON f.id_contenu = c.id_contenu
ORDER BY c.titre;

-- 4. Series avec saisons et episodes
SELECT c.titre AS serie, s.numero_saison, e.numero_episode,
       e.titre AS episode, e.duree_minutes
FROM Contenu c
JOIN Serie se ON se.id_contenu = c.id_contenu
JOIN Saison s ON s.id_contenu = se.id_contenu
JOIN Episode e ON e.id_saison = s.id_saison
ORDER BY c.titre, s.numero_saison, e.numero_episode;

-- 5. Controle simple de la specialisation : contenus de type film
SELECT c.id_contenu, c.titre, c.type_contenu, f.duree_minutes
FROM Contenu c
JOIN Film f ON f.id_contenu = c.id_contenu
WHERE c.type_contenu = 'film'
ORDER BY c.id_contenu;

-- 6. Controle simple de la specialisation : contenus de type serie
SELECT c.id_contenu, c.titre, c.type_contenu, se.nb_saisons
FROM Contenu c
JOIN Serie se ON se.id_contenu = c.id_contenu
WHERE c.type_contenu = 'serie'
ORDER BY c.id_contenu;

-- 7. Casting : seulement les acteurs, avec le role joue
SELECT c.titre, p.nom_complet, cp.role_personnage
FROM ContenuPersonne cp
JOIN Contenu c ON c.id_contenu = cp.id_contenu
JOIN Personne p ON p.id_personne = cp.id_personne
WHERE cp.participation = 'acteur'
ORDER BY c.titre, p.nom_complet;

-- 8. Realisateurs
SELECT c.titre, p.nom_complet AS realisateur
FROM ContenuPersonne cp
JOIN Contenu c ON c.id_contenu = cp.id_contenu
JOIN Personne p ON p.id_personne = cp.id_personne
WHERE cp.participation = 'realisateur'
ORDER BY c.titre, p.nom_complet;

-- 9. Producteurs
SELECT c.titre, p.nom_complet AS producteur
FROM ContenuPersonne cp
JOIN Contenu c ON c.id_contenu = cp.id_contenu
JOIN Personne p ON p.id_personne = cp.id_personne
WHERE cp.participation = 'producteur'
ORDER BY c.titre, p.nom_complet;

-- 10. Exemple : une personne peut etre acteur et realisateur
SELECT c.titre, p.nom_complet, cp.participation, cp.role_personnage
FROM ContenuPersonne cp
JOIN Contenu c ON c.id_contenu = cp.id_contenu
JOIN Personne p ON p.id_personne = cp.id_personne
WHERE p.nom_complet = 'Dany Boon'
ORDER BY c.titre, cp.participation;

-- 11. Historique des films
SELECT u.email, c.titre AS film, h.date_visionnage,
       h.progression_minutes, h.termine
FROM HistoriqueVisionnage h
JOIN Utilisateur u ON u.id_utilisateur = h.id_utilisateur
JOIN Contenu c ON c.id_contenu = h.id_contenu
JOIN Film f ON f.id_contenu = c.id_contenu
ORDER BY h.date_visionnage DESC;

-- 12. Historique des series avec episodes
SELECT u.email, c.titre AS serie, e.titre AS episode,
       h.date_visionnage, h.progression_minutes, h.termine
FROM HistoriqueVisionnage h
JOIN Utilisateur u ON u.id_utilisateur = h.id_utilisateur
JOIN Contenu c ON c.id_contenu = h.id_contenu
JOIN Serie se ON se.id_contenu = c.id_contenu
JOIN Episode e ON e.id_episode = h.id_episode
ORDER BY h.date_visionnage DESC;
