USE flix_first;

-- 1. Nombre de tuples par relation
SELECT 'Utilisateur' AS relation, COUNT(*) AS lignes FROM Utilisateur
UNION ALL SELECT 'FormuleAbonnement', COUNT(*) FROM FormuleAbonnement
UNION ALL SELECT 'Abonnement', COUNT(*) FROM Abonnement
UNION ALL SELECT 'Contenu', COUNT(*) FROM Contenu
UNION ALL SELECT 'Film', COUNT(*) FROM Film
UNION ALL SELECT 'Serie', COUNT(*) FROM Serie
UNION ALL SELECT 'Saison', COUNT(*) FROM Saison
UNION ALL SELECT 'Episode', COUNT(*) FROM Episode
UNION ALL SELECT 'Genre', COUNT(*) FROM Genre
UNION ALL SELECT 'ContenuGenre', COUNT(*) FROM ContenuGenre
UNION ALL SELECT 'Personne', COUNT(*) FROM Personne
UNION ALL SELECT 'ContenuPersonne', COUNT(*) FROM ContenuPersonne
UNION ALL SELECT 'HistoriqueVisionnage', COUNT(*) FROM HistoriqueVisionnage
UNION ALL SELECT 'Evaluation', COUNT(*) FROM Evaluation
UNION ALL SELECT 'MaListe', COUNT(*) FROM MaListe
ORDER BY relation;

-- 2. Catalogue detaille
SELECT c.titre, c.type_contenu, c.annee_sortie,
       COALESCE(GROUP_CONCAT(DISTINCT g.nom ORDER BY g.nom SEPARATOR ', '), '-') AS genres,
       COALESCE(CONCAT(f.duree_minutes, ' min'), s.createur) AS duree_ou_createur,
       COALESCE(ROUND(AVG(e.note), 1), '-') AS note_moyenne
FROM Contenu c
LEFT JOIN Film f ON f.id_contenu = c.id_contenu
LEFT JOIN Serie s ON s.id_contenu = c.id_contenu
LEFT JOIN ContenuGenre cg ON cg.id_contenu = c.id_contenu
LEFT JOIN Genre g ON g.id_genre = cg.id_genre
LEFT JOIN Evaluation e ON e.id_contenu = c.id_contenu
GROUP BY c.id_contenu
ORDER BY c.type_contenu, c.titre;

-- 3. Controle de la specialisation Film / Serie
SELECT c.id_contenu, c.titre, c.type_contenu,
       CASE WHEN f.id_contenu IS NULL THEN 0 ELSE 1 END AS ligne_film,
       CASE WHEN s.id_contenu IS NULL THEN 0 ELSE 1 END AS ligne_serie
FROM Contenu c
LEFT JOIN Film f ON f.id_contenu = c.id_contenu
LEFT JOIN Serie s ON s.id_contenu = c.id_contenu
ORDER BY c.id_contenu;

-- 4. Casting, realisateurs et producteurs
SELECT c.titre, p.nom_complet, cp.participation, COALESCE(cp.role_personnage, '-') AS role_personnage
FROM ContenuPersonne cp
JOIN Contenu c ON c.id_contenu = cp.id_contenu
JOIN Personne p ON p.id_personne = cp.id_personne
ORDER BY c.titre, cp.participation, p.nom_complet;

-- 5. Historique utilisateur
SELECT u.email, c.titre, COALESCE(e.titre, '-') AS episode,
       h.date_visionnage, h.progression_minutes, h.termine
FROM HistoriqueVisionnage h
JOIN Utilisateur u ON u.id_utilisateur = h.id_utilisateur
JOIN Contenu c ON c.id_contenu = h.id_contenu
LEFT JOIN Episode e ON e.id_episode = h.id_episode
ORDER BY h.date_visionnage DESC;
