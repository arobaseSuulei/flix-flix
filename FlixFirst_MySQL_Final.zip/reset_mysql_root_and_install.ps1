$ErrorActionPreference = "Stop"

$newPassword = "FlixFirst123!"
$serviceName = "MySQL80"
$mysqlBin = "C:\Program Files\MySQL\MySQL Server 8.0\bin"
$mysqld = Join-Path $mysqlBin "mysqld.exe"
$mysql = Join-Path $mysqlBin "mysql.exe"
$mysqladmin = Join-Path $mysqlBin "mysqladmin.exe"
$myIni = "C:\ProgramData\MySQL\MySQL Server 8.0\my.ini"
$projectDir = "C:\Users\Lenovo\Downloads\FlixFirst_MySQL_Final"
$sqlScript = Join-Path $projectDir "sql\flix_first_mysql.sql"
$initFile = Join-Path $projectDir "mysql-init-reset.sql"
$logFile = Join-Path $projectDir "reset_mysql_log.txt"

Start-Transcript -Path $logFile -Force | Out-Null

if (!(Test-Path $mysqld)) { throw "mysqld.exe introuvable : $mysqld" }
if (!(Test-Path $mysql)) { throw "mysql.exe introuvable : $mysql" }
if (!(Test-Path $mysqladmin)) { throw "mysqladmin.exe introuvable : $mysqladmin" }
if (!(Test-Path $myIni)) { throw "my.ini introuvable : $myIni" }
if (!(Test-Path $sqlScript)) { throw "Script SQL introuvable : $sqlScript" }

Set-Content -LiteralPath $initFile -Encoding ASCII -Value @"
ALTER USER 'root'@'localhost' IDENTIFIED BY '$newPassword';
FLUSH PRIVILEGES;
"@

Write-Host "Arret du service MySQL..."
Stop-Service -Name $serviceName -Force
Start-Sleep -Seconds 4

$proc = $null
try {
    Write-Host "Demarrage temporaire de MySQL avec init-file..."
    $proc = Start-Process -FilePath $mysqld `
        -ArgumentList @("--defaults-file=`"$myIni`"", "--init-file=`"$initFile`"", "--console") `
        -PassThru `
        -WindowStyle Hidden

    Start-Sleep -Seconds 15

    Write-Host "Arret propre du serveur temporaire..."
    try {
        & $mysqladmin -uroot "-p$newPassword" shutdown
    } catch {
        if ($proc -and -not $proc.HasExited) {
            Stop-Process -Id $proc.Id -Force
        }
    }
    Start-Sleep -Seconds 5
}
finally {
    if ($proc -and -not $proc.HasExited) {
        Stop-Process -Id $proc.Id -Force
    }
    Write-Host "Redemarrage du service MySQL..."
    Start-Service -Name $serviceName
    Start-Sleep -Seconds 8
    Remove-Item -LiteralPath $initFile -Force -ErrorAction SilentlyContinue
}

Write-Host "Verification du nouveau mot de passe..."
& $mysql -uroot "-p$newPassword" -e "SELECT VERSION() AS mysql_version;"

Write-Host "Creation de la base Flix First..."
$mysqlScript = $sqlScript.Replace("\", "/")
& $mysql -uroot "-p$newPassword" -e "source $mysqlScript"

Write-Host "Verification de la base..."
& $mysql -uroot "-p$newPassword" -e "USE flix_first; SELECT COUNT(*) AS contenus FROM Contenu; SELECT COUNT(*) AS utilisateurs FROM Utilisateur;"

Write-Host ""
Write-Host "TERMINE."
Write-Host "Mot de passe MySQL root pour le projet : $newPassword"
Stop-Transcript | Out-Null
