DROP DATABASE IF EXISTS flix_first;
CREATE DATABASE flix_first
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE flix_first;

CREATE TABLE Utilisateur (
    id_utilisateur INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    mot_de_passe_hash CHAR(64) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    date_inscription DATE NOT NULL
);

CREATE TABLE FormuleAbonnement (
    id_formule INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(80) NOT NULL UNIQUE,
    prix_mensuel DECIMAL(6,2) NOT NULL CHECK (prix_mensuel >= 0),
    qualite_max ENUM('SD', 'HD', '4K') NOT NULL,
    nb_ecrans_max INT NOT NULL CHECK (nb_ecrans_max BETWEEN 1 AND 5)
);

CREATE TABLE Abonnement (
    id_abonnement INT AUTO_INCREMENT PRIMARY KEY,
    id_utilisateur INT NOT NULL,
    id_formule INT NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE NULL,
    statut ENUM('actif', 'expire', 'annule') NOT NULL,
    id_utilisateur_actif INT GENERATED ALWAYS AS (
        CASE WHEN statut = 'actif' THEN id_utilisateur ELSE NULL END
    ) STORED,
    UNIQUE KEY uq_un_abonnement_actif (id_utilisateur_actif),
    CONSTRAINT fk_abonnement_utilisateur
        FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
        ON DELETE RESTRICT,
    CONSTRAINT fk_abonnement_formule
        FOREIGN KEY (id_formule) REFERENCES FormuleAbonnement(id_formule)
);

DELIMITER $$

CREATE TRIGGER trg_abonnement_bi_dates
BEFORE INSERT ON Abonnement
FOR EACH ROW
BEGIN
    IF NEW.date_fin IS NOT NULL AND NEW.date_fin < NEW.date_debut THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'date_fin doit etre superieure ou egale a date_debut';
    END IF;
END$$

CREATE TRIGGER trg_abonnement_bu_dates
BEFORE UPDATE ON Abonnement
FOR EACH ROW
BEGIN
    IF NEW.date_fin IS NOT NULL AND NEW.date_fin < NEW.date_debut THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'date_fin doit etre superieure ou egale a date_debut';
    END IF;
END$$

DELIMITER ;

CREATE TABLE Contenu (
    id_contenu INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255) NOT NULL,
    type_contenu ENUM('film', 'serie') NOT NULL,
    annee_sortie INT NOT NULL CHECK (annee_sortie BETWEEN 1888 AND 2100),
    classification_age ENUM('Tout', '7+', '10+', '12+', '16+', '18+') NOT NULL,
    pays_origine VARCHAR(120) NOT NULL,
    synopsis TEXT NOT NULL,
    couleur_affiche VARCHAR(7) NOT NULL DEFAULT '#E50914',
    bande_annonce_url VARCHAR(512) DEFAULT NULL
);

CREATE TABLE Profil (
    id_profil INT AUTO_INCREMENT PRIMARY KEY,
    pseudo VARCHAR(80) NOT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    id_utilisateur INT NOT NULL,
    CONSTRAINT fk_profil_utilisateur
        FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
        ON DELETE CASCADE
);

CREATE TABLE Film (
    id_contenu INT PRIMARY KEY,
    duree_minutes INT NOT NULL CHECK (duree_minutes > 0),
    realisateur VARCHAR(160) NOT NULL,
    producteur VARCHAR(160) NOT NULL,
    CONSTRAINT fk_film_contenu
        FOREIGN KEY (id_contenu) REFERENCES Contenu(id_contenu)
        ON DELETE CASCADE
);

CREATE TABLE Serie (
    id_contenu INT PRIMARY KEY,
    createur VARCHAR(160) NOT NULL,
    nb_saisons INT NOT NULL CHECK (nb_saisons > 0),
    CONSTRAINT fk_serie_contenu
        FOREIGN KEY (id_contenu) REFERENCES Contenu(id_contenu)
        ON DELETE CASCADE
);

CREATE TABLE Saison (
    id_saison INT AUTO_INCREMENT PRIMARY KEY,
    id_contenu INT NOT NULL,
    numero_saison INT NOT NULL CHECK (numero_saison > 0),
    titre VARCHAR(255),
    UNIQUE KEY uq_saison_serie_numero (id_contenu, numero_saison),
    CONSTRAINT fk_saison_serie
        FOREIGN KEY (id_contenu) REFERENCES Serie(id_contenu)
        ON DELETE CASCADE
);

CREATE TABLE Episode (
    id_episode INT AUTO_INCREMENT PRIMARY KEY,
    id_saison INT NOT NULL,
    numero_episode INT NOT NULL CHECK (numero_episode > 0),
    titre VARCHAR(255) NOT NULL,
    duree_minutes INT NOT NULL CHECK (duree_minutes > 0),
    UNIQUE KEY uq_episode_saison_numero (id_saison, numero_episode),
    CONSTRAINT fk_episode_saison
        FOREIGN KEY (id_saison) REFERENCES Saison(id_saison)
        ON DELETE CASCADE
);

CREATE TABLE Genre (
    id_genre INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE ContenuGenre (
    id_contenu INT NOT NULL,
    id_genre INT NOT NULL,
    PRIMARY KEY (id_contenu, id_genre),
    CONSTRAINT fk_contenu_genre_contenu
        FOREIGN KEY (id_contenu) REFERENCES Contenu(id_contenu)
        ON DELETE CASCADE,
    CONSTRAINT fk_contenu_genre_genre
        FOREIGN KEY (id_genre) REFERENCES Genre(id_genre)
        ON DELETE CASCADE
);

CREATE TABLE Personne (
    id_personne INT AUTO_INCREMENT PRIMARY KEY,
    nom_complet VARCHAR(180) NOT NULL,
    pays VARCHAR(120),
    date_naissance DATE NULL
);

CREATE TABLE ContenuPersonne (
    id_contenu INT NOT NULL,
    id_personne INT NOT NULL,
    participation ENUM('acteur', 'realisateur', 'producteur', 'createur') NOT NULL,
    role_personnage VARCHAR(160),
    PRIMARY KEY (id_contenu, id_personne, participation),
    CONSTRAINT fk_contenu_personne_contenu
        FOREIGN KEY (id_contenu) REFERENCES Contenu(id_contenu)
        ON DELETE CASCADE,
    CONSTRAINT fk_contenu_personne_personne
        FOREIGN KEY (id_personne) REFERENCES Personne(id_personne)
        ON DELETE CASCADE
);

CREATE TABLE HistoriqueVisionnage (
    id_historique INT AUTO_INCREMENT PRIMARY KEY,
    id_utilisateur INT NOT NULL,
    id_contenu INT NOT NULL,
    id_episode INT NULL,
    date_visionnage DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    progression_minutes INT NOT NULL DEFAULT 0 CHECK (progression_minutes >= 0),
    termine BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_historique_utilisateur
        FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
        ON DELETE CASCADE,
    CONSTRAINT fk_historique_contenu
        FOREIGN KEY (id_contenu) REFERENCES Contenu(id_contenu)
        ON DELETE CASCADE,
    CONSTRAINT fk_historique_episode
        FOREIGN KEY (id_episode) REFERENCES Episode(id_episode)
        ON DELETE SET NULL
);

CREATE TABLE Evaluation (
    id_utilisateur INT NOT NULL,
    id_contenu INT NOT NULL,
    note INT NOT NULL CHECK (note BETWEEN 1 AND 5),
    date_evaluation DATE NOT NULL,
    PRIMARY KEY (id_utilisateur, id_contenu),
    CONSTRAINT fk_evaluation_utilisateur
        FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
        ON DELETE CASCADE,
    CONSTRAINT fk_evaluation_contenu
        FOREIGN KEY (id_contenu) REFERENCES Contenu(id_contenu)
        ON DELETE CASCADE
);

CREATE TABLE MaListe (
    id_utilisateur INT NOT NULL,
    id_contenu INT NOT NULL,
    date_ajout DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_utilisateur, id_contenu),
    CONSTRAINT fk_maliste_utilisateur
        FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
        ON DELETE CASCADE,
    CONSTRAINT fk_maliste_contenu
        FOREIGN KEY (id_contenu) REFERENCES Contenu(id_contenu)
        ON DELETE CASCADE
);

DELIMITER //

CREATE TRIGGER trg_film_type_insert
BEFORE INSERT ON Film
FOR EACH ROW
BEGIN
    IF (SELECT type_contenu FROM Contenu WHERE id_contenu = NEW.id_contenu) <> 'film' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un Film doit referencer un contenu de type film';
    END IF;
END//

CREATE TRIGGER trg_serie_type_insert
BEFORE INSERT ON Serie
FOR EACH ROW
BEGIN
    IF (SELECT type_contenu FROM Contenu WHERE id_contenu = NEW.id_contenu) <> 'serie' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Une Serie doit referencer un contenu de type serie';
    END IF;
END//

DELIMITER ;

INSERT INTO Utilisateur (email, mot_de_passe_hash, nom, prenom, date_inscription) VALUES
('demo@flixfirst.com', 'd3ad9315b7be5dd53b31a273b3b3aba5defe700808305aa16a3062b76658a791', 'Demo', 'Flix', '2026-05-01'),
('alice@mail.com', 'd3ad9315b7be5dd53b31a273b3b3aba5defe700808305aa16a3062b76658a791', 'Dupont', 'Alice', '2026-05-03'),
('omar@mail.com', 'd3ad9315b7be5dd53b31a273b3b3aba5defe700808305aa16a3062b76658a791', 'Bensaid', 'Omar', '2026-05-05'),
('emma@mail.com', 'd3ad9315b7be5dd53b31a273b3b3aba5defe700808305aa16a3062b76658a791', 'Moreau', 'Emma', '2026-05-07'),
('leo@mail.com', 'd3ad9315b7be5dd53b31a273b3b3aba5defe700808305aa16a3062b76658a791', 'Nguyen', 'Leo', '2026-05-10');

INSERT INTO FormuleAbonnement (nom, prix_mensuel, qualite_max, nb_ecrans_max) VALUES
('Starter', 5.99, 'SD', 1),
('Essential', 9.99, 'HD', 2),
('Premium', 15.99, '4K', 4),
('Family', 19.99, '4K', 5),
('Student', 4.99, 'HD', 1);

INSERT INTO Abonnement (id_utilisateur, id_formule, date_debut, date_fin, statut) VALUES
(1, 3, '2026-05-01', NULL, 'actif'),
(2, 2, '2026-05-03', NULL, 'actif'),
(3, 1, '2026-05-05', NULL, 'actif'),
(4, 4, '2026-05-07', NULL, 'actif'),
(5, 5, '2026-05-10', NULL, 'actif');

INSERT INTO Profil (pseudo, avatar, id_utilisateur) VALUES
('Demo Principal', NULL, 1),
('Demo Enfant', NULL, 1),
('Alice Main', NULL, 2),
('Omar Main', NULL, 3);

INSERT INTO Contenu (titre, type_contenu, annee_sortie, classification_age, pays_origine, synopsis, couleur_affiche) VALUES
('Inception', 'film', 2010, '12+', 'Etats-Unis', 'Un voleur specialise dans l extraction de secrets infiltre les reves et tente une mission impossible : implanter une idee.', '#E50914'),
('Interstellar', 'film', 2014, '10+', 'Etats-Unis', 'Une equipe traverse un trou de ver pour trouver une nouvelle planete habitable et sauver l humanite.', '#2563EB'),
('Intouchables', 'film', 2011, 'Tout', 'France', 'Une amitie inattendue nait entre un aristocrate tetraplegique et son auxiliaire de vie.', '#16A34A'),
('Dune', 'film', 2021, '12+', 'Etats-Unis', 'Paul Atreides decouvre Arrakis, une planete desertique au centre d enjeux politiques et mystiques.', '#D97706'),
('Parasite', 'film', 2019, '16+', 'Coree du Sud', 'Deux familles opposees se rencontrent dans une satire sociale tendue et brillante.', '#7C3AED'),
('Stranger Things', 'serie', 2016, '12+', 'Etats-Unis', 'Une bande d amis affronte des forces surnaturelles dans une ville americaine apparemment calme.', '#DC2626'),
('Lupin', 'serie', 2021, '12+', 'France', 'Assane Diop s inspire d Arsene Lupin pour venger son pere et defier les puissants.', '#0891B2'),
('Dark', 'serie', 2017, '16+', 'Allemagne', 'Des disparitions revelent une boucle temporelle complexe qui lie plusieurs familles.', '#4B5563'),
('Arcane', 'serie', 2021, '12+', 'Etats-Unis', 'Deux soeurs se retrouvent au coeur d une cite dechiree entre magie, technologie et pouvoir.', '#9333EA'),
('The Crown', 'serie', 2016, '12+', 'Royaume-Uni', 'Les tensions politiques et intimes de la monarchie britannique au fil des decennies.', '#B45309');

INSERT INTO Film (id_contenu, duree_minutes, realisateur, producteur) VALUES
(1, 148, 'Christopher Nolan', 'Emma Thomas'),
(2, 169, 'Christopher Nolan', 'Lynda Obst'),
(3, 112, 'Olivier Nakache et Eric Toledano', 'Nicolas Duval-Adassovsky'),
(4, 155, 'Denis Villeneuve', 'Mary Parent'),
(5, 132, 'Bong Joon-ho', 'Kwak Sin-ae');

INSERT INTO Serie (id_contenu, createur, nb_saisons) VALUES
(6, 'Matt Duffer et Ross Duffer', 4),
(7, 'George Kay', 3),
(8, 'Baran bo Odar et Jantje Friese', 3),
(9, 'Christian Linke et Alex Yee', 2),
(10, 'Peter Morgan', 6);

INSERT INTO Saison (id_contenu, numero_saison, titre) VALUES
(6, 1, 'Hawkins'),
(6, 2, 'Le portail'),
(7, 1, 'Assane Diop'),
(8, 1, 'Secrets'),
(9, 1, 'Piltover et Zaun'),
(10, 1, 'Le debut du regne');

INSERT INTO Episode (id_saison, numero_episode, titre, duree_minutes) VALUES
(1, 1, 'La disparition de Will Byers', 48),
(1, 2, 'La barjo de Maple Street', 55),
(2, 1, 'MADMAX', 48),
(3, 1, 'Chapitre 1', 47),
(4, 1, 'Secrets', 51),
(5, 1, 'Bienvenue au terrain de jeu', 43),
(6, 1, 'Wolferton Splash', 57);

INSERT INTO Genre (nom) VALUES
('Action'), ('Science-fiction'), ('Drame'), ('Comedie'), ('Thriller'), ('Fantastique'), ('Historique');

INSERT INTO ContenuGenre (id_contenu, id_genre) VALUES
(1, 1), (1, 2), (1, 5),
(2, 2), (2, 3),
(3, 3), (3, 4),
(4, 1), (4, 2),
(5, 3), (5, 5),
(6, 2), (6, 6),
(7, 1), (7, 5),
(8, 2), (8, 5),
(9, 1), (9, 6),
(10, 3), (10, 7);

INSERT INTO Personne (nom_complet, pays, date_naissance) VALUES
('Leonardo DiCaprio', 'Etats-Unis', '1974-11-11'),
('Joseph Gordon-Levitt', 'Etats-Unis', '1981-02-17'),
('Matthew McConaughey', 'Etats-Unis', '1969-11-04'),
('Anne Hathaway', 'Etats-Unis', '1982-11-12'),
('Omar Sy', 'France', '1978-01-20'),
('Francois Cluzet', 'France', '1955-09-21'),
('Timothee Chalamet', 'Etats-Unis', '1995-12-27'),
('Zendaya', 'Etats-Unis', '1996-09-01'),
('Song Kang-ho', 'Coree du Sud', '1967-01-17'),
('Millie Bobby Brown', 'Royaume-Uni', '2004-02-19'),
('Finn Wolfhard', 'Canada', '2002-12-23'),
('Omar Sy', 'France', '1978-01-20'),
('Louis Hofmann', 'Allemagne', '1997-06-03'),
('Hailee Steinfeld', 'Etats-Unis', '1996-12-11'),
('Claire Foy', 'Royaume-Uni', '1984-04-16'),
('Christopher Nolan', 'Royaume-Uni', '1970-07-30'),
('Denis Villeneuve', 'Canada', '1967-10-03'),
('Bong Joon-ho', 'Coree du Sud', '1969-09-14'),
('Emma Thomas', 'Royaume-Uni', '1971-12-09'),
('Mary Parent', 'Etats-Unis', NULL);

INSERT INTO ContenuPersonne (id_contenu, id_personne, participation, role_personnage) VALUES
(1, 1, 'acteur', 'Dom Cobb'),
(1, 2, 'acteur', 'Arthur'),
(1, 16, 'realisateur', NULL),
(1, 19, 'producteur', NULL),
(2, 3, 'acteur', 'Cooper'),
(2, 4, 'acteur', 'Brand'),
(2, 16, 'realisateur', NULL),
(3, 5, 'acteur', 'Driss'),
(3, 6, 'acteur', 'Philippe'),
(4, 7, 'acteur', 'Paul Atreides'),
(4, 8, 'acteur', 'Chani'),
(4, 17, 'realisateur', NULL),
(4, 20, 'producteur', NULL),
(5, 9, 'acteur', 'Kim Ki-taek'),
(5, 18, 'realisateur', NULL),
(6, 10, 'acteur', 'Eleven'),
(6, 11, 'acteur', 'Mike Wheeler'),
(7, 12, 'acteur', 'Assane Diop'),
(8, 13, 'acteur', 'Jonas Kahnwald'),
(9, 14, 'acteur', 'Vi'),
(10, 15, 'acteur', 'Queen Elizabeth II');

INSERT INTO HistoriqueVisionnage (id_utilisateur, id_contenu, id_episode, date_visionnage, progression_minutes, termine) VALUES
(1, 1, NULL, '2026-05-19 20:30:00', 148, TRUE),
(1, 6, 1, '2026-05-20 21:00:00', 32, FALSE),
(2, 3, NULL, '2026-05-20 18:45:00', 112, TRUE),
(3, 4, NULL, '2026-05-21 22:10:00', 70, FALSE),
(4, 9, 6, '2026-05-22 20:00:00', 43, TRUE);

INSERT INTO Evaluation (id_utilisateur, id_contenu, note, date_evaluation) VALUES
(1, 1, 5, '2026-05-20'),
(2, 3, 5, '2026-05-21'),
(3, 4, 4, '2026-05-22'),
(4, 9, 5, '2026-05-23'),
(5, 5, 4, '2026-05-23');

INSERT INTO MaListe (id_utilisateur, id_contenu) VALUES
(1, 2), (1, 7), (2, 1), (3, 8), (4, 10);

SELECT 'Flix First schema loaded' AS status;
