@echo off
cd /d "%~dp0"

echo Compilation de Flix First...
javac -encoding UTF-8 -d bin src\flixfirst\FlixFirstApp.java
if errorlevel 1 (
    echo.
    echo La compilation a echoue. Verifie que Java est installe et disponible dans le PATH.
    pause
    exit /b 1
)

echo.
echo Lancement de Flix First...
java -cp "bin;lib\mysql-connector-j-9.7.0.jar" flixfirst.FlixFirstApp

echo.
pause
