@echo off
set "PROJECT_DIR=%~dp0"

if not exist "%PROJECT_DIR%src\flixfirst\FlixFirstApp.java" (
    set "PROJECT_DIR=C:\Users\Lenovo\Downloads\FlixFirst_MySQL_Final\"
)

if not exist "%PROJECT_DIR%src\flixfirst\FlixFirstApp.java" (
    echo Impossible de trouver le projet Flix First.
    echo Verifie que le dossier complet FlixFirst_MySQL_Final existe dans Downloads.
    echo Chemin attendu : C:\Users\Lenovo\Downloads\FlixFirst_MySQL_Final
    pause
    exit /b 1
)

cd /d "%PROJECT_DIR%"

if not exist bin mkdir bin

echo Compilation de Flix First...
javac -encoding UTF-8 -d bin src\flixfirst\FlixFirstApp.java
if errorlevel 1 (
    echo.
    echo La compilation a echoue. Verifie que Java est installe et disponible dans le PATH.
    pause
    exit /b 1
)

echo.
echo Lancement de Flix First...
java -cp "bin;lib\mysql-connector-j-9.7.0.jar" flixfirst.FlixFirstApp

echo.
pause
