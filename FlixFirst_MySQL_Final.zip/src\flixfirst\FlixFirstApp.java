package flixfirst;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.CardLayout;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;
import java.nio.file.Files;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class FlixFirstApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AppFrame().setVisible(true));
    }
}

class AppFrame extends JFrame {
    // Updated, cleaner palette for a modern professional look
    private static final Color BG = new Color(18, 24, 32);
    private static final Color PANEL = new Color(26, 32, 40);
    private static final Color PANEL_2 = new Color(36, 44, 54);
    private static final Color PANEL_3 = new Color(42, 50, 62);
    private static final Color INPUT_BG = new Color(28, 34, 44);
    private static final Color BORDER = new Color(64, 75, 92);
    private static final Color TEXT = new Color(235, 238, 242);
    private static final Color MUTED = new Color(142, 152, 170);
    private static final Color RED = new Color(220, 38, 56);
    private static final Color RED_HOVER = new Color(235, 64, 82);
    private static final Color GOLD = new Color(238, 170, 39);
    private static final Color TEAL = new Color(20, 184, 166);

    private final CardLayout rootCards = new CardLayout();
    private final JPanel root = new JPanel(rootCards);
    private final CardLayout appCards = new CardLayout();
    private final JPanel appPages = new JPanel(appCards);
    private final JLabel status = new JLabel("Flix First");

    private JTextField hostField;
    private JTextField portField;
    private JTextField dbField;
    private JTextField dbUserField;
    private JPasswordField dbPasswordField;

    private JTextField loginEmailField;
    private JPasswordField loginPasswordField;
    private JTextField regFirstNameField;
    private JTextField regLastNameField;
    private JTextField regEmailField;
    private JPasswordField regPasswordField;
    private JComboBox<IdLabel> regPlanBox;

    private int currentUserId = -1;
    private String currentUserName = "";
    private int currentProfileId = -1;
    private String currentProfileName = "";

    private JTable catalogueTable;
    private JTable homeTopTable;
    private JTable listTable;
    private JTable historyTable;
    private JTable peopleTable;
    private JTable sqlTable;
    private JTextArea contentDetails;
    private JTextField searchField;
    private JComboBox<String> typeFilter;
    private JComboBox<Integer> ratingBox;
    private JPanel homeRowsPanel;
    private JPanel catalogueGrid;
    private final List<PosterCard> catalogueCards = new ArrayList<>();
    private int selectedContentId = -1;
    private String selectedContentTitle = "";
    private String selectedContentType = "";

    // Home hero / carousel
    private Timer heroTimer;
    private int heroIndex = 0;
    private final List<Integer> heroIds = new ArrayList<>();
    private final List<String> heroTitles = new ArrayList<>();
    private final List<String> heroSynopsis = new ArrayList<>();
    private JLabel heroTitleLabel;
    private JTextArea heroSynopsisArea;
    private JPanel heroBanner;
    private final List<BufferedImage> heroImages = new ArrayList<>();
    private int nextHeroIndex = 0;
    private Timer transitionTimer;
    private float transitionAlpha = 0f;
    private HeroPanel heroPanel;
    private final List<JLabel> indicators = new ArrayList<>();

    AppFrame() {
        super("Flix First");
        configureLookAndFeel();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1260, 780));
        setContentPane(root);
        root.add(mysqlPanel(), "mysql");
        root.add(authPanel(), "auth");
        root.add(appPanel(), "app");
        pack();
        setLocationRelativeTo(null);
        rootCards.show(root, "mysql");
    }

    private JPanel mysqlPanel() {
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(BG);
        page.setBorder(new EmptyBorder(32, 44, 32, 44));

        page.add(new LogoHero("FLIX FIRST", "Cinema, series, streaming"), BorderLayout.NORTH);

        JPanel form = card(new GridBagLayout());
        GridBagConstraints c = gbc();
        hostField = new JTextField("localhost", 22);
        portField = new JTextField("3306", 8);
        dbField = new JTextField("flix_first", 18);
        dbUserField = new JTextField("flixapp", 16);
        dbPasswordField = new JPasswordField("flixfirst", 16);
        styleInput(hostField);
        styleInput(portField);
        styleInput(dbField);
        styleInput(dbUserField);
        styleInput(dbPasswordField);

        addWide(form, c, 0, "Serveur", hostField);
        addWide(form, c, 1, "Port", portField);
        addWide(form, c, 2, "Base", dbField);
        addWide(form, c, 3, "Utilisateur MySQL", dbUserField);
        addWide(form, c, 4, "Mot de passe MySQL", dbPasswordField);

        JButton connect = primary("Connecter");
        connect.addActionListener(e -> connectToMySQL());
        c.gridx = 1;
        c.gridy = 5;
        c.insets = new Insets(16, 8, 8, 8);
        form.add(connect, c);

        JPanel center = new JPanel(new GridBagLayout());
        center.setOpaque(false);
        center.add(form);
        page.add(center, BorderLayout.CENTER);
        return page;
    }

    private JPanel authPanel() {
        JPanel page = new JPanel(new BorderLayout(0, 18));
        page.setBackground(BG);
        page.setBorder(new EmptyBorder(30, 44, 30, 44));
        page.add(new LogoHero("FLIX FIRST", "Votre catalogue premium"), BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(1, 2, 18, 0));
        grid.setOpaque(false);

        JPanel login = card(new GridBagLayout());
        GridBagConstraints c = gbc();
        loginEmailField = new JTextField("demo@flixfirst.com", 24);
        loginPasswordField = new JPasswordField("demo123", 24);
        styleInput(loginEmailField);
        styleInput(loginPasswordField);
        addWide(login, c, 0, "Email", loginEmailField);
        addWide(login, c, 1, "Mot de passe", loginPasswordField);
        JButton loginButton = primary("Se connecter");
        loginButton.addActionListener(e -> login());
        c.gridx = 1;
        c.gridy = 2;
        c.insets = new Insets(14, 8, 8, 8);
        login.add(loginButton, c);

        JPanel register = card(new GridBagLayout());
        GridBagConstraints r = gbc();
        regFirstNameField = new JTextField(18);
        regLastNameField = new JTextField(18);
        regEmailField = new JTextField(22);
        regPasswordField = new JPasswordField(18);
        regPlanBox = new JComboBox<>();
        styleInput(regFirstNameField);
        styleInput(regLastNameField);
        styleInput(regEmailField);
        styleInput(regPasswordField);
        styleCombo(regPlanBox);
        addWide(register, r, 0, "Prenom", regFirstNameField);
        addWide(register, r, 1, "Nom", regLastNameField);
        addWide(register, r, 2, "Email", regEmailField);
        addWide(register, r, 3, "Mot de passe", regPasswordField);
        addWide(register, r, 4, "Formule", regPlanBox);
        JButton create = primary("Creer un compte");
        create.addActionListener(e -> register());
        r.gridx = 1;
        r.gridy = 5;
        r.insets = new Insets(14, 8, 8, 8);
        register.add(create, r);

        grid.add(wrapped("Connexion", login));
        grid.add(wrapped("Inscription", register));
        page.add(grid, BorderLayout.CENTER);
        return page;
    }

    private JPanel appPanel() {
        // Use a background panel with subtle gradient for the app
        JPanel panel = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                int w = getWidth(), h = getHeight();
                GradientPaint gp = new GradientPaint(0, 0, new Color(12, 18, 26), w, h, new Color(18, 24, 32));
                g2.setPaint(gp);
                g2.fillRect(0, 0, w, h);
                g2.dispose();
            }
        };
        panel.setOpaque(false);
        panel.add(sidebar(), BorderLayout.WEST);
        panel.add(mainArea(), BorderLayout.CENTER);
        return panel;
    }

    private JPanel sidebar() {
        JPanel side = new JPanel();
        side.setPreferredSize(new Dimension(235, 780));
        side.setBackground(new Color(5, 8, 15));
        side.setBorder(new EmptyBorder(24, 18, 24, 18));
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.add(new SmallLogo());
        side.add(Box.createVerticalStrut(28));
        side.add(nav("Accueil", "home"));
        side.add(nav("Catalogue", "catalogue"));
        side.add(nav("Ma liste", "list"));
        side.add(nav("Historique", "history"));
        side.add(nav("Equipe artistique", "people"));
        side.add(nav("SQL", "sql"));
        side.add(Box.createVerticalGlue());
        JButton logout = secondary("Deconnexion");
        logout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        logout.addActionListener(e -> {
            currentUserId = -1;
            currentProfileId = -1;
            currentProfileName = "";
            rootCards.show(root, "auth");
        });
        side.add(logout);
        return side;
    }

    private JPanel mainArea() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BG);
        main.setBorder(new EmptyBorder(20, 22, 20, 22));
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel title = new JLabel("Flix First");
        title.setForeground(TEXT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        status.setForeground(GOLD);
        status.setFont(new Font("Segoe UI", Font.BOLD, 13));
        top.add(title, BorderLayout.WEST);
        top.add(status, BorderLayout.EAST);

        appPages.setOpaque(false);
        appPages.add(homePage(), "home");
        appPages.add(cataloguePage(), "catalogue");
        appPages.add(listPage(), "list");
        appPages.add(historyPage(), "history");
        appPages.add(peoplePage(), "people");
        appPages.add(sqlPage(), "sql");

        main.add(top, BorderLayout.NORTH);
        main.add(appPages, BorderLayout.CENTER);
        return main;
    }

    private JPanel homePage() {
        JPanel page = page();
        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        LogoHero logo = new LogoHero("Bienvenue sur Flix First", "Films, series et talents reunis");
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(logo);

        JPanel profiles = createProfilesStrip();
        profiles.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(profiles);

        heroBanner = createHeroBannerPanel();
        heroBanner.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(heroBanner);
        content.add(Box.createVerticalStrut(18));

        homeRowsPanel = new JPanel();
        homeRowsPanel.setOpaque(false);
        homeRowsPanel.setLayout(new BoxLayout(homeRowsPanel, BoxLayout.Y_AXIS));
        homeRowsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(homeRowsPanel);

        JScrollPane pane = scroll(content);
        pane.setBorder(null);
        page.add(pane, BorderLayout.CENTER);
        return page;
    }

    private JPanel createProfilesStrip() {
        JPanel strip = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        strip.setOpaque(false);
        strip.setBorder(new EmptyBorder(6, 0, 6, 0));
        // load current user's profiles if logged
        if (currentUserId > 0) {
            List<IdLabel> profiles = new ArrayList<>();
            query("SELECT id_profil, pseudo FROM Profil WHERE id_utilisateur = ?", rs -> profiles.add(new IdLabel(rs.getInt(1), rs.getString(2))), currentUserId);
            for (IdLabel p : profiles) {
                JPanel avatar = profileAvatar(p.label());
                avatar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                avatar.addMouseListener(new MouseAdapter() {
                    @Override public void mouseClicked(MouseEvent e) {
                        currentProfileId = p.id();
                        currentProfileName = p.label();
                        status.setText(currentUserName + " — " + currentProfileName);
                    }
                });
                strip.add(avatar);
            }
            JButton manage = secondary("Gerer profils");
            manage.addActionListener(e -> selectProfileForUser());
            strip.add(manage);
        } else {
            JLabel info = new JLabel("Connectez-vous pour gerer les profils");
            info.setForeground(MUTED);
            strip.add(info);
        }
        return strip;
    }

    private JPanel profileAvatar(String name) {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(58, 134, 255));
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 220));
                String initials = initialsOf(name);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 14));
                int w = g2.getFontMetrics().stringWidth(initials);
                int h = g2.getFontMetrics().getAscent();
                g2.drawString(initials, (getWidth() - w) / 2, (getHeight() + h) / 2 - 3);
                g2.dispose();
            }
        };
        p.setPreferredSize(new Dimension(64, 64));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(6, 6, 6, 6));
        return p;
    }

    private String initialsOf(String name) {
        if (name == null || name.isBlank()) return "?";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
        return (parts[0].substring(0, 1) + parts[1].substring(0, 1)).toUpperCase();
    }

    private JPanel createHeroBannerPanel() {
        heroPanel = new HeroPanel();
        heroPanel.setLayout(new BorderLayout());
        heroPanel.setBorder(new EmptyBorder(18, 18, 18, 18));

        heroTitleLabel = new JLabel(" ");
        heroTitleLabel.setForeground(TEXT);
        heroTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 38));

        heroSynopsisArea = new JTextArea();
        heroSynopsisArea.setEditable(false);
        heroSynopsisArea.setLineWrap(true);
        heroSynopsisArea.setWrapStyleWord(true);
        heroSynopsisArea.setForeground(new Color(229, 234, 244));
        heroSynopsisArea.setOpaque(false);
        heroSynopsisArea.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        heroSynopsisArea.setBorder(null);

        JPanel left = new JPanel(new BorderLayout(8, 8));
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(470, 290));
        left.setBorder(new EmptyBorder(28, 26, 24, 20));
        left.add(heroTitleLabel, BorderLayout.NORTH);
        left.add(heroSynopsisArea, BorderLayout.CENTER);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        controls.setOpaque(false);
        JButton watch = primary("Regarder");
        watch.addActionListener(e -> {
            if (!heroIds.isEmpty()) {
                int id = heroIds.get(heroIndex % heroIds.size());
                // select in catalogue and open watch
                showApp("catalogue");
                refreshCatalogue();
                for (int r = 0; r < catalogueTable.getRowCount(); r++) {
                    if (String.valueOf(catalogueTable.getValueAt(r, 0)).equals(String.valueOf(id))) {
                        catalogueTable.setRowSelectionInterval(r, r);
                        watchSelected();
                        break;
                    }
                }
            }
        });
        JButton trailer = secondary("Bande-annonce");
        trailer.addActionListener(e -> {
            if (!heroTitles.isEmpty()) {
                String t = heroTitles.get(heroIndex % heroTitles.size());
                try { if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(new URI(getTrailerUrl(t))); } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Impossible d'ouvrir la bande-annonce.", "Erreur", JOptionPane.ERROR_MESSAGE); }
            }
        });
        controls.add(watch);
        controls.add(trailer);

        left.add(controls, BorderLayout.SOUTH);

        heroPanel.add(left, BorderLayout.WEST);

        JPanel dots = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 6));
        dots.setOpaque(false);
        heroPanel.add(dots, BorderLayout.SOUTH);

        // timer to rotate (starts when images loaded)
        heroTimer = new Timer(5000, e -> {
            if (!heroTitles.isEmpty()) {
                startTransitionTo((heroIndex + 1) % heroTitles.size());
            }
        });

        // smooth transition animator
        transitionTimer = new Timer(40, e -> {
            transitionAlpha += 0.12f;
            if (transitionAlpha >= 1f) {
                // finish
                transitionTimer.stop();
                heroIndex = nextHeroIndex;
                transitionAlpha = 0f;
                heroPanel.setPrimary(heroImages.isEmpty() ? null : heroImages.get(heroIndex));
                updateHeroDisplay();
            } else {
                heroPanel.setBlend(transitionAlpha);
            }
        });

        // load images and indicators
        SwingUtilities.invokeLater(() -> {
            loadHeroImages();
            dots.removeAll();
            indicators.clear();
            for (int i = 0; i < Math.max(1, heroTitles.size()); i++) {
                JLabel dot = new JLabel("\u25CF");
                dot.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                dot.setForeground(i == heroIndex ? GOLD : MUTED);
                final int idx = i;
                dot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                dot.addMouseListener(new MouseAdapter() { @Override public void mouseClicked(MouseEvent e) { startTransitionTo(idx); } });
                dots.add(dot);
                indicators.add(dot);
            }
            dots.revalidate();
            dots.repaint();
            if (!heroTitles.isEmpty()) heroTimer.start();
        });

        return heroPanel;
    }

    private void loadFeatured() {
        heroIds.clear(); heroTitles.clear(); heroSynopsis.clear(); heroIndex = 0;
        query("SELECT id_contenu, titre, COALESCE(synopsis, '') FROM Contenu ORDER BY id_contenu LIMIT 8", rs -> {
            heroIds.add(rs.getInt(1));
            heroTitles.add(rs.getString(2));
            heroSynopsis.add(rs.getString(3));
        });
        updateHeroDisplay();
        if (!heroTitles.isEmpty()) {
            heroTimer.restart();
        } else {
            heroTimer.stop();
        }
    }

    private void loadHeroImages() {
        heroImages.clear();
        Path dir = Path.of("assets", "hero");
        if (Files.exists(dir) && Files.isDirectory(dir)) {
            try (var stream = Files.list(dir)) {
                stream.filter(p -> !Files.isDirectory(p)).limit(8).forEach(p -> {
                    try {
                        BufferedImage img = ImageIO.read(p.toFile());
                        if (img != null) heroImages.add(img);
                    } catch (IOException ignored) { }
                });
            } catch (IOException ignored) { }
        }
        // if no images, leave heroImages empty and HeroPanel will use gradient
        if (!heroImages.isEmpty()) heroPanel.setPrimary(heroImages.get(heroIndex));
    }

    private void startTransitionTo(int idx) {
        if (heroTitles.isEmpty()) return;
        if (idx == heroIndex) return;
        nextHeroIndex = idx;
        BufferedImage next = heroImages.size() > nextHeroIndex ? heroImages.get(nextHeroIndex) : null;
        heroPanel.setSecondary(next);
        transitionAlpha = 0f;
        transitionTimer.start();
        // update indicators color immediately
        for (int i = 0; i < indicators.size(); i++) indicators.get(i).setForeground(i == nextHeroIndex ? GOLD : MUTED);
    }

    private void updateHeroDisplay() {
        if (heroTitles.isEmpty()) return;
        int idx = heroIndex % heroTitles.size();
        heroTitleLabel.setText(heroTitles.get(idx));
        heroSynopsisArea.setText(heroSynopsis.get(idx) == null || heroSynopsis.get(idx).isBlank() ? "Aucune description." : heroSynopsis.get(idx));
        heroSynopsisArea.setCaretPosition(0);
        if (heroPanel != null) {
            heroPanel.setTitle(heroTitles.get(idx));
        }
    }

    private JPanel cataloguePage() {
        JPanel page = page();
        page.add(header("Catalogue"), BorderLayout.NORTH);

        JPanel filters = card(new FlowLayout(FlowLayout.LEFT, 10, 10));
        searchField = new JTextField(24);
        typeFilter = new JComboBox<>(new String[]{"Tous", "Films", "Series"});
        styleInput(searchField);
        styleCombo(typeFilter);
        JButton search = primary("Rechercher");
        search.addActionListener(e -> refreshCatalogue());
        filters.add(label("Titre"));
        filters.add(searchField);
        filters.add(label("Type"));
        filters.add(typeFilter);
        filters.add(search);

        catalogueTable = table("ID", "Titre", "Type", "Annee", "Genres", "Duree/Createur", "Note");
        catalogueGrid = new JPanel(new FlowLayout(FlowLayout.LEFT, 18, 18));
        catalogueGrid.setOpaque(false);
        contentDetails = textArea();

        JButton watch = primary("Regarder");
        watch.addActionListener(e -> watchSelected());
        JButton clip = secondary("Extrait reel");
        clip.addActionListener(e -> openClipSelected());
        JButton trailer = secondary("Bande-annonce");
        trailer.addActionListener(e -> openTrailerSelected());
        JButton add = secondary("Ajouter a ma liste");
        add.addActionListener(e -> addSelectedToList());
        ratingBox = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5});
        styleCombo(ratingBox);
        JButton rate = secondary("Noter");
        rate.addActionListener(e -> rateSelected());

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        actions.setOpaque(false);
        actions.add(watch);
        actions.add(clip);
        actions.add(trailer);
        actions.add(add);
        actions.add(label("Note"));
        actions.add(ratingBox);
        actions.add(rate);

        JPanel detail = card(new BorderLayout(0, 10));
        detail.add(section("Fiche"), BorderLayout.NORTH);
        detail.add(scroll(contentDetails), BorderLayout.CENTER);
        detail.add(actions, BorderLayout.SOUTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scroll(catalogueGrid), detail);
        split.setResizeWeight(0.70);
        split.setBorder(null);
        split.setBackground(BG);
        split.setDividerSize(8);

        JPanel center = new JPanel(new BorderLayout(0, 14));
        center.setOpaque(false);
        center.add(filters, BorderLayout.NORTH);
        center.add(split, BorderLayout.CENTER);
        page.add(center, BorderLayout.CENTER);
        return page;
    }

    private JPanel listPage() {
        JPanel page = page();
        page.add(header("Ma liste"), BorderLayout.NORTH);
        listTable = table("ID", "Titre", "Type", "Annee", "Ajout");
        JButton remove = primary("Retirer");
        remove.addActionListener(e -> removeFromList());
        page.add(scroll(listTable), BorderLayout.CENTER);
        page.add(buttonBar(remove), BorderLayout.SOUTH);
        return page;
    }

    private JPanel historyPage() {
        JPanel page = page();
        page.add(header("Historique"), BorderLayout.NORTH);
        historyTable = table("Date", "Titre", "Lecture", "Progression", "Termine");
        page.add(scroll(historyTable), BorderLayout.CENTER);
        return page;
    }

    private JPanel peoplePage() {
        JPanel page = page();
        page.add(header("Acteurs, realisateurs et producteurs"), BorderLayout.NORTH);
        peopleTable = table("Contenu", "Personne", "Participation", "Detail", "Pays");
        page.add(scroll(peopleTable), BorderLayout.CENTER);
        return page;
    }

    private JPanel sqlPage() {
        JPanel page = page();
        page.add(header("Verification SQL"), BorderLayout.NORTH);
        sqlTable = table("Resultat");
        JPanel actions = card(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JButton counts = primary("Relations");
        JButton isa = secondary("Film / Serie");
        JButton team = secondary("Equipe artistique");
        JButton multiRoles = secondary("Multi-roles");
        counts.addActionListener(e -> runCounts());
        isa.addActionListener(e -> runIsa());
        team.addActionListener(e -> runTeam());
        multiRoles.addActionListener(e -> runMultiRoles());
        actions.add(counts);
        actions.add(isa);
        actions.add(team);
        actions.add(multiRoles);
        JPanel center = new JPanel(new BorderLayout(0, 14));
        center.setOpaque(false);
        center.add(actions, BorderLayout.NORTH);
        center.add(scroll(sqlTable), BorderLayout.CENTER);
        page.add(center, BorderLayout.CENTER);
        return page;
    }

    private void connectToMySQL() {
        Db.configure(hostField.getText().trim(), portField.getText().trim(), dbField.getText().trim(),
            dbUserField.getText().trim(), new String(dbPasswordField.getPassword()));
        try (Connection ignored = Db.connect()) {
            loadPlans();
            rootCards.show(root, "auth");
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("unknown database")) {
                int choice = JOptionPane.showConfirmDialog(
                    this,
                    "La base flix_first n'existe pas encore. Voulez-vous la creer automatiquement ?",
                    "Installer la base",
                    JOptionPane.YES_NO_OPTION
                );
                if (choice == JOptionPane.YES_OPTION) {
                    try {
                        Db.installSchema();
                        try (Connection ignored = Db.connect()) {
                            loadPlans();
                            rootCards.show(root, "auth");
                        }
                        return;
                    } catch (SQLException installError) {
                        JOptionPane.showMessageDialog(this, installError.getMessage(), "Installation MySQL", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }
            JOptionPane.showMessageDialog(this, e.getMessage(), "Connexion MySQL", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadPlans() {
        regPlanBox.removeAllItems();
        query("SELECT id_formule, nom FROM FormuleAbonnement ORDER BY prix_mensuel", rs ->
            regPlanBox.addItem(new IdLabel(rs.getInt(1), rs.getString(2)))
        );
    }

    private void login() {
        String email = loginEmailField.getText().trim();
        String password = new String(loginPasswordField.getPassword());
        query("SELECT id_utilisateur, prenom, nom FROM Utilisateur WHERE email = ? AND mot_de_passe_hash = ?",
            rs -> {
                currentUserId = rs.getInt("id_utilisateur");
                currentUserName = rs.getString("prenom") + " " + rs.getString("nom");
            }, email, sha256(password));
        if (currentUserId > 0) {
            // after login, select or create a profile
            selectProfileForUser();
        } else {
            JOptionPane.showMessageDialog(this, "Identifiants incorrects.", "Connexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void selectProfileForUser() {
        List<IdLabel> profiles = new ArrayList<>();
        // If an older database is opened, upgrade it without deleting existing data.
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement("SELECT id_profil, pseudo FROM Profil WHERE id_utilisateur = ?")) {
            ps.setInt(1, currentUserId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) profiles.add(new IdLabel(rs.getInt(1), rs.getString(2)));
            }
        } catch (SQLException e) {
            // If the Profil table is missing or other SQL error occurs, do not try to modify the schema automatically.
            JOptionPane.showMessageDialog(this,
                "Erreur SQL lors du chargement des profils : " + e.getMessage() +
                "\n\nVeuillez verifier que la base flix_first est installee en executant sql/flix_first_mysql.sql",
                "Erreur base de donnees", JOptionPane.ERROR_MESSAGE);
            currentUserId = -1;
            return;
        }
        // make plan box visually prominent (gold border)
        regPlanBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GOLD, 2), new EmptyBorder(6, 8, 6, 8)));
        regPlanBox.setBackground(new Color(24, 30, 40));
        regPlanBox.setForeground(TEXT);

        if (profiles.isEmpty()) {
            String pseudo = JOptionPane.showInputDialog(this, "Aucun profil trouve. Entrez un pseudo pour creer un profil:");
            if (pseudo != null && !pseudo.trim().isBlank()) {
                update("INSERT INTO Profil(pseudo, avatar, id_utilisateur) VALUES (?, NULL, ?)", pseudo.trim(), currentUserId);
                // reload profiles
                selectProfileForUser();
                return;
            } else {
                // cancel login
                currentUserId = -1;
                return;
            }
        }

        String[] options = new String[profiles.size() + 1];
        for (int i = 0; i < profiles.size(); i++) options[i] = profiles.get(i).label();
        options[profiles.size()] = "Creer un nouveau profil";
        String selected = (String) JOptionPane.showInputDialog(this, "Choisissez un profil:", "Profils",
            JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
        if (selected == null) {
            currentUserId = -1; // user cancelled
            return;
        }
        if (selected.equals("Creer un nouveau profil")) {
            String pseudo = JOptionPane.showInputDialog(this, "Entrez le pseudo du nouveau profil:");
            if (pseudo != null && !pseudo.trim().isBlank()) {
                update("INSERT INTO Profil(pseudo, avatar, id_utilisateur) VALUES (?, NULL, ?)", pseudo.trim(), currentUserId);
                selectProfileForUser();
                return;
            } else {
                currentUserId = -1; // cancel
                return;
            }
        }
        // find chosen profile id
        for (IdLabel p : profiles) {
            if (p.label().equals(selected)) {
                currentProfileId = p.id();
                currentProfileName = p.label();
                break;
            }
        }
        // show app
        rootCards.show(root, "app");
        showApp("home");
    }

    private void register() {
        IdLabel plan = (IdLabel) regPlanBox.getSelectedItem();
        if (plan == null) {
            return;
        }
        try (Connection c = Db.connect()) {
            c.setAutoCommit(false);
            int id;
            try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO Utilisateur(email, mot_de_passe_hash, nom, prenom, date_inscription) VALUES (?, ?, ?, ?, CURRENT_DATE())",
                Statement.RETURN_GENERATED_KEYS
            )) {
                ps.setString(1, regEmailField.getText().trim());
                ps.setString(2, sha256(new String(regPasswordField.getPassword())));
                ps.setString(3, regLastNameField.getText().trim());
                ps.setString(4, regFirstNameField.getText().trim());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    keys.next();
                    id = keys.getInt(1);
                }
            }
            try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO Abonnement(id_utilisateur, id_formule, date_debut, statut) VALUES (?, ?, CURRENT_DATE(), 'actif')"
            )) {
                ps.setInt(1, id);
                ps.setInt(2, plan.id());
                ps.executeUpdate();
            }
            c.commit();
            JOptionPane.showMessageDialog(this, "Compte cree.");
            loginEmailField.setText(regEmailField.getText().trim());
            loginPasswordField.setText(new String(regPasswordField.getPassword()));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Inscription", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showApp(String page) {
        appCards.show(appPages, page);
        String s = currentUserName;
        if (currentProfileName != null && !currentProfileName.isBlank()) s += " — " + currentProfileName;
        status.setText(s);
        switch (page) {
            case "home" -> refreshHome();
            case "catalogue" -> refreshCatalogue();
            case "list" -> refreshList();
            case "history" -> refreshHistory();
            case "people" -> refreshPeople();
            case "sql" -> runCounts();
            default -> { }
        }
    }

    private JButton nav(String label, String page) {
        JButton b = button(label, PANEL, TEXT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.addActionListener(e -> showApp(page));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(RED_HOVER); }
            @Override public void mouseExited(MouseEvent e) { b.setBackground(PANEL); }
        });
        return b;
    }

    private void refreshHome() {
        loadFeatured();
        if (homeRowsPanel != null) {
            homeRowsPanel.removeAll();
            homeRowsPanel.add(buildPosterRow("Tendances", fetchCatalogItems(" GROUP BY c.id_contenu ORDER BY note DESC, c.titre LIMIT 10")));
            homeRowsPanel.add(buildPosterRow("Films", fetchCatalogItems(" AND c.type_contenu = 'film' GROUP BY c.id_contenu ORDER BY c.annee_sortie DESC, c.titre LIMIT 10")));
            homeRowsPanel.add(buildPosterRow("Series", fetchCatalogItems(" AND c.type_contenu = 'serie' GROUP BY c.id_contenu ORDER BY c.annee_sortie DESC, c.titre LIMIT 10")));
            homeRowsPanel.revalidate();
            homeRowsPanel.repaint();
        }
        status.setText(currentUserName);
    }

    private void refreshCatalogue() {
        String suffix = "";
        List<Object> params = new ArrayList<>();
        if (searchField != null && !searchField.getText().trim().isBlank()) {
            suffix += " AND LOWER(c.titre) LIKE ? ";
            params.add("%" + searchField.getText().trim().toLowerCase() + "%");
        }
        String type = typeFilter == null ? "Tous" : String.valueOf(typeFilter.getSelectedItem());
        if ("Films".equals(type)) {
            suffix += " AND c.type_contenu = 'film' ";
        }
        if ("Series".equals(type)) {
            suffix += " AND c.type_contenu = 'serie' ";
        }
        suffix += " GROUP BY c.id_contenu ORDER BY c.type_contenu, c.titre";
        runInto(catalogueTable, catalogSql(suffix), params.toArray());
        rebuildCatalogueCards();
    }

    private String catalogSql(String suffix) {
        return """
            SELECT c.id_contenu AS id, c.titre, c.type_contenu AS type, c.annee_sortie AS annee,
                   COALESCE(GROUP_CONCAT(DISTINCT g.nom ORDER BY g.nom SEPARATOR ', '), '-') AS genres,
                   COALESCE(CONCAT(f.duree_minutes, ' min'), s.createur) AS detail,
                   COALESCE(ROUND(AVG(ev.note), 1), '-') AS note
            FROM Contenu c
            LEFT JOIN Film f ON f.id_contenu = c.id_contenu
            LEFT JOIN Serie s ON s.id_contenu = c.id_contenu
            LEFT JOIN ContenuGenre cg ON cg.id_contenu = c.id_contenu
            LEFT JOIN Genre g ON g.id_genre = cg.id_genre
            LEFT JOIN Evaluation ev ON ev.id_contenu = c.id_contenu
            WHERE 1 = 1
            """ + suffix;
    }

    private List<CatalogItem> fetchCatalogItems(String suffix, Object... params) {
        List<CatalogItem> items = new ArrayList<>();
        query(catalogSql(suffix), rs -> items.add(new CatalogItem(
            rs.getInt("id"),
            rs.getString("titre"),
            rs.getString("type"),
            rs.getString("annee"),
            rs.getString("genres"),
            rs.getString("detail"),
            rs.getString("note")
        )), params);
        return items;
    }

    private JPanel buildPosterRow(String title, List<CatalogItem> items) {
        JPanel row = new JPanel(new BorderLayout(0, 8));
        row.setOpaque(false);
        row.setBorder(new EmptyBorder(0, 0, 18, 0));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.add(section(title), BorderLayout.NORTH);

        JPanel strip = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 8));
        strip.setOpaque(false);
        for (CatalogItem item : items) {
            PosterCard card = new PosterCard(item);
            card.setClickActions(() -> {
                showApp("catalogue");
                selectContent(item);
            }, () -> {
                selectContent(item);
                watchSelected();
            });
            strip.add(card);
        }
        JScrollPane scroller = scroll(strip);
        scroller.setBorder(null);
        scroller.setPreferredSize(new Dimension(980, 235));
        scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        row.add(scroller, BorderLayout.CENTER);
        return row;
    }

    private void rebuildCatalogueCards() {
        if (catalogueGrid == null || catalogueTable == null) {
            return;
        }
        catalogueGrid.removeAll();
        catalogueCards.clear();
        selectedContentId = -1;
        for (int row = 0; row < catalogueTable.getRowCount(); row++) {
            CatalogItem item = itemFromTable(row);
            PosterCard card = new PosterCard(item);
            card.setClickActions(() -> selectContent(item), () -> {
                selectContent(item);
                watchSelected();
            });
            catalogueCards.add(card);
            catalogueGrid.add(card);
        }
        if (catalogueTable.getRowCount() > 0) {
            selectContent(itemFromTable(0));
        } else {
            contentDetails.setText("");
        }
        catalogueGrid.revalidate();
        catalogueGrid.repaint();
    }

    private CatalogItem itemFromTable(int row) {
        return new CatalogItem(
            Integer.parseInt(String.valueOf(catalogueTable.getValueAt(row, 0))),
            String.valueOf(catalogueTable.getValueAt(row, 1)),
            String.valueOf(catalogueTable.getValueAt(row, 2)),
            String.valueOf(catalogueTable.getValueAt(row, 3)),
            String.valueOf(catalogueTable.getValueAt(row, 4)),
            String.valueOf(catalogueTable.getValueAt(row, 5)),
            String.valueOf(catalogueTable.getValueAt(row, 6))
        );
    }

    private void selectContent(CatalogItem item) {
        selectedContentId = item.id();
        selectedContentTitle = item.title();
        selectedContentType = item.type();
        for (PosterCard card : catalogueCards) {
            card.setSelected(card.item().id() == item.id());
        }
        showContentDetails(item.id(), item.type());
    }

    private void showSelectedContent() {
        if (selectedContentId > 0) {
            showContentDetails(selectedContentId, selectedContentType);
            return;
        }
        if (catalogueTable == null || catalogueTable.getSelectedRow() < 0) {
            return;
        }
        int id = selectedContentId();
        String type = String.valueOf(catalogueTable.getValueAt(catalogueTable.getSelectedRow(), 2));
        showContentDetails(id, type);
    }

    private void showContentDetails(int id, String type) {
        StringBuilder sb = new StringBuilder();
        query("""
            SELECT c.*, f.duree_minutes, f.realisateur, f.producteur, s.createur, s.nb_saisons
            FROM Contenu c
            LEFT JOIN Film f ON f.id_contenu = c.id_contenu
            LEFT JOIN Serie s ON s.id_contenu = c.id_contenu
            WHERE c.id_contenu = ?
            """, rs -> {
            sb.append(rs.getString("titre")).append("\n");
            sb.append(rs.getString("type_contenu")).append(" | ").append(rs.getInt("annee_sortie")).append(" | ");
            sb.append(rs.getString("classification_age")).append(" | ").append(rs.getString("pays_origine")).append("\n\n");
            if ("film".equals(rs.getString("type_contenu"))) {
                sb.append("Duree : ").append(rs.getInt("duree_minutes")).append(" min\n");
                sb.append("Realisateur : ").append(rs.getString("realisateur")).append("\n");
                sb.append("Producteur : ").append(rs.getString("producteur")).append("\n\n");
            } else {
                sb.append("Createur : ").append(rs.getString("createur")).append("\n");
                sb.append("Saisons : ").append(rs.getInt("nb_saisons")).append("\n\n");
            }
            sb.append(rs.getString("synopsis")).append("\n\n");
        }, id);
        sb.append("Genres : ").append(one("SELECT COALESCE(GROUP_CONCAT(g.nom ORDER BY g.nom SEPARATOR ', '), '-') FROM ContenuGenre cg JOIN Genre g ON g.id_genre = cg.id_genre WHERE cg.id_contenu = ?", id)).append("\n");
        sb.append("Casting : ").append(one("SELECT COALESCE(GROUP_CONCAT(p.nom_complet ORDER BY p.nom_complet SEPARATOR ', '), '-') FROM ContenuPersonne cp JOIN Personne p ON p.id_personne = cp.id_personne WHERE cp.id_contenu = ? AND cp.participation = 'acteur'", id)).append("\n");
        if ("serie".equals(type)) {
            sb.append("\nEpisodes\n");
            query("""
                SELECT sa.numero_saison, e.numero_episode, e.titre, e.duree_minutes
                FROM Saison sa JOIN Episode e ON e.id_saison = sa.id_saison
                WHERE sa.id_contenu = ?
                ORDER BY sa.numero_saison, e.numero_episode
                """, rs -> sb.append("S").append(rs.getInt(1)).append("E").append(rs.getInt(2)).append(" - ").append(rs.getString(3)).append(" (").append(rs.getInt(4)).append(" min)\n"), id);
        }
        contentDetails.setText(sb.toString());
        contentDetails.setCaretPosition(0);
    }

    private void watchSelected() {
        int id = selectedContentId();
        if (id <= 0) {
            return;
        }
        String title = selectedContentTitle == null || selectedContentTitle.isBlank()
            ? String.valueOf(catalogueTable.getValueAt(catalogueTable.getSelectedRow(), 1))
            : selectedContentTitle;
        WatchDialog dialog = new WatchDialog(this, id, title);
        dialog.setVisible(true);
        refreshHistory();
    }

    private void openTrailerSelected() {
        String title = selectedContentTitle;
        if ((title == null || title.isBlank()) && catalogueTable != null && catalogueTable.getSelectedRow() >= 0) {
            title = String.valueOf(catalogueTable.getValueAt(catalogueTable.getSelectedRow(), 1));
        }
        if (title == null || title.isBlank()) {
            return;
        }
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(new URI(getTrailerUrl(title)));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Impossible d'ouvrir la bande-annonce : " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openClipSelected() {
        String title = selectedContentTitle;
        if ((title == null || title.isBlank()) && catalogueTable != null && catalogueTable.getSelectedRow() >= 0) {
            title = String.valueOf(catalogueTable.getValueAt(catalogueTable.getSelectedRow(), 1));
        }
        if (title == null || title.isBlank()) {
            return;
        }
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(new URI(getClipUrl(title)));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Impossible d'ouvrir l'extrait : " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getTrailerUrl(String title) {
        return switch (title.toLowerCase()) {
            case "inception" -> "https://www.youtube.com/watch?v=YoHD9XEInc0";
            case "interstellar" -> "https://www.youtube.com/watch?v=zSWdZVtXT7E";
            case "dune" -> "https://www.youtube.com/watch?v=n9xhJrPXop4";
            case "parasite" -> "https://www.youtube.com/watch?v=5xH0HfJHsaY";
            case "big buck bunny" -> "https://video.blender.org/w/pAQiVCgv2CsLg79KKXUoMw";
            case "caminandes 3: llamigos" -> "https://video.blender.org/w/5ruRYckTcQMTMQvyqMnVsr";
            case "tears of steel" -> "https://video.blender.org/w/hs1zJY8mdr3iH2JNmxpeGV";
            case "stranger things" -> "https://www.youtube.com/results?search_query=stranger+things+trailer";
            case "lupin" -> "https://www.youtube.com/results?search_query=lupin+trailer";
            default -> "https://www.youtube.com/results?search_query=" + title.replace(' ', '+') + "+trailer";
        };
    }

    private String getClipUrl(String title) {
        return switch (title.toLowerCase()) {
            case "big buck bunny" -> "https://video.blender.org/w/pAQiVCgv2CsLg79KKXUoMw";
            case "caminandes 3: llamigos" -> "https://video.blender.org/w/5ruRYckTcQMTMQvyqMnVsr";
            case "tears of steel" -> "https://video.blender.org/w/hs1zJY8mdr3iH2JNmxpeGV";
            default -> getTrailerUrl(title);
        };
    }

    private void addSelectedToList() {
        int id = selectedContentId();
        update("INSERT IGNORE INTO MaListe(id_utilisateur, id_contenu) VALUES (?, ?)", currentUserId, id);
        JOptionPane.showMessageDialog(this, "Ajoute a votre liste.");
    }

    private void rateSelected() {
        int id = selectedContentId();
        int note = (Integer) ratingBox.getSelectedItem();
        update("""
            INSERT INTO Evaluation(id_utilisateur, id_contenu, note, date_evaluation)
            VALUES (?, ?, ?, CURRENT_DATE())
            ON DUPLICATE KEY UPDATE note = ?, date_evaluation = CURRENT_DATE()
            """, currentUserId, id, note, note);
        refreshCatalogue();
    }

    private void refreshList() {
        runInto(listTable, """
            SELECT c.id_contenu AS id, c.titre, c.type_contenu AS type, c.annee_sortie AS annee, ml.date_ajout AS ajout
            FROM MaListe ml
            JOIN Contenu c ON c.id_contenu = ml.id_contenu
            WHERE ml.id_utilisateur = ?
            ORDER BY ml.date_ajout DESC
            """, currentUserId);
    }

    private void removeFromList() {
        if (listTable.getSelectedRow() < 0) {
            return;
        }
        int id = Integer.parseInt(String.valueOf(listTable.getValueAt(listTable.getSelectedRow(), 0)));
        update("DELETE FROM MaListe WHERE id_utilisateur = ? AND id_contenu = ?", currentUserId, id);
        refreshList();
    }

    private void refreshHistory() {
        runInto(historyTable, """
            SELECT h.date_visionnage AS date, c.titre,
                   CASE
                       WHEN c.type_contenu = 'film' THEN c.titre
                       ELSE COALESCE(e.titre, c.titre)
                   END AS lecture,
                   h.progression_minutes AS progression,
                   CASE WHEN h.termine THEN 'oui' ELSE 'non' END AS termine
            FROM HistoriqueVisionnage h
            JOIN Contenu c ON c.id_contenu = h.id_contenu
            LEFT JOIN Episode e ON e.id_episode = h.id_episode
            WHERE h.id_utilisateur = ?
            ORDER BY h.date_visionnage DESC
            """, currentUserId);
    }

    private void refreshPeople() {
        runInto(peopleTable, """
            SELECT c.titre AS contenu, p.nom_complet AS personne,
                   cp.participation,
                   CASE
                       WHEN cp.participation = 'acteur' THEN COALESCE(cp.role_personnage, 'Role non renseigne')
                       WHEN cp.participation = 'realisateur' THEN 'Mise en scene'
                       WHEN cp.participation = 'producteur' THEN 'Production'
                       WHEN cp.participation = 'createur' THEN 'Creation'
                       ELSE cp.participation
                   END AS detail,
                   COALESCE(p.pays, '-') AS pays
            FROM ContenuPersonne cp
            JOIN Contenu c ON c.id_contenu = cp.id_contenu
            JOIN Personne p ON p.id_personne = cp.id_personne
            ORDER BY c.titre, cp.participation, p.nom_complet
            """);
    }

    private void runCounts() {
        runInto(sqlTable, """
            SELECT 'Utilisateur' AS relation, COUNT(*) AS lignes FROM Utilisateur
            UNION ALL SELECT 'FormuleAbonnement', COUNT(*) FROM FormuleAbonnement
            UNION ALL SELECT 'Abonnement', COUNT(*) FROM Abonnement
            UNION ALL SELECT 'Contenu', COUNT(*) FROM Contenu
            UNION ALL SELECT 'Film', COUNT(*) FROM Film
            UNION ALL SELECT 'Serie', COUNT(*) FROM Serie
            UNION ALL SELECT 'Saison', COUNT(*) FROM Saison
            UNION ALL SELECT 'Episode', COUNT(*) FROM Episode
            UNION ALL SELECT 'Genre', COUNT(*) FROM Genre
            UNION ALL SELECT 'Personne', COUNT(*) FROM Personne
            UNION ALL SELECT 'HistoriqueVisionnage', COUNT(*) FROM HistoriqueVisionnage
            UNION ALL SELECT 'Evaluation', COUNT(*) FROM Evaluation
            ORDER BY relation
            """);
    }

    private void runIsa() {
        runInto(sqlTable, """
            SELECT c.id_contenu, c.titre, c.type_contenu,
                   CASE WHEN f.id_contenu IS NULL THEN 0 ELSE 1 END AS ligne_film,
                   CASE WHEN s.id_contenu IS NULL THEN 0 ELSE 1 END AS ligne_serie
            FROM Contenu c
            LEFT JOIN Film f ON f.id_contenu = c.id_contenu
            LEFT JOIN Serie s ON s.id_contenu = c.id_contenu
            ORDER BY c.id_contenu
            """);
    }

    private void runTeam() {
        runInto(sqlTable, """
            SELECT c.titre, p.nom_complet, cp.participation,
                   CASE
                       WHEN cp.participation = 'acteur' THEN COALESCE(cp.role_personnage, 'Role non renseigne')
                       WHEN cp.participation = 'realisateur' THEN 'Mise en scene'
                       WHEN cp.participation = 'producteur' THEN 'Production'
                       WHEN cp.participation = 'createur' THEN 'Creation'
                       ELSE cp.participation
                   END AS detail,
                   COALESCE(p.pays, '-') AS pays
            FROM ContenuPersonne cp
            JOIN Contenu c ON c.id_contenu = cp.id_contenu
            JOIN Personne p ON p.id_personne = cp.id_personne
            ORDER BY c.titre, cp.participation, p.nom_complet
            """);
    }

    private void runMultiRoles() {
        runInto(sqlTable, """
            SELECT c.titre, p.nom_complet,
                   GROUP_CONCAT(cp.participation ORDER BY cp.participation SEPARATOR ', ') AS participations,
                   GROUP_CONCAT(
                       CASE
                           WHEN cp.participation = 'acteur' THEN COALESCE(cp.role_personnage, 'Role non renseigne')
                           WHEN cp.participation = 'realisateur' THEN 'Mise en scene'
                           WHEN cp.participation = 'producteur' THEN 'Production'
                           WHEN cp.participation = 'createur' THEN 'Creation'
                           ELSE cp.participation
                       END
                       ORDER BY cp.participation SEPARATOR ', '
                   ) AS details
            FROM ContenuPersonne cp
            JOIN Contenu c ON c.id_contenu = cp.id_contenu
            JOIN Personne p ON p.id_personne = cp.id_personne
            GROUP BY c.id_contenu, p.id_personne, c.titre, p.nom_complet
            HAVING COUNT(*) > 1
            """);
    }

    private int selectedContentId() {
        if (selectedContentId > 0) {
            return selectedContentId;
        }
        if (catalogueTable == null || catalogueTable.getSelectedRow() < 0) {
            return -1;
        }
        return Integer.parseInt(String.valueOf(catalogueTable.getValueAt(catalogueTable.getSelectedRow(), 0)));
    }

    private void update(String sql, Object... params) {
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "SQL", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String one(String sql, Object... params) {
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : "-";
            }
        } catch (SQLException e) {
            return "-";
        }
    }

    private void query(String sql, RowReader reader, Object... params) {
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    reader.read(rs);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "SQL", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void runInto(JTable table, String sql, Object... params) {
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                DefaultTableModel model = new DefaultTableModel() {
                    @Override public boolean isCellEditable(int row, int column) { return false; }
                };
                ResultSetMetaData meta = rs.getMetaData();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    model.addColumn(meta.getColumnLabel(i));
                }
                while (rs.next()) {
                    Object[] row = new Object[meta.getColumnCount()];
                    for (int i = 1; i <= meta.getColumnCount(); i++) {
                        row[i - 1] = rs.getObject(i);
                    }
                    model.addRow(row);
                }
                table.setModel(model);
                style(table);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "SQL", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void bind(PreparedStatement ps, Object... params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            ps.setObject(i + 1, params[i]);
        }
    }

    private String sha256(String text) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private JPanel page() {
        JPanel p = new JPanel(new BorderLayout(0, 18));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(18, 0, 0, 0));
        return p;
    }

    private JPanel card(java.awt.LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setBackground(PANEL);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(48, 59, 86)),
            new EmptyBorder(16, 16, 16, 16)
        ));
        return p;
    }

    private JPanel wrapped(String title, Component component) {
        JPanel p = card(new BorderLayout(0, 10));
        p.add(section(title), BorderLayout.NORTH);
        p.add(component, BorderLayout.CENTER);
        return p;
    }

    private JPanel buttonBar(JButton button) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        p.setOpaque(false);
        p.add(button);
        return p;
    }

    private JLabel header(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(TEXT);
        l.setFont(new Font("Segoe UI", Font.BOLD, 23));
        return l;
    }

    private JLabel section(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(TEXT);
        l.setFont(new Font("Segoe UI", Font.BOLD, 16));
        return l;
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(TEXT);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        return l;
    }

    private JTable table(String... columns) {
        JTable t = new JTable(new DefaultTableModel(columns, 0));
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        style(t);
        return t;
    }

    private void style(JTable t) {
        t.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        t.setForeground(TEXT);
        t.setBackground(PANEL_2);
        t.setSelectionBackground(new Color(86, 21, 31));
        t.setSelectionForeground(Color.WHITE);
        t.setRowHeight(32);
        t.setGridColor(new Color(55, 66, 92));
        t.setShowVerticalLines(false);
        t.setOpaque(true);
        JTableHeader h = t.getTableHeader();
        h.setFont(new Font("Segoe UI", Font.BOLD, 12));
        h.setForeground(TEXT);
        h.setBackground(new Color(34, 43, 66));
        h.setOpaque(true);
        h.setPreferredSize(new Dimension(h.getWidth(), 34));
        DefaultTableCellRenderer r = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                    boolean focused, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, selected, focused, row, column);
                c.setForeground(selected ? Color.WHITE : TEXT);
                c.setBackground(selected ? new Color(120, 24, 36) : (row % 2 == 0 ? PANEL_2 : PANEL_3));
                setBorder(new EmptyBorder(0, 9, 0, 9));
                return c;
            }
        };
        t.setDefaultRenderer(Object.class, r);
    }

    private JTextArea textArea() {
        JTextArea a = new JTextArea();
        a.setEditable(false);
        a.setLineWrap(true);
        a.setWrapStyleWord(true);
        a.setForeground(TEXT);
        a.setBackground(PANEL_2);
        a.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        a.setBorder(new EmptyBorder(14, 14, 14, 14));
        return a;
    }

    private JScrollPane scroll(Component component) {
        JScrollPane pane = new JScrollPane(component);
        pane.setBorder(BorderFactory.createLineBorder(BORDER));
        pane.setBackground(PANEL_2);
        pane.getViewport().setBackground(PANEL_2);
        pane.getVerticalScrollBar().setUnitIncrement(18);
        pane.getHorizontalScrollBar().setUnitIncrement(18);
        return pane;
    }

    private void styleInput(JTextField field) {
        field.setForeground(TEXT);
        field.setBackground(INPUT_BG);
        field.setCaretColor(RED_HOVER);
        field.setSelectionColor(new Color(137, 28, 44));
        field.setSelectedTextColor(Color.WHITE);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            new EmptyBorder(7, 9, 7, 9)
        ));
        field.setOpaque(true);
    }

    private void styleCombo(JComboBox<?> combo) {
        combo.setForeground(TEXT);
        combo.setBackground(INPUT_BG);
        combo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        combo.setBorder(BorderFactory.createLineBorder(BORDER));
        combo.setOpaque(true);
        combo.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                    boolean selected, boolean focused) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, selected, focused);
                label.setForeground(TEXT);
                label.setBackground(selected ? new Color(120, 24, 36) : INPUT_BG);
                label.setBorder(new EmptyBorder(6, 9, 6, 9));
                return label;
            }
        });
    }

    private JButton primary(String text) {
        return button(text, RED, Color.WHITE);
    }

    private JButton secondary(String text) {
        return button(text, new Color(43, 54, 80), TEXT);
    }

    private JButton button(String text, Color bg, Color fg) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color fill = getModel().isPressed() ? getBackground().darker() : getBackground();
                g2.setColor(fill);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(new Color(255, 255, 255, 36));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBackground(bg);
        b.setForeground(fg);
        b.setOpaque(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setBorder(new EmptyBorder(9, 14, 9, 14));
        return b;
    }

    private GridBagConstraints gbc() {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        return c;
    }

    private void addWide(JPanel p, GridBagConstraints c, int row, String label, Component field) {
        c.gridx = 0; c.gridy = row; c.weightx = 0;
        p.add(label(label), c);
        c.gridx = 1; c.gridy = row; c.weightx = 1;
        p.add(field, c);
    }

    private void configureLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }
    }

    private Color colorForTitle(String text) {
        int hash = Math.abs((text == null ? "flix" : text).hashCode());
        float hue = (hash % 360) / 360f;
        return Color.getHSBColor(hue, 0.68f, 0.78f);
    }

    private Color darker(Color c, int amount) {
        return new Color(Math.max(0, c.getRed() - amount), Math.max(0, c.getGreen() - amount), Math.max(0, c.getBlue() - amount));
    }

    private void drawWrapped(Graphics2D g2, String text, int x, int y, int maxWidth, int maxLines, int lineHeight) {
        if (text == null) {
            return;
        }
        String[] words = text.split("\\s+");
        String line = "";
        int lines = 0;
        for (String word : words) {
            String test = line.isBlank() ? word : line + " " + word;
            if (g2.getFontMetrics().stringWidth(test) > maxWidth && !line.isBlank()) {
                g2.drawString(line, x, y + lines * lineHeight);
                lines++;
                line = word;
                if (lines >= maxLines) {
                    return;
                }
            } else {
                line = test;
            }
        }
        if (!line.isBlank() && lines < maxLines) {
            g2.drawString(line, x, y + lines * lineHeight);
        }
    }

    private class PosterCard extends JPanel {
        private final CatalogItem item;
        private Runnable clickAction = () -> { };
        private Runnable doubleClickAction = () -> { };
        private boolean hover;
        private boolean selected;

        PosterCard(CatalogItem item) {
            this.item = item;
            setPreferredSize(new Dimension(168, 232));
            setMinimumSize(new Dimension(168, 232));
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                @Override public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() >= 2) {
                        doubleClickAction.run();
                    } else {
                        clickAction.run();
                    }
                }
            });
        }

        CatalogItem item() {
            return item;
        }

        void setClickActions(Runnable clickAction, Runnable doubleClickAction) {
            this.clickAction = clickAction == null ? () -> { } : clickAction;
            this.doubleClickAction = doubleClickAction == null ? () -> { } : doubleClickAction;
        }

        void setSelected(boolean selected) {
            this.selected = selected;
            repaint();
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            int lift = hover ? 6 : 0;
            int y = 8 - lift;
            Color base = colorForTitle(item.title());
            Color deep = darker(base, 95);

            g2.setColor(new Color(0, 0, 0, hover ? 150 : 100));
            g2.fillRoundRect(7, 15, w - 14, h - 20, 18, 18);
            g2.setPaint(new GradientPaint(0, y, base, w, h, deep));
            g2.fillRoundRect(6, y, w - 12, h - 18, 18, 18);

            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.18f));
            for (int i = 0; i < 5; i++) {
                int oval = 48 + i * 17;
                g2.setColor(i % 2 == 0 ? Color.WHITE : Color.BLACK);
                g2.fillOval((i * 37 + Math.abs(item.title().hashCode())) % Math.max(1, w) - 35, y + 20 + i * 24, oval, oval);
            }
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));

            g2.setColor(new Color(255, 255, 255, 36));
            g2.setStroke(new BasicStroke(2f));
            int[] xs = {28, w - 36, w - 70, 44};
            int[] ys = {y + 42, y + 68, y + 130, y + 116};
            g2.drawPolygon(xs, ys, 4);
            g2.drawLine(28, y + 150, w - 28, y + 92);

            g2.setColor(new Color(0, 0, 0, 155));
            g2.fillRoundRect(6, h - 94, w - 12, 76, 0, 0);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 16));
            g2.setColor(Color.WHITE);
            drawWrapped(g2, item.title(), 16, h - 70, w - 30, 2, 18);

            g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
            g2.setColor(new Color(235, 238, 242));
            String type = item.type().equals("serie") ? "SERIE" : "FILM";
            g2.drawString(type + "  " + item.year(), 16, h - 27);
            g2.setColor(GOLD);
            g2.drawString("Note " + item.note(), w - 66, h - 27);

            if (hover) {
                g2.setColor(new Color(229, 9, 20, 230));
                g2.fillOval(w / 2 - 25, y + 76, 50, 50);
                g2.setColor(Color.WHITE);
                int[] px = {w / 2 - 7, w / 2 - 7, w / 2 + 14};
                int[] py = {y + 91, y + 112, y + 101};
                g2.fillPolygon(px, py, 3);
            }

            if (selected) {
                g2.setColor(GOLD);
                g2.setStroke(new BasicStroke(3f));
                g2.drawRoundRect(7, y + 1, w - 15, h - 21, 18, 18);
            }
            g2.dispose();
        }
    }

    private class WatchDialog extends JDialog {
        private int progress = 0;
        private final JProgressBar bar = new JProgressBar(0, 100);
        private Timer timer;

        WatchDialog(JFrame owner, int contentId, String title) {
            super(owner, "Lecture - " + title, true);
            setSize(960, 590);
            setLocationRelativeTo(owner);
            JPanel panel = new JPanel(new BorderLayout(0, 14));
            panel.setBackground(BG);
            panel.setBorder(new EmptyBorder(20, 20, 20, 20));
            PlayerCanvas player = new PlayerCanvas(title);
            panel.add(player, BorderLayout.CENTER);
            bar.setStringPainted(true);
            bar.setForeground(RED);
            bar.setBackground(PANEL_2);
            bar.setBorder(BorderFactory.createLineBorder(BORDER));
            JButton play = primary("Lecture");
            JButton pause = secondary("Pause");
            JButton clip = secondary("Extrait reel");
            JButton trailer = secondary("Bande-annonce officielle");
            JButton stop = secondary("Terminer");
            JPanel controls = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
            controls.setOpaque(false);
            controls.add(play);
            controls.add(pause);
            controls.add(clip);
            controls.add(trailer);
            controls.add(stop);
            controls.add(bar);
            panel.add(controls, BorderLayout.SOUTH);
            setContentPane(panel);

            timer = new Timer(140, e -> {
                progress = Math.min(100, progress + 1);
                bar.setValue(progress);
                if (progress >= 100) {
                    timer.stop();
                    player.setPlaying(false);
                    saveWatch(contentId, 100, true);
                }
            });
            play.addActionListener(e -> {
                player.setPlaying(true);
                timer.start();
            });
            pause.addActionListener(e -> {
                timer.stop();
                player.setPlaying(false);
            });
            clip.addActionListener(e -> {
                try {
                    if (Desktop.isDesktopSupported()) {
                        Desktop.getDesktop().browse(new URI(getClipUrl(title)));
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Impossible d'ouvrir l'extrait.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            });
            trailer.addActionListener(e -> {
                try {
                    if (Desktop.isDesktopSupported()) {
                        Desktop.getDesktop().browse(new URI(getTrailerUrl(title)));
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Impossible d'ouvrir la bande-annonce.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            });
            stop.addActionListener(e -> {
                timer.stop();
                player.setPlaying(false);
                saveWatch(contentId, progress, progress >= 100);
                dispose();
            });
        }
    }

    private class HeroPanel extends JPanel {
        private BufferedImage primary;
        private BufferedImage secondary;
        private float blend = 0f;
        private String title = "Flix First";

        HeroPanel() {
            setOpaque(false);
            setBorder(new EmptyBorder(12, 12, 12, 12));
            setPreferredSize(new Dimension(980, 355));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 355));
        }

        void setPrimary(BufferedImage img) { this.primary = img; repaint(); }
        void setSecondary(BufferedImage img) { this.secondary = img; repaint(); }
        void setBlend(float a) { this.blend = Math.max(0f, Math.min(1f, a)); repaint(); }
        void setTitle(String title) { this.title = title == null ? "Flix First" : title; repaint(); }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            int w = getWidth(), h = getHeight();
            if (primary != null) {
                g2.drawImage(primary, 0, 0, w, h, null);
            } else {
                Color base = colorForTitle(title);
                Color deep = darker(base, 110);
                g2.setPaint(new GradientPaint(0, 0, deep, w, h, new Color(8, 12, 22)));
                g2.fillRoundRect(0, 0, w, h, 24, 24);
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.22f));
                for (int i = 0; i < 9; i++) {
                    int x = (Math.abs(title.hashCode()) + i * 147) % Math.max(1, w);
                    int y = 30 + (i * 49) % Math.max(1, h - 90);
                    g2.setColor(i % 2 == 0 ? Color.WHITE : base.brighter());
                    g2.fillOval(x - 50, y, 150 - i * 5, 85);
                }
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                g2.setColor(new Color(255, 255, 255, 35));
                for (int x = w / 2; x < w; x += 58) {
                    g2.drawRoundRect(x, 35, 38, h - 80, 10, 10);
                }
                g2.setColor(new Color(0, 0, 0, 90));
                g2.fillRoundRect(w / 2 + 40, 72, 260, 150, 18, 18);
                g2.setColor(RED);
                g2.fillOval(w / 2 + 145, 110, 70, 70);
                g2.setColor(Color.WHITE);
                int[] px = {w / 2 + 173, w / 2 + 173, w / 2 + 202};
                int[] py = {130, 160, 145};
                g2.fillPolygon(px, py, 3);
            }
                if (secondary != null && blend > 0f) {
                g2.setComposite(java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.SRC_OVER, blend));
                g2.drawImage(secondary, 0, 0, w, h, null);
                g2.setComposite(java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.SRC_OVER, 1f));
            }
            g2.setPaint(new GradientPaint(0, 0, new Color(0, 0, 0, 230), w / 2, 0, new Color(0, 0, 0, 35)));
            g2.fillRoundRect(0, 0, w, h, 24, 24);
            g2.setColor(new Color(255, 255, 255, 28));
            g2.drawRoundRect(0, 0, w - 1, h - 1, 24, 24);
            g2.dispose();
        }
    }

    private void saveWatch(int contentId, int percent, boolean done) {
        int minutes = Math.max(1, percent);
        update("INSERT INTO HistoriqueVisionnage(id_utilisateur, id_contenu, progression_minutes, termine) VALUES (?, ?, ?, ?)",
            currentUserId, contentId, minutes, done);
    }

    private static class Db {
        private static String host = "localhost";
        private static String port = "3306";
        private static String database = "flix_first";
        private static String user = "flixapp";
        private static String password = "flixfirst";

        static void configure(String h, String p, String db, String u, String pass) {
            host = h; port = p; database = db; user = u; password = pass;
        }

        static Connection connect() throws SQLException {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException("Driver MySQL introuvable : ajoutez lib/mysql-connector-j-9.7.0.jar au Build Path.", e);
            }
            String url = "jdbc:mysql://" + host + ":" + port + "/" + database + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
            return DriverManager.getConnection(url, user, password);
        }

        static Connection connectServer() throws SQLException {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException("Driver MySQL introuvable : ajoutez lib/mysql-connector-j-9.7.0.jar au Build Path.", e);
            }
            String url = "jdbc:mysql://" + host + ":" + port + "/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
            return DriverManager.getConnection(url, user, password);
        }

        static void installSchema() throws SQLException {
            Path script = Path.of("sql", "flix_first_mysql.sql");
            if (!Files.exists(script)) {
                throw new SQLException("Script introuvable : " + script.toAbsolutePath());
            }
            try (Connection connection = connectServer()) {
                runScript(connection, script);
            } catch (Exception e) {
                if (e instanceof SQLException sqlException) {
                    throw sqlException;
                }
                throw new SQLException("Impossible d'executer le script MySQL.", e);
            }
        }

        static void ensureProfilesTable() throws SQLException {
            try (Connection connection = connect(); Statement st = connection.createStatement()) {
                st.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS Profil (
                        id_profil INT AUTO_INCREMENT PRIMARY KEY,
                        pseudo VARCHAR(80) NOT NULL,
                        avatar VARCHAR(255) DEFAULT NULL,
                        id_utilisateur INT NOT NULL,
                        CONSTRAINT fk_profil_utilisateur
                            FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
                            ON DELETE CASCADE
                    )
                    """);
                st.executeUpdate("""
                    INSERT INTO Profil (pseudo, avatar, id_utilisateur)
                    SELECT COALESCE(NULLIF(prenom, ''), 'Profil'), NULL, id_utilisateur
                    FROM Utilisateur u
                    WHERE NOT EXISTS (
                        SELECT 1
                        FROM Profil p
                        WHERE p.id_utilisateur = u.id_utilisateur
                    )
                    """);
            }
        }

        private static void runScript(Connection connection, Path script) throws Exception {
            List<String> lines = Files.readAllLines(script, StandardCharsets.UTF_8);
            String delimiter = ";";
            StringBuilder statement = new StringBuilder();
            try (Statement st = connection.createStatement()) {
                for (String rawLine : lines) {
                    String line = rawLine.trim();
                    if (line.isBlank() || line.startsWith("--")) {
                        continue;
                    }
                    if (line.toUpperCase().startsWith("DELIMITER ")) {
                        delimiter = line.substring("DELIMITER ".length()).trim();
                        continue;
                    }
                    statement.append(rawLine).append("\n");
                    if (line.endsWith(delimiter)) {
                        int end = statement.lastIndexOf(delimiter);
                        String sql = statement.substring(0, end).trim();
                        statement.setLength(0);
                        if (!sql.isBlank()) {
                            st.execute(sql);
                        }
                    }
                }
                String remaining = statement.toString().trim();
                if (!remaining.isBlank()) {
                    st.execute(remaining);
                }
            }
        }
    }

    private record IdLabel(int id, String label) {
        @Override public String toString() { return label; }
    }

    private record CatalogItem(int id, String title, String type, String year, String genres, String detail, String note) {
    }

    @FunctionalInterface
    private interface RowReader {
        void read(ResultSet rs) throws SQLException;
    }

    private class SmallLogo extends JPanel {
        SmallLogo() {
            setOpaque(false);
            setPreferredSize(new Dimension(190, 82));
            setMaximumSize(new Dimension(190, 82));
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(RED);
            g2.fillRoundRect(0, 6, 48, 48, 16, 16);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 30));
            g2.drawString("F", 16, 42);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 24));
            g2.drawString("Flix", 58, 30);
            g2.setColor(GOLD);
            g2.drawString("First", 58, 57);
            g2.dispose();
        }
    }

    private class LogoHero extends JPanel {
        private final String title;
        private final String subtitle;
        LogoHero(String title, String subtitle) {
            this.title = title;
            this.subtitle = subtitle;
            setPreferredSize(new Dimension(1000, 140));
            setOpaque(false);
            // static hero: remove continuous animation for a professional look
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            g2.setPaint(new GradientPaint(0, 0, new Color(34, 40, 52), w, h, new Color(18, 24, 34)));
            g2.fillRoundRect(0, 0, w, h, 18, 18);
            // subtle highlight
            g2.setColor(new Color(255, 255, 255, 18));
            g2.fillOval(w - 180, 12, 140, 60);
            g2.setColor(RED);
            g2.fillRoundRect(34, 42, 68, 68, 18, 18);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 40));
            g2.drawString("F", 54, 86);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 30));
            g2.drawString(title, 118, 66);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            g2.setColor(new Color(225, 230, 240));
            g2.drawString(subtitle, 120, 92);
            g2.setColor(GOLD);
            g2.fillRoundRect(120, 110, 160, 8, 8, 8);
            g2.dispose();
        }
    }

    private class PlayerCanvas extends JPanel {
        private final String title;
        private int phase = 0;
        private boolean playing = false;
        private final Timer animation;

        PlayerCanvas(String title) {
            this.title = title;
            setOpaque(false);
            animation = new Timer(45, e -> {
                if (playing) {
                    phase = (phase + 5) % 3600;
                } else {
                    phase = (phase + 1) % 3600;
                }
                repaint();
            });
        }

        void setPlaying(boolean playing) {
            this.playing = playing;
            repaint();
        }

        @Override public void addNotify() {
            super.addNotify();
            animation.start();
        }

        @Override public void removeNotify() {
            animation.stop();
            super.removeNotify();
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            Color base = colorForTitle(title);
            Color deep = darker(base, 115);
            g2.setColor(Color.BLACK);
            g2.fillRoundRect(0, 0, w, h, 18, 18);

            int screenX = 16;
            int screenY = 16;
            int screenW = w - 32;
            int screenH = h - 72;
            g2.setPaint(new GradientPaint(0, screenY, deep, screenW, screenH, base));
            g2.fillRoundRect(screenX, screenY, screenW, screenH, 16, 16);

            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.22f));
            for (int i = 0; i < 12; i++) {
                int x = (phase * (i + 1) / 2 + i * 113) % Math.max(1, screenW + 180) - 90;
                int y = screenY + 30 + (i * 37) % Math.max(1, screenH - 90);
                g2.setColor(i % 2 == 0 ? Color.WHITE : base.brighter());
                g2.fillOval(x, y, 150 - (i % 5) * 12, 70 + (i % 4) * 15);
            }
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));

            g2.setColor(new Color(0, 0, 0, 95));
            g2.fillRect(screenX, screenY, screenW, 54);
            g2.fillRect(screenX, screenY + screenH - 64, screenW, 64);

            g2.setColor(new Color(255, 255, 255, 45));
            g2.setStroke(new BasicStroke(2f));
            int horizon = screenY + screenH / 2 + (int) (Math.sin(phase / 25.0) * 14);
            g2.drawLine(screenX + 35, horizon, screenX + screenW - 35, horizon - 30);
            g2.drawOval(screenX + screenW - 230, screenY + 75, 150, 150);
            g2.drawLine(screenX + 70, screenY + screenH - 110, screenX + 250, screenY + 100);

            if (!playing) {
                g2.setColor(new Color(0, 0, 0, 110));
                g2.fillRoundRect(w / 2 - 58, h / 2 - 75, 116, 116, 58, 58);
                g2.setColor(RED);
                g2.fillOval(w / 2 - 48, h / 2 - 65, 96, 96);
                g2.setColor(Color.WHITE);
                int[] x = {w / 2 - 13, w / 2 - 13, w / 2 + 27};
                int[] y = {h / 2 - 37, h / 2 + 5, h / 2 - 16};
                g2.fillPolygon(x, y, 3);
            }

            g2.setFont(new Font("Segoe UI", Font.BOLD, 24));
            g2.setColor(Color.WHITE);
            g2.drawString(title, screenX + 24, screenY + screenH - 28);

            g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g2.setColor(new Color(238, 242, 255));
            g2.drawString(playing ? "LECTURE EN COURS" : "PRET A LANCER", screenX + 24, screenY + 34);
            g2.setColor(RED);
            int live = 90 + (phase % Math.max(1, screenW - 140));
            g2.fillRoundRect(screenX + 24, h - 36, live, 7, 7, 7);
            g2.setColor(new Color(255, 255, 255, 55));
            g2.fillRoundRect(screenX + 24, h - 36, screenW - 48, 7, 7, 7);
            g2.setColor(RED);
            g2.fillRoundRect(screenX + 24, h - 36, live, 7, 7, 7);
            g2.dispose();
        }
    }
}
