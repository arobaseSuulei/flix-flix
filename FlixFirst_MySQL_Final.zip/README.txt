============================================================
FLIX FIRST - Projet BDD Streaming avec MySQL Workbench
============================================================

SGBD : MySQL
Outil BD : MySQL Workbench
Application : Java Swing
Driver JDBC inclus : lib/mysql-connector-j-9.7.0.jar

Compte demo dans l'application :
Email : demo@flixfirst.com
Mot de passe : demo123

------------------------------------------------------------
1. CREER LA BASE DANS MYSQL WORKBENCH
------------------------------------------------------------

1. Ouvre MySQL Workbench.
2. Connecte-toi a ton serveur MySQL local.
3. File > Open SQL Script.
4. Ouvre :
   sql/flix_first_mysql.sql
5. Clique sur l'eclair pour executer tout le script.
6. Dans le panneau de gauche, clique Refresh.
7. Tu dois voir la base :
   flix_first

Le script cree toutes les tables, les contraintes et les donnees :
- utilisateurs
- formules d'abonnement
- abonnements
- catalogue
- films
- series
- saisons
- episodes
- genres
- acteurs, realisateurs, producteurs
- historique
- evaluations
- ma liste

------------------------------------------------------------
2. IMPORTER DANS ECLIPSE
------------------------------------------------------------

1. Ouvre Eclipse.
2. File > Import.
3. General > Existing Projects into Workspace.
4. Selectionne le dossier :
   C:\Users\Lenovo\Downloads\FlixFirst_MySQL_Final
5. Finish.
6. Clic droit sur le projet > Refresh.
7. Clic droit > Build Path > Configure Build Path > Libraries.
8. Verifie que cette ligne existe :
   lib/mysql-connector-j-9.7.0.jar
9. Lance :
   src/flixfirst/FlixFirstApp.java
   Run As > Java Application.

Option rapide sans Eclipse :
double-clique sur run_flix_first.bat.

Dans le premier ecran de l'application :
- Serveur : localhost
- Port : 3306
- Base : flix_first
- Utilisateur MySQL : flixapp
- Mot de passe MySQL : flixfirst

Sur ce PC, un utilisateur MySQL special application a ete cree :
Utilisateur : flixapp
Mot de passe : flixfirst

Utilise aussi ce compte dans MySQL Workbench si le compte root affiche
"Access denied".

Si l'application affiche "Unknown database 'flix_first'", elle proposera de
creer la base automatiquement. Clique Oui. Cela execute le script
sql/flix_first_mysql.sql depuis l'application.

Ensuite connecte-toi avec :
demo@flixfirst.com / demo123

------------------------------------------------------------
3. LANCER DANS VSCODE
------------------------------------------------------------

1. Ouvre le dossier FlixFirst_MySQL_Final dans VSCode.
2. Installe l'extension "Extension Pack for Java" si besoin.
3. Verifie que le fichier lib/mysql-connector-j-9.7.0.jar est present.
4. Dans un terminal VSCode :

   javac -encoding UTF-8 -d bin src/flixfirst/FlixFirstApp.java
   java -cp "bin;lib/mysql-connector-j-9.7.0.jar" flixfirst.FlixFirstApp

Sur Ubuntu/Linux :

   javac -encoding UTF-8 -d bin src/flixfirst/FlixFirstApp.java
   java -cp "bin:lib/mysql-connector-j-9.7.0.jar" flixfirst.FlixFirstApp

------------------------------------------------------------
4. SCENARIO DE DEMONSTRATION
------------------------------------------------------------

1. Ouvrir MySQL Workbench.
2. Executer sql/flix_first_mysql.sql.
3. Ouvrir Eclipse et lancer FlixFirstApp.
4. Se connecter a MySQL depuis l'application.
5. Se connecter avec le compte demo.
6. Montrer le catalogue.
7. Cliquer sur un film et montrer :
   - fiche
   - genres
   - casting
   - realisateur/producteur
8. Cliquer sur Regarder.
9. Lancer la lecture simulee puis terminer.
10. Aller dans Historique.
11. Ajouter un contenu a Ma liste.
12. Noter un contenu.
13. Aller dans SQL et montrer :
   - Relations
   - Film / Serie

------------------------------------------------------------
5. LIVRABLES POUR LA PROF
------------------------------------------------------------

A fournir :
- src/
- sql/flix_first_mysql.sql
- sql/demo_queries_mysql.sql
- lib/mysql-connector-j-9.7.0.jar
- assets/flix_first_logo.svg
- README.txt
- run_flix_first.bat
- RAPPORT_FlixFirst_MySQL.pdf
- video de presentation

Phrase utile :
"Flix First est une application Java Swing connectee a MySQL. Le schema relationnel
respecte les contraintes du projet : cles primaires, cles etrangeres, contraintes
UNIQUE, CHECK, specialisation ISA Contenu vers Film et Serie, relations N:M pour
les genres et les personnes, historique de visionnage et evaluation."
