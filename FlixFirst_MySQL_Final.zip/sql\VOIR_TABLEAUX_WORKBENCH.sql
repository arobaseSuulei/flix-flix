USE flix_first;

-- FICHIER A UTILISER POUR VOIR LES TABLEAUX DANS MYSQL WORKBENCH
-- Ce fichier ne supprime rien et ne cree rien.
-- Il sert seulement a afficher les donnees.

-- 1. Voir toutes les tables de la base
SHOW TABLES;

-- 2. Voir le catalogue complet
SELECT *
FROM Contenu
ORDER BY id_contenu;

-- 3. Voir les films
SELECT c.id_contenu, c.titre, c.annee_sortie,
       f.duree_minutes, f.realisateur, f.producteur
FROM Contenu c
JOIN Film f ON f.id_contenu = c.id_contenu
ORDER BY c.titre;

-- 4. Voir les series
SELECT c.id_contenu, c.titre, c.annee_sortie,
       s.createur, s.nb_saisons
FROM Contenu c
JOIN Serie s ON s.id_contenu = c.id_contenu
ORDER BY c.titre;

-- 5. Voir les saisons et episodes
SELECT c.titre AS serie, sa.numero_saison,
       e.numero_episode, e.titre AS episode, e.duree_minutes
FROM Contenu c
JOIN Serie s ON s.id_contenu = c.id_contenu
JOIN Saison sa ON sa.id_contenu = s.id_contenu
JOIN Episode e ON e.id_saison = sa.id_saison
ORDER BY c.titre, sa.numero_saison, e.numero_episode;

-- 6. Voir les genres par contenu
SELECT c.titre, g.nom AS genre
FROM Contenu c
JOIN ContenuGenre cg ON cg.id_contenu = c.id_contenu
JOIN Genre g ON g.id_genre = cg.id_genre
ORDER BY c.titre, g.nom;

-- 7. Voir les acteurs
SELECT c.titre, p.nom_complet AS acteur, cp.role_personnage
FROM ContenuPersonne cp
JOIN Contenu c ON c.id_contenu = cp.id_contenu
JOIN Personne p ON p.id_personne = cp.id_personne
WHERE cp.participation = 'acteur'
ORDER BY c.titre, p.nom_complet;

-- 8. Voir les realisateurs
SELECT c.titre, p.nom_complet AS realisateur
FROM ContenuPersonne cp
JOIN Contenu c ON c.id_contenu = cp.id_contenu
JOIN Personne p ON p.id_personne = cp.id_personne
WHERE cp.participation = 'realisateur'
ORDER BY c.titre, p.nom_complet;

-- 9. Voir l'historique des visionnages
SELECT u.email, c.titre, h.date_visionnage,
       h.progression_minutes, h.termine
FROM HistoriqueVisionnage h
JOIN Utilisateur u ON u.id_utilisateur = h.id_utilisateur
JOIN Contenu c ON c.id_contenu = h.id_contenu
ORDER BY h.date_visionnage DESC;

-- 10. Voir les notes
SELECT u.email, c.titre, e.note, e.date_evaluation
FROM Evaluation e
JOIN Utilisateur u ON u.id_utilisateur = e.id_utilisateur
JOIN Contenu c ON c.id_contenu = e.id_contenu
ORDER BY e.date_evaluation DESC, c.titre;
