package streamdb.ui;

import streamdb.dao.ContenuDAO;
import streamdb.dao.MaListeDAO;
import streamdb.dao.ProfilDAO;
import streamdb.dao.VisionnageDAO;
import streamdb.model.Contenu;
import streamdb.model.Profil;
import streamdb.model.Visionnage;
import streamdb.util.ConsoleHelper;

import java.sql.SQLException;
import java.util.List;

public class MenuVisionnage {

    private final VisionnageDAO vDao     = new VisionnageDAO();
    private final MaListeDAO    mlDao    = new MaListeDAO();
    private final ContenuDAO    cDao     = new ContenuDAO();
    private final ProfilDAO     pDao     = new ProfilDAO();

    public void show() {
        while (true) {
            ConsoleHelper.printMenu("ESPACE PROFIL — VISIONNAGE", new String[]{
                "Voir mon historique de visionnage",
                "Regarder un film",
                "Regarder un épisode de série",
                "Ma Liste — voir mes sauvegardes",
                "Ma Liste — ajouter un contenu",
                "Ma Liste — retirer un contenu"
            });
            int choix = ConsoleHelper.readInt("  Votre choix : ");
            switch (choix) {
                case 1 -> historique();
                case 2 -> regarderFilm();
                case 3 -> regarderEpisode();
                case 4 -> voirMaListe();
                case 5 -> ajouterMaListe();
                case 6 -> retirerMaListe();
                case 0 -> { return; }
                default -> ConsoleHelper.error("Choix invalide.");
            }
        }
    }

    private int selectionnerProfil() throws SQLException {
        // Liste tous les profils pour choisir
        System.out.println("  (Entrez l'ID de votre profil)");
        return ConsoleHelper.readInt("  ID profil : ");
    }

    // ── Historique ────────────────────────────────────────────
    private void historique() {
        try {
            int idProfil = selectionnerProfil();
            Profil p = pDao.findById(idProfil);
            if (p == null) { ConsoleHelper.error("Profil introuvable."); ConsoleHelper.pause(); return; }

            List<Visionnage> list = vDao.findByProfil(idProfil);
            ConsoleHelper.printTitle("HISTORIQUE DE " + p.getPseudo());
            if (list.isEmpty()) ConsoleHelper.info("Aucun visionnage enregistré.");
            else list.forEach(v -> System.out.println("  " + v));
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    // ── Regarder un film ──────────────────────────────────────
    private void regarderFilm() {
        try {
            int idProfil = selectionnerProfil();
            ConsoleHelper.printTitle("FILMS DISPONIBLES");
            List<Contenu> films = cDao.findFilms();
            films.forEach(f -> System.out.printf("  [%3d] %-40s (%d) | %d min%n",
                    f.getIdContenu(), f.getTitre(), f.getAnnee(),
                    f.getDuree() != null ? f.getDuree() : 0));

            int idFilm = ConsoleHelper.readInt("  ID du film à regarder : ");
            int progression = ConsoleHelper.readInt("  Progression actuelle (secondes, 0 pour démarrer) : ");

            if (vDao.upsertFilm(idProfil, idFilm, progression))
                ConsoleHelper.ok("Visionnage enregistré à " + formatSeconds(progression) + ".");
            else
                ConsoleHelper.error("Erreur d'enregistrement.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    // ── Regarder un épisode ───────────────────────────────────
    private void regarderEpisode() {
        try {
            int idProfil = selectionnerProfil();
            ConsoleHelper.printTitle("SÉRIES DISPONIBLES");
            List<Contenu> series = cDao.findSeries();
            series.forEach(s -> System.out.printf("  [%3d] %-40s (%d saison(s))%n",
                    s.getIdContenu(), s.getTitre(), s.getNbSaisons() != null ? s.getNbSaisons() : 0));

            int idSerie = ConsoleHelper.readInt("  ID de la série : ");
            cDao.printEpisodes(idSerie);

            int idEpisode  = ConsoleHelper.readInt("  ID de l'épisode à regarder : ");
            int progression = ConsoleHelper.readInt("  Progression (secondes, 0 pour démarrer) : ");

            if (vDao.upsertEpisode(idProfil, idEpisode, progression))
                ConsoleHelper.ok("Visionnage enregistré à " + formatSeconds(progression) + ".");
            else
                ConsoleHelper.error("Erreur d'enregistrement.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    // ── Ma Liste ──────────────────────────────────────────────
    private void voirMaListe() {
        try {
            int idProfil = selectionnerProfil();
            List<Contenu> list = mlDao.findByProfil(idProfil);
            ConsoleHelper.printTitle("MA LISTE (profil " + idProfil + ")");
            if (list.isEmpty()) ConsoleHelper.info("Votre liste est vide.");
            else list.forEach(c -> System.out.println("  " + c));
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void ajouterMaListe() {
        try {
            int idProfil  = selectionnerProfil();
            int idContenu = ConsoleHelper.readInt("  ID du contenu à ajouter à Ma Liste : ");
            if (mlDao.add(idProfil, idContenu)) ConsoleHelper.ok("Ajouté à Ma Liste !");
            else                                ConsoleHelper.info("Déjà dans Ma Liste.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void retirerMaListe() {
        try {
            int idProfil  = selectionnerProfil();
            voirMaListeSilent(idProfil);
            int idContenu = ConsoleHelper.readInt("  ID du contenu à retirer : ");
            if (mlDao.remove(idProfil, idContenu)) ConsoleHelper.ok("Retiré de Ma Liste.");
            else                                   ConsoleHelper.error("Contenu introuvable dans votre liste.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void voirMaListeSilent(int idProfil) throws SQLException {
        List<Contenu> list = mlDao.findByProfil(idProfil);
        list.forEach(c -> System.out.printf("  [%d] %s%n", c.getIdContenu(), c.getTitre()));
    }

    private String formatSeconds(int s) {
        return String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
    }
}
