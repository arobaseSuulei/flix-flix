package streamdb.dao;

import streamdb.model.Plan;
import streamdb.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlanDAO {

    // ── Lire tous les plans ────────────────────────────────────
    public List<Plan> findAll() throws SQLException {
        List<Plan> plans = new ArrayList<>();
        String sql = "SELECT idPlan, libelle, prixMensuel, qualiteMax, nbProfilsMax FROM Plan ORDER BY prixMensuel";
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                plans.add(map(rs));
            }
        }
        return plans;
    }

    // ── Lire un plan par id ────────────────────────────────────
    public Plan findById(int id) throws SQLException {
        String sql = "SELECT idPlan, libelle, prixMensuel, qualiteMax, nbProfilsMax FROM Plan WHERE idPlan = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    // ── Créer un plan ──────────────────────────────────────────
    public boolean create(Plan p) throws SQLException {
        String sql = "INSERT INTO Plan (libelle, prixMensuel, qualiteMax, nbProfilsMax) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, p.getLibelle());
            ps.setDouble(2, p.getPrixMensuel());
            ps.setString(3, p.getQualiteMax());
            ps.setInt(4, p.getNbProfilsMax());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Mettre à jour un plan ──────────────────────────────────
    public boolean update(Plan p) throws SQLException {
        String sql = "UPDATE Plan SET libelle=?, prixMensuel=?, qualiteMax=?, nbProfilsMax=? WHERE idPlan=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, p.getLibelle());
            ps.setDouble(2, p.getPrixMensuel());
            ps.setString(3, p.getQualiteMax());
            ps.setInt(4, p.getNbProfilsMax());
            ps.setInt(5, p.getIdPlan());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Supprimer un plan ──────────────────────────────────────
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM Plan WHERE idPlan = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Plan map(ResultSet rs) throws SQLException {
        return new Plan(
            rs.getInt("idPlan"),
            rs.getString("libelle"),
            rs.getDouble("prixMensuel"),
            rs.getString("qualiteMax"),
            rs.getInt("nbProfilsMax")
        );
    }
}
