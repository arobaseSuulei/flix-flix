-- ============================================================
-- StreamDB - Requetes de demonstration pour pgAdmin
-- A executer apres sql/streamdb_pgadmin.sql
-- ============================================================

-- 1) Verifier que chaque relation contient au moins 5 tuples.
SELECT 'Plan' AS relation, COUNT(*) AS tuples FROM Plan
UNION ALL SELECT 'Pays', COUNT(*) FROM Pays
UNION ALL SELECT 'Genre', COUNT(*) FROM Genre
UNION ALL SELECT 'Compte', COUNT(*) FROM Compte
UNION ALL SELECT 'Profil', COUNT(*) FROM Profil
UNION ALL SELECT 'Contenu', COUNT(*) FROM Contenu
UNION ALL SELECT 'Film', COUNT(*) FROM Film
UNION ALL SELECT 'Serie', COUNT(*) FROM Serie
UNION ALL SELECT 'Saison', COUNT(*) FROM Saison
UNION ALL SELECT 'Episode', COUNT(*) FROM Episode
UNION ALL SELECT 'ContenuGenre', COUNT(*) FROM ContenuGenre
UNION ALL SELECT 'ContenuLangue', COUNT(*) FROM ContenuLangue
UNION ALL SELECT 'VisionnageFilm', COUNT(*) FROM VisionnageFilm
UNION ALL SELECT 'Visionnage', COUNT(*) FROM Visionnage
UNION ALL SELECT 'MaListe', COUNT(*) FROM MaListe
ORDER BY relation;

-- 2) Catalogue final : film ou serie, pays, genres et informations de sous-classe.
SELECT c.idContenu, c.type, c.titre, c.annee, p.nom AS pays,
       COALESCE(STRING_AGG(DISTINCT g.libelle, ', ' ORDER BY g.libelle), '-') AS genres,
       f.realisateur,
       s.createur,
       s.nbSaisons
FROM Contenu c
JOIN Pays p ON p.idPays = c.idPays
LEFT JOIN ContenuGenre cg ON cg.idContenu = c.idContenu
LEFT JOIN Genre g ON g.idGenre = cg.idGenre
LEFT JOIN Film f ON f.idContenu = c.idContenu
LEFT JOIN Serie s ON s.idContenu = c.idContenu
GROUP BY c.idContenu, c.type, c.titre, c.annee, p.nom,
         f.realisateur, s.createur, s.nbSaisons
ORDER BY c.type, c.titre;

-- 3) Profils par compte : illustre la contrainte de limite par plan.
SELECT c.email, p.libelle AS plan, p.nbProfilsMax,
       COUNT(pr.idProfil) AS nbProfilsActuels
FROM Compte c
JOIN Plan p ON p.idPlan = c.idPlan
LEFT JOIN Profil pr ON pr.idCompte = c.idCompte
GROUP BY c.email, p.libelle, p.nbProfilsMax
ORDER BY c.email;

-- 4) Historique complet d'un profil : films + episodes.
-- Remplacer 1 par l'idProfil souhaite.
SELECT dateDebut, typeCible, titreAffiche, progression
FROM (
    SELECT vf.dateDebut,
           'film' AS typeCible,
           c.titre AS titreAffiche,
           vf.progression
    FROM VisionnageFilm vf
    JOIN Contenu c ON c.idContenu = vf.idContenu
    WHERE vf.idProfil = 1

    UNION ALL

    SELECT v.dateDebut,
           'episode' AS typeCible,
           c.titre || ' S' || s.numero || 'E' || e.numero || ' - ' || e.titre AS titreAffiche,
           v.progression
    FROM Visionnage v
    JOIN Episode e ON e.idEpisode = v.idEpisode
    JOIN Saison s ON s.idSaison = e.idSaison
    JOIN Contenu c ON c.idContenu = s.idContenu
    WHERE v.idProfil = 1
) h
ORDER BY dateDebut DESC;

-- 5) Controle de la specialisation ISA Film / Serie.
-- Chaque contenu doit avoir exactement une ligne dans Film OU dans Serie.
SELECT c.idContenu, c.titre, c.type,
       CASE WHEN f.idContenu IS NOT NULL THEN 1 ELSE 0 END AS est_film,
       CASE WHEN s.idContenu IS NOT NULL THEN 1 ELSE 0 END AS est_serie
FROM Contenu c
LEFT JOIN Film f ON f.idContenu = c.idContenu
LEFT JOIN Serie s ON s.idContenu = c.idContenu
ORDER BY c.idContenu;
