package streamdb.ui;

import streamdb.dao.PlanDAO;
import streamdb.model.Plan;
import streamdb.util.ConsoleHelper;

import java.sql.SQLException;
import java.util.List;

public class MenuPlans {

    private final PlanDAO dao = new PlanDAO();

    public void show() {
        while (true) {
            ConsoleHelper.printMenu("GESTION DES PLANS D'ABONNEMENT", new String[]{
                "Lister tous les plans",
                "Ajouter un plan",
                "Modifier un plan",
                "Supprimer un plan"
            });
            int choix = ConsoleHelper.readInt("  Votre choix : ");
            switch (choix) {
                case 1 -> lister();
                case 2 -> ajouter();
                case 3 -> modifier();
                case 4 -> supprimer();
                case 0 -> { return; }
                default -> ConsoleHelper.error("Choix invalide.");
            }
        }
    }

    private void lister() {
        try {
            List<Plan> plans = dao.findAll();
            ConsoleHelper.printTitle("PLANS D'ABONNEMENT");
            if (plans.isEmpty()) { ConsoleHelper.info("Aucun plan enregistré."); }
            else plans.forEach(p -> System.out.println("  " + p));
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void ajouter() {
        ConsoleHelper.printTitle("AJOUTER UN PLAN");
        Plan p = new Plan();
        p.setLibelle(ConsoleHelper.readLine("  Libellé (ex: Premium) : "));
        p.setPrixMensuel(ConsoleHelper.readDouble("  Prix mensuel (€) : "));
        String q;
        do {
            q = ConsoleHelper.readLine("  Qualité max [SD / HD / 4K] : ").toUpperCase();
        } while (!q.equals("SD") && !q.equals("HD") && !q.equals("4K"));
        p.setQualiteMax(q);
        p.setNbProfilsMax(ConsoleHelper.readInt("  Nombre max de profils (1-5) : "));
        try {
            if (dao.create(p)) ConsoleHelper.ok("Plan créé avec succès !");
            else               ConsoleHelper.error("Échec de la création.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void modifier() {
        ConsoleHelper.printTitle("MODIFIER UN PLAN");
        lister();
        int id = ConsoleHelper.readInt("  ID du plan à modifier : ");
        try {
            Plan p = dao.findById(id);
            if (p == null) { ConsoleHelper.error("Plan introuvable."); ConsoleHelper.pause(); return; }
            System.out.println("  Plan actuel : " + p);
            p.setLibelle(ConsoleHelper.readLine("  Nouveau libellé [" + p.getLibelle() + "] : "));
            p.setPrixMensuel(ConsoleHelper.readDouble("  Nouveau prix : "));
            String q;
            do { q = ConsoleHelper.readLine("  Qualité [SD/HD/4K] : ").toUpperCase(); }
            while (!q.equals("SD") && !q.equals("HD") && !q.equals("4K"));
            p.setQualiteMax(q);
            p.setNbProfilsMax(ConsoleHelper.readInt("  Nb profils max : "));
            if (dao.update(p)) ConsoleHelper.ok("Plan mis à jour !");
            else               ConsoleHelper.error("Échec de la mise à jour.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void supprimer() {
        ConsoleHelper.printTitle("SUPPRIMER UN PLAN");
        lister();
        int id = ConsoleHelper.readInt("  ID du plan à supprimer : ");
        boolean conf = ConsoleHelper.readBoolean("  Confirmer la suppression");
        if (!conf) { ConsoleHelper.info("Annulé."); ConsoleHelper.pause(); return; }
        try {
            if (dao.delete(id)) ConsoleHelper.ok("Plan supprimé.");
            else                ConsoleHelper.error("Plan introuvable ou suppression impossible.");
        } catch (SQLException e) { ConsoleHelper.error("Impossible : " + e.getMessage()); }
        ConsoleHelper.pause();
    }
}
