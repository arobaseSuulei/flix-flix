from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


OUTPUT = "rapport_streamdb.pdf"


styles = getSampleStyleSheet()
styles.add(
    ParagraphStyle(
        name="CoverTitle",
        parent=styles["Title"],
        fontName="Helvetica-Bold",
        fontSize=28,
        leading=34,
        alignment=TA_CENTER,
        textColor=colors.HexColor("#111827"),
        spaceAfter=18,
    )
)
styles.add(
    ParagraphStyle(
        name="CoverSubtitle",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=13,
        leading=18,
        alignment=TA_CENTER,
        textColor=colors.HexColor("#4B5563"),
        spaceAfter=12,
    )
)
styles.add(
    ParagraphStyle(
        name="H1Custom",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=17,
        leading=21,
        textColor=colors.HexColor("#1D4ED8"),
        spaceBefore=10,
        spaceAfter=8,
    )
)
styles.add(
    ParagraphStyle(
        name="H2Custom",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=13,
        leading=16,
        textColor=colors.HexColor("#111827"),
        spaceBefore=8,
        spaceAfter=6,
    )
)
styles.add(
    ParagraphStyle(
        name="BodyCustom",
        parent=styles["BodyText"],
        fontName="Helvetica",
        fontSize=9.4,
        leading=13,
        textColor=colors.HexColor("#1F2937"),
        spaceAfter=5,
    )
)
styles.add(
    ParagraphStyle(
        name="SmallCustom",
        parent=styles["BodyText"],
        fontName="Helvetica",
        fontSize=8.2,
        leading=10.5,
        textColor=colors.HexColor("#1F2937"),
    )
)


def p(text, style="BodyCustom"):
    return Paragraph(text, styles[style])


def h1(text):
    return Paragraph(text, styles["H1Custom"])


def h2(text):
    return Paragraph(text, styles["H2Custom"])


def tbl(data, widths=None, font_size=7.4):
    converted = []
    for row in data:
        converted.append([p(str(cell), "SmallCustom") for cell in row])
    table = Table(converted, colWidths=widths, repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E5E7EB")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#111827")),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ("FONTSIZE", (0, 0), (-1, -1), font_size),
            ]
        )
    )
    return table


def bullets(items):
    flow = []
    for item in items:
        flow.append(p("- " + item))
    return flow


def add_page_number(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#6B7280"))
    canvas.drawRightString(A4[0] - 1.5 * cm, 1 * cm, f"Page {doc.page}")
    canvas.drawString(1.5 * cm, 1 * cm, "StreamDB - Projet BD")
    canvas.restoreState()


story = []

story.append(Spacer(1, 3.8 * cm))
story.append(p("StreamDB", "CoverTitle"))
story.append(p("Projet de modelisation de base de donnees", "CoverSubtitle"))
story.append(p("De la semantique a la conception relationnelle formelle", "CoverSubtitle"))
story.append(Spacer(1, 1.2 * cm))
story.append(
    tbl(
        [
            ["Element", "Choix retenu"],
            ["Application", "Plateforme de video a la demande (VOD)"],
            ["SGBD", "PostgreSQL"],
            ["Application", "Java avec interface Swing + mode console"],
            ["Specialisation", "Contenu ISA Film / Serie, disjointe et totale"],
            ["Relations finales", "15 relations"],
        ],
        [5 * cm, 9 * cm],
    )
)
story.append(PageBreak())

story.append(h1("1. Description de l'application"))
story.append(
    p(
        "StreamDB est une plateforme de video a la demande permettant a des abonnes de "
        "visionner des films et des series en streaming. Un compte client peut contenir "
        "plusieurs profils, par exemple un profil par membre de la famille. Chaque profil "
        "possede son propre historique de visionnage et sa propre liste personnelle. "
        "Le catalogue contient des films et des series, les series etant structurees en "
        "saisons puis en episodes. Les contenus sont classes par genre, rattaches a un pays "
        "d'origine, et peuvent etre disponibles dans plusieurs langues pour l'audio et les "
        "sous-titres."
    )
)
story.append(
    p(
        "Le plan d'abonnement souscrit par le compte determine les caracteristiques "
        "d'acces, notamment la qualite video maximale et le nombre de profils autorises."
    )
)

story.append(h1("2. Contraintes en langage naturel"))
constraints = [
    "Chaque compte est identifie par une adresse e-mail unique.",
    "Un compte souscrit a exactement un plan d'abonnement a la fois.",
    "Un compte peut avoir plusieurs profils, avec une limite comprise entre 1 et 5.",
    "Chaque profil appartient a exactement un compte.",
    "Un contenu est soit un film, soit une serie, jamais les deux.",
    "Une serie est composee d'une ou plusieurs saisons.",
    "Une saison contient un ou plusieurs episodes.",
    "Chaque episode appartient a exactement une saison.",
    "Un profil peut visionner plusieurs episodes ou films.",
    "Chaque visionnage est horodate et memorise la progression en secondes.",
    "Un profil peut ajouter des contenus a sa liste personnelle.",
    "Un contenu peut appartenir a plusieurs genres.",
    "Un contenu peut etre disponible en plusieurs langues pour l'audio et les sous-titres.",
    "Chaque plan definit un prix mensuel, une qualite maximale et un nombre maximal de profils.",
    "Un contenu est associe a exactement un pays d'origine.",
]
story.extend(bullets(constraints))

story.append(h1("3. Modele ER/EER"))
story.append(h2("Entites, identifiants et dependances fonctionnelles induites"))
entities = [
    ["Entite", "Attributs", "Identifiant", "DF induite"],
    ["Compte", "idCompte, email, motDePasse, dateInscription, idPlan", "idCompte", "idCompte -> email, motDePasse, dateInscription, idPlan"],
    ["Plan", "idPlan, libelle, prixMensuel, qualiteMax, nbProfilsMax", "idPlan", "idPlan -> libelle, prixMensuel, qualiteMax, nbProfilsMax"],
    ["Profil", "idProfil, pseudo, avatar, idCompte", "idProfil", "idProfil -> pseudo, avatar, idCompte"],
    ["Contenu", "idContenu, titre, annee, duree, idPays, type", "idContenu", "idContenu -> titre, annee, duree, idPays, type"],
    ["Film", "idContenu, realisateur", "idContenu", "idContenu -> realisateur"],
    ["Serie", "idContenu, createur, nbSaisons", "idContenu", "idContenu -> createur, nbSaisons"],
    ["Saison", "idSaison, numero, idContenu", "idSaison", "idSaison -> numero, idContenu"],
    ["Episode", "idEpisode, numero, titre, duree, idSaison", "idEpisode", "idEpisode -> numero, titre, duree, idSaison"],
    ["Genre", "idGenre, libelle", "idGenre", "idGenre -> libelle"],
    ["Pays", "idPays, nom", "idPays", "idPays -> nom"],
]
story.append(tbl(entities, [2.4 * cm, 5.4 * cm, 2.3 * cm, 6.2 * cm]))

story.append(h2("Specialisation ISA"))
story.append(
    p(
        "Contenu est specialise en Film et Serie. La specialisation est disjointe et "
        "totale : tout contenu est exactement un film ou exactement une serie. Elle est "
        "necessaire car un film est visionne directement, alors qu'une serie est organisee "
        "par saisons et episodes. Cette modelisation evite les attributs non applicables."
    )
)

story.append(h2("Semantique des associations"))
assoc = [
    ["Relation", "Interpretation semantique d'un tuple"],
    ["Visionnage(idProfil, idEpisode, dateDebut, progression)", "Le profil idProfil a commence l'episode idEpisode a dateDebut et s'est arrete a progression secondes."],
    ["VisionnageFilm(idProfil, idContenu, dateDebut, progression)", "Le profil idProfil a commence le film idContenu a dateDebut et s'est arrete a progression secondes."],
    ["MaListe(idProfil, idContenu, dateAjout)", "Le profil idProfil a ajoute le contenu idContenu a sa liste personnelle a dateAjout."],
    ["ContenuGenre(idContenu, idGenre)", "Le contenu idContenu appartient au genre idGenre."],
    ["ContenuLangue(idContenu, langue, typeDisponibilite)", "Le contenu idContenu est disponible dans la langue indiquee pour l'audio ou les sous-titres."],
]
story.append(tbl(assoc, [6.5 * cm, 9.8 * cm]))
story.append(PageBreak())

story.append(h1("4. Schema relationnel final"))
schema_rows = [
    ["Relation", "Cle primaire", "Cles etrangeres / contraintes principales"],
    ["Plan(idPlan, libelle, prixMensuel, qualiteMax, nbProfilsMax)", "idPlan", "UNIQUE(libelle), CHECK qualiteMax, CHECK nbProfilsMax"],
    ["Pays(idPays, nom)", "idPays", "UNIQUE(nom)"],
    ["Genre(idGenre, libelle)", "idGenre", "UNIQUE(libelle)"],
    ["Compte(idCompte, email, motDePasse, dateInscription, idPlan)", "idCompte", "UNIQUE(email), idPlan -> Plan"],
    ["Profil(idProfil, pseudo, avatar, idCompte)", "idProfil", "idCompte -> Compte"],
    ["Contenu(idContenu, titre, annee, duree, idPays, type)", "idContenu", "idPays -> Pays, CHECK type IN ('film','serie')"],
    ["Film(idContenu, realisateur)", "idContenu", "idContenu -> Contenu"],
    ["Serie(idContenu, createur, nbSaisons)", "idContenu", "idContenu -> Contenu"],
    ["Saison(idSaison, numero, idContenu)", "idSaison", "idContenu -> Serie, UNIQUE(idContenu, numero)"],
    ["Episode(idEpisode, numero, titre, duree, idSaison)", "idEpisode", "idSaison -> Saison, UNIQUE(idSaison, numero)"],
    ["ContenuGenre(idContenu, idGenre)", "(idContenu, idGenre)", "idContenu -> Contenu, idGenre -> Genre"],
    ["ContenuLangue(idContenu, langue, typeDisponibilite)", "(idContenu, langue, typeDisponibilite)", "idContenu -> Contenu, CHECK typeDisponibilite"],
    ["VisionnageFilm(idProfil, idContenu, dateDebut, progression)", "(idProfil, idContenu, dateDebut)", "idProfil -> Profil, idContenu -> Film"],
    ["Visionnage(idProfil, idEpisode, dateDebut, progression)", "(idProfil, idEpisode, dateDebut)", "idProfil -> Profil, idEpisode -> Episode"],
    ["MaListe(idProfil, idContenu, dateAjout)", "(idProfil, idContenu)", "idProfil -> Profil, idContenu -> Contenu"],
]
story.append(tbl(schema_rows, [6.2 * cm, 3.9 * cm, 6.2 * cm]))

story.append(h1("5. Systeme global de dependances"))
story.append(
    p(
        "Le systeme global F contient les DF issues des identifiants : idCompte -> email, "
        "motDePasse, dateInscription, idPlan ; idPlan -> libelle, prixMensuel, qualiteMax, "
        "nbProfilsMax ; idProfil -> pseudo, avatar, idCompte ; idContenu -> titre, annee, "
        "duree, idPays, type ; idSaison -> numero, idContenu ; idEpisode -> numero, titre, "
        "duree, idSaison ; idGenre -> libelle ; idPays -> nom. Les relations associatives "
        "ont des cles composees qui determinent leurs attributs descriptifs, par exemple "
        "(idProfil, idContenu, dateDebut) -> progression pour VisionnageFilm."
    )
)
story.append(
    p(
        "Les dependances d'inclusion correspondent aux cles etrangeres du schema final : "
        "Compte[idPlan] inclus dans Plan[idPlan], Profil[idCompte] inclus dans Compte[idCompte], "
        "Contenu[idPays] inclus dans Pays[idPays], Film[idContenu] inclus dans Contenu[idContenu], "
        "Serie[idContenu] inclus dans Contenu[idContenu], Saison[idContenu] inclus dans Serie[idContenu], "
        "Episode[idSaison] inclus dans Saison[idSaison], et de meme pour les relations associatives."
    )
)

story.append(h1("6. Normalisation"))
normalisation = [
    ["Relation", "DF pertinente", "Forme normale"],
    ["Contenu", "idContenu -> titre, annee, duree, idPays, type", "BCNF"],
    ["Film", "idContenu -> realisateur", "BCNF"],
    ["Serie", "idContenu -> createur, nbSaisons", "BCNF"],
    ["Saison", "idSaison -> numero, idContenu ; (idContenu, numero) candidat", "BCNF"],
    ["Episode", "idEpisode -> numero, titre, duree, idSaison ; (idSaison, numero) candidat", "BCNF"],
    ["ContenuGenre", "(idContenu, idGenre) est la cle", "BCNF"],
    ["ContenuLangue", "(idContenu, langue, typeDisponibilite) est la cle", "BCNF"],
    ["Visionnage / VisionnageFilm", "cle composee avec dateDebut -> progression", "BCNF"],
    ["MaListe", "(idProfil, idContenu) -> dateAjout", "BCNF"],
]
story.append(tbl(normalisation, [4.2 * cm, 8.3 * cm, 3.8 * cm]))
story.append(
    p(
        "Chaque DF non triviale projetee sur une relation a pour determinant une super-cle. "
        "Les relations finales sont donc en BCNF. Les attributs multi-values comme les genres "
        "et les langues sont separes dans des relations associatives afin d'eviter les repetitions."
    )
)

story.append(h1("7. Decomposition et anomalies"))
story.append(
    p(
        "Exemple de relation plate problematique : EpisodeAvecSerie(idEpisode, numeroEpisode, "
        "idSaison, numeroSaison, idContenu, titreSerie). On aurait notamment idEpisode -> "
        "numeroEpisode, idSaison ; idSaison -> numeroSaison, idContenu ; idContenu -> titreSerie. "
        "La dependance transitive idEpisode -> idSaison -> idContenu -> titreSerie produit des "
        "anomalies de mise a jour et de suppression."
    )
)
story.append(
    p(
        "Decomposition retenue : Episode(idEpisode, numero, titre, duree, idSaison), "
        "Saison(idSaison, numero, idContenu), Serie(idContenu, createur, nbSaisons). "
        "La jointure est sans perte car l'intersection Episode/Saison contient idSaison, "
        "qui determine les attributs de Saison ; l'intersection Saison/Serie contient idContenu, "
        "qui determine les attributs de Serie."
    )
)
story.append(PageBreak())

story.append(h1("8. Tracabilite finale"))
trace = [
    ["Contrainte", "DF / DI / contrainte SQL associee", "Preservee"],
    ["Compte identifie par email", "UNIQUE(email)", "Oui"],
    ["Un compte a un seul plan", "Compte.idPlan -> Plan.idPlan", "Oui"],
    ["Profil appartient a un compte", "Profil.idCompte -> Compte.idCompte", "Oui"],
    ["Contenu film XOR serie", "type CHECK + tables Film/Serie", "Oui"],
    ["Serie composee de saisons", "Saison.idContenu -> Serie.idContenu", "Oui"],
    ["Episode appartient a une saison", "Episode.idSaison -> Saison.idSaison", "Oui"],
    ["Visionnage horodate", "dateDebut dans les PK Visionnage et VisionnageFilm", "Oui"],
    ["Progression memorisee", "attribut progression CHECK >= 0", "Oui"],
    ["Ma Liste par profil", "MaListe(idProfil, idContenu)", "Oui"],
    ["Plusieurs genres par contenu", "ContenuGenre relation N:M", "Oui"],
    ["Langues audio/sous-titre", "ContenuLangue(idContenu, langue, typeDisponibilite)", "Oui"],
    ["Qualite maximale par plan", "Plan.qualiteMax CHECK IN ('SD','HD','4K')", "Oui"],
    ["Nombre max de profils", "Plan.nbProfilsMax CHECK BETWEEN 1 AND 5 + controle applicatif", "Oui"],
    ["Pays d'origine unique", "Contenu.idPays -> Pays.idPays", "Oui"],
]
story.append(tbl(trace, [5.5 * cm, 8.2 * cm, 2.6 * cm]))

story.append(h1("9. Implementation SQL et application"))
story.append(
    p(
        "L'implementation SQL est fournie dans sql/streamdb_pgadmin.sql. Elle contient les "
        "CREATE TABLE, les cles primaires, les cles etrangeres, les contraintes UNIQUE, NOT NULL "
        "et CHECK, puis un jeu de donnees d'au moins cinq tuples par relation. Le fichier "
        "sql/demo_queries.sql contient les requetes a presenter pendant la soutenance."
    )
)
story.append(
    p(
        "L'application Java suit une organisation simple : Main -> UI Swing ou console -> DAO -> "
        "DatabaseConnection -> PostgreSQL. Elle permet de consulter le dashboard, le catalogue, "
        "les plans, les comptes, les profils, l'historique et Ma Liste."
    )
)

story.append(h1("10. Livrables"))
story.extend(
    bullets(
        [
            "Code source Java dans src/.",
            "Script SQL complet dans sql/streamdb_pgadmin.sql.",
            "Requetes de demonstration dans sql/demo_queries.sql.",
            "README.txt avec les etapes d'installation, compilation et execution.",
            "Rapport PDF : rapport_streamdb.pdf.",
            "Video de presentation de moins de cinq minutes avec execution concrete.",
        ]
    )
)


doc = SimpleDocTemplate(
    OUTPUT,
    pagesize=A4,
    rightMargin=1.5 * cm,
    leftMargin=1.5 * cm,
    topMargin=1.4 * cm,
    bottomMargin=1.4 * cm,
)
doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
print(OUTPUT)
