package streamdb.model;

import java.time.LocalDate;

public class Compte {
    private int       idCompte;
    private String    email;
    private String    motDePasse;
    private LocalDate dateInscription;
    private int       idPlan;
    private String    libellePlan; // enrichi par jointure

    public Compte() {}

    public Compte(int idCompte, String email, String motDePasse,
                  LocalDate dateInscription, int idPlan) {
        this.idCompte        = idCompte;
        this.email           = email;
        this.motDePasse      = motDePasse;
        this.dateInscription = dateInscription;
        this.idPlan          = idPlan;
    }

    // ── Getters / Setters ──────────────────────────────────────
    public int       getIdCompte()        { return idCompte; }
    public String    getEmail()           { return email; }
    public String    getMotDePasse()      { return motDePasse; }
    public LocalDate getDateInscription() { return dateInscription; }
    public int       getIdPlan()          { return idPlan; }
    public String    getLibellePlan()     { return libellePlan; }

    public void setIdCompte(int idCompte)               { this.idCompte = idCompte; }
    public void setEmail(String email)                   { this.email = email; }
    public void setMotDePasse(String motDePasse)         { this.motDePasse = motDePasse; }
    public void setDateInscription(LocalDate d)          { this.dateInscription = d; }
    public void setIdPlan(int idPlan)                    { this.idPlan = idPlan; }
    public void setLibellePlan(String libellePlan)       { this.libellePlan = libellePlan; }

    @Override
    public String toString() {
        return String.format("[%d] %-30s | Inscrit le : %s | Plan : %s",
                idCompte, email, dateInscription, libellePlan != null ? libellePlan : String.valueOf(idPlan));
    }
}
