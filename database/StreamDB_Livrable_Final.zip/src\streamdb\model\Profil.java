package streamdb.model;

public class Profil {
    private int    idProfil;
    private String pseudo;
    private String avatar;
    private int    idCompte;

    public Profil() {}

    public Profil(int idProfil, String pseudo, String avatar, int idCompte) {
        this.idProfil = idProfil;
        this.pseudo   = pseudo;
        this.avatar   = avatar;
        this.idCompte = idCompte;
    }

    public int    getIdProfil() { return idProfil; }
    public String getPseudo()   { return pseudo; }
    public String getAvatar()   { return avatar; }
    public int    getIdCompte() { return idCompte; }

    public void setIdProfil(int idProfil)   { this.idProfil = idProfil; }
    public void setPseudo(String pseudo)     { this.pseudo = pseudo; }
    public void setAvatar(String avatar)     { this.avatar = avatar; }
    public void setIdCompte(int idCompte)    { this.idCompte = idCompte; }

    @Override
    public String toString() {
        return String.format("[%d] %-20s | Avatar : %-20s | Compte : %d",
                idProfil, pseudo, avatar != null ? avatar : "(aucun)", idCompte);
    }
}
