package streamdb.model;

public class Episode {
    private int    idEpisode;
    private int    numero;
    private String titre;
    private int    duree;
    private int    idSaison;
    private int    numeroSaison;   // enrichi
    private String titreSerie;     // enrichi

    public Episode() {}

    public int    getIdEpisode()    { return idEpisode; }
    public int    getNumero()       { return numero; }
    public String getTitre()        { return titre; }
    public int    getDuree()        { return duree; }
    public int    getIdSaison()     { return idSaison; }
    public int    getNumeroSaison() { return numeroSaison; }
    public String getTitreSerie()   { return titreSerie; }

    public void setIdEpisode(int v)    { this.idEpisode = v; }
    public void setNumero(int v)       { this.numero = v; }
    public void setTitre(String v)     { this.titre = v; }
    public void setDuree(int v)        { this.duree = v; }
    public void setIdSaison(int v)     { this.idSaison = v; }
    public void setNumeroSaison(int v) { this.numeroSaison = v; }
    public void setTitreSerie(String v){ this.titreSerie = v; }

    @Override
    public String toString() {
        return String.format("[%d] %s — S%02dE%02d : %-40s (%d min)",
                idEpisode, titreSerie != null ? titreSerie : "?",
                numeroSaison, numero, titre, duree);
    }
}
