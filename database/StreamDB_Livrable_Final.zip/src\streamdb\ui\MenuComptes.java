package streamdb.ui;

import streamdb.dao.CompteDAO;
import streamdb.dao.PlanDAO;
import streamdb.dao.ProfilDAO;
import streamdb.model.Compte;
import streamdb.model.Plan;
import streamdb.model.Profil;
import streamdb.util.ConsoleHelper;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class MenuComptes {

    private final CompteDAO  compteDAO  = new CompteDAO();
    private final PlanDAO    planDAO    = new PlanDAO();
    private final ProfilDAO  profilDAO  = new ProfilDAO();

    public void show() {
        while (true) {
            ConsoleHelper.printMenu("GESTION DES COMPTES", new String[]{
                "Lister tous les comptes",
                "Créer un compte",
                "Changer le plan d'un compte",
                "Supprimer un compte",
                "Gérer les profils d'un compte"
            });
            int choix = ConsoleHelper.readInt("  Votre choix : ");
            switch (choix) {
                case 1 -> lister();
                case 2 -> creer();
                case 3 -> changerPlan();
                case 4 -> supprimer();
                case 5 -> gererProfils();
                case 0 -> { return; }
                default -> ConsoleHelper.error("Choix invalide.");
            }
        }
    }

    // ── Lister ────────────────────────────────────────────────
    private void lister() {
        try {
            List<Compte> comptes = compteDAO.findAll();
            ConsoleHelper.printTitle("COMPTES ENREGISTRÉS");
            if (comptes.isEmpty()) ConsoleHelper.info("Aucun compte.");
            else comptes.forEach(c -> System.out.println("  " + c));
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    // ── Créer ─────────────────────────────────────────────────
    private void creer() {
        ConsoleHelper.printTitle("CRÉER UN COMPTE");
        try {
            // Afficher les plans disponibles
            List<Plan> plans = planDAO.findAll();
            System.out.println("  Plans disponibles :");
            plans.forEach(p -> System.out.println("    " + p));

            Compte c = new Compte();
            c.setEmail(ConsoleHelper.readLine("  Email : "));
            c.setMotDePasse(ConsoleHelper.readLine("  Mot de passe : "));
            c.setDateInscription(LocalDate.now());
            c.setIdPlan(ConsoleHelper.readInt("  ID du plan choisi : "));

            if (compteDAO.create(c)) ConsoleHelper.ok("Compte créé !");
            else                     ConsoleHelper.error("Échec de la création.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    // ── Changer plan ──────────────────────────────────────────
    private void changerPlan() {
        ConsoleHelper.printTitle("CHANGER LE PLAN D'UN COMPTE");
        try {
            listerSilent();
            int idCompte = ConsoleHelper.readInt("  ID du compte : ");
            List<Plan> plans = planDAO.findAll();
            System.out.println("  Plans disponibles :");
            plans.forEach(p -> System.out.println("    " + p));
            int idPlan = ConsoleHelper.readInt("  Nouvel ID de plan : ");
            if (compteDAO.updatePlan(idCompte, idPlan)) ConsoleHelper.ok("Plan mis à jour !");
            else                                        ConsoleHelper.error("Échec.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    // ── Supprimer ─────────────────────────────────────────────
    private void supprimer() {
        ConsoleHelper.printTitle("SUPPRIMER UN COMPTE");
        try {
            listerSilent();
            int id = ConsoleHelper.readInt("  ID du compte à supprimer : ");
            boolean conf = ConsoleHelper.readBoolean("  Confirmer (tous les profils seront supprimés)");
            if (!conf) { ConsoleHelper.info("Annulé."); ConsoleHelper.pause(); return; }
            if (compteDAO.delete(id)) ConsoleHelper.ok("Compte supprimé.");
            else                      ConsoleHelper.error("Introuvable.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    // ── Gérer profils ─────────────────────────────────────────
    private void gererProfils() {
        ConsoleHelper.printTitle("GESTION DES PROFILS");
        try {
            listerSilent();
            int idCompte = ConsoleHelper.readInt("  ID du compte : ");
            Compte compte = compteDAO.findById(idCompte);
            if (compte == null) { ConsoleHelper.error("Compte introuvable."); ConsoleHelper.pause(); return; }

            // Récupérer le plan pour connaître nbProfilsMax
            Plan plan = planDAO.findById(compte.getIdPlan());
            int nbMax = plan != null ? plan.getNbProfilsMax() : 5;

            while (true) {
                List<Profil> profils = profilDAO.findByCompte(idCompte);
                System.out.println("\n  Profils du compte (" + profils.size() + "/" + nbMax + ") :");
                profils.forEach(p -> System.out.println("    " + p));

                ConsoleHelper.printMenu("PROFILS — " + compte.getEmail(), new String[]{
                    "Ajouter un profil",
                    "Modifier un profil",
                    "Supprimer un profil"
                });
                int choix = ConsoleHelper.readInt("  Choix : ");
                switch (choix) {
                    case 1 -> ajouterProfil(idCompte, nbMax);
                    case 2 -> modifierProfil(profils);
                    case 3 -> supprimerProfil(profils);
                    case 0 -> { return; }
                    default -> ConsoleHelper.error("Choix invalide.");
                }
            }
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
    }

    private void ajouterProfil(int idCompte, int nbMax) throws SQLException {
        Profil p = new Profil();
        p.setIdCompte(idCompte);
        p.setPseudo(ConsoleHelper.readLine("  Pseudo : "));
        p.setAvatar(ConsoleHelper.readLine("  Avatar (fichier ou URL, laisser vide) : "));
        int newId = profilDAO.create(p, nbMax);
        if (newId == -1) ConsoleHelper.error("Limite de " + nbMax + " profils atteinte pour ce plan.");
        else             ConsoleHelper.ok("Profil créé (id=" + newId + ").");
        ConsoleHelper.pause();
    }

    private void modifierProfil(List<Profil> profils) throws SQLException {
        if (profils.isEmpty()) { ConsoleHelper.info("Aucun profil."); return; }
        int id = ConsoleHelper.readInt("  ID du profil à modifier : ");
        Profil p = profilDAO.findById(id);
        if (p == null) { ConsoleHelper.error("Profil introuvable."); return; }
        p.setPseudo(ConsoleHelper.readLine("  Nouveau pseudo [" + p.getPseudo() + "] : "));
        p.setAvatar(ConsoleHelper.readLine("  Nouvel avatar : "));
        if (profilDAO.update(p)) ConsoleHelper.ok("Profil mis à jour !");
        ConsoleHelper.pause();
    }

    private void supprimerProfil(List<Profil> profils) throws SQLException {
        if (profils.isEmpty()) { ConsoleHelper.info("Aucun profil."); return; }
        int id = ConsoleHelper.readInt("  ID du profil à supprimer : ");
        if (profilDAO.delete(id)) ConsoleHelper.ok("Profil supprimé.");
        else                      ConsoleHelper.error("Introuvable.");
        ConsoleHelper.pause();
    }

    private void listerSilent() throws SQLException {
        compteDAO.findAll().forEach(c -> System.out.println("  " + c));
    }
}
