package streamdb.dao;

import streamdb.model.Contenu;
import streamdb.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContenuDAO {

    // ── Catalogue complet (films + séries avec genres) ─────────
    public List<Contenu> findAll() throws SQLException {
        List<Contenu> list = new ArrayList<>();
        String sql = """
            SELECT c.idContenu, c.titre, c.annee, c.duree, c.idPays, c.type,
                   py.nom AS nomPays,
                   STRING_AGG(DISTINCT g.libelle, ', ' ORDER BY g.libelle) AS genres,
                   f.realisateur,
                   s.createur, s.nbSaisons
            FROM Contenu c
            JOIN Pays py ON c.idPays = py.idPays
            LEFT JOIN ContenuGenre cg ON c.idContenu = cg.idContenu
            LEFT JOIN Genre g ON cg.idGenre = g.idGenre
            LEFT JOIN Film f ON c.idContenu = f.idContenu
            LEFT JOIN Serie s ON c.idContenu = s.idContenu
            GROUP BY c.idContenu, c.titre, c.annee, c.duree, c.idPays, c.type,
                     py.nom, f.realisateur, s.createur, s.nbSaisons
            ORDER BY c.type, c.titre
            """;
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    // ── Recherche par titre (ILIKE = insensible à la casse) ────
    public List<Contenu> findByTitre(String keyword) throws SQLException {
        List<Contenu> list = new ArrayList<>();
        String sql = """
            SELECT c.idContenu, c.titre, c.annee, c.duree, c.idPays, c.type,
                   py.nom AS nomPays,
                   STRING_AGG(DISTINCT g.libelle, ', ' ORDER BY g.libelle) AS genres,
                   f.realisateur,
                   s.createur, s.nbSaisons
            FROM Contenu c
            JOIN Pays py ON c.idPays = py.idPays
            LEFT JOIN ContenuGenre cg ON c.idContenu = cg.idContenu
            LEFT JOIN Genre g ON cg.idGenre = g.idGenre
            LEFT JOIN Film f ON c.idContenu = f.idContenu
            LEFT JOIN Serie s ON c.idContenu = s.idContenu
            WHERE c.titre ILIKE ?
            GROUP BY c.idContenu, c.titre, c.annee, c.duree, c.idPays, c.type,
                     py.nom, f.realisateur, s.createur, s.nbSaisons
            ORDER BY c.titre
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    // ── Films uniquement ───────────────────────────────────────
    public List<Contenu> findFilms() throws SQLException {
        return findByType("film");
    }

    // ── Séries uniquement ──────────────────────────────────────
    public List<Contenu> findSeries() throws SQLException {
        return findByType("serie");
    }

    private List<Contenu> findByType(String type) throws SQLException {
        List<Contenu> list = new ArrayList<>();
        String sql = """
            SELECT c.idContenu, c.titre, c.annee, c.duree, c.idPays, c.type,
                   py.nom AS nomPays,
                   STRING_AGG(DISTINCT g.libelle, ', ' ORDER BY g.libelle) AS genres,
                   f.realisateur,
                   s.createur, s.nbSaisons
            FROM Contenu c
            JOIN Pays py ON c.idPays = py.idPays
            LEFT JOIN ContenuGenre cg ON c.idContenu = cg.idContenu
            LEFT JOIN Genre g ON cg.idGenre = g.idGenre
            LEFT JOIN Film f ON c.idContenu = f.idContenu
            LEFT JOIN Serie s ON c.idContenu = s.idContenu
            WHERE c.type = ?
            GROUP BY c.idContenu, c.titre, c.annee, c.duree, c.idPays, c.type,
                     py.nom, f.realisateur, s.createur, s.nbSaisons
            ORDER BY c.titre
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, type);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    // ── Créer un Film (transaction : Contenu + Film) ──────────
    public boolean createFilm(Contenu c) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        conn.setAutoCommit(false);
        try {
            int id = insertContenu(conn, c, "film");
            String sql = "INSERT INTO Film (idContenu, realisateur) VALUES (?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);
                ps.setString(2, c.getRealisateur());
                ps.executeUpdate();
            }
            insertGenres(conn, id, c.getGenres());
            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    // ── Créer une Série (transaction : Contenu + Serie) ───────
    public boolean createSerie(Contenu c) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        conn.setAutoCommit(false);
        try {
            int id = insertContenu(conn, c, "serie");
            String sql = "INSERT INTO Serie (idContenu, createur, nbSaisons) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);
                ps.setString(2, c.getCreateur());
                ps.setInt(3, c.getNbSaisons() != null ? c.getNbSaisons() : 1);
                ps.executeUpdate();
            }
            insertGenres(conn, id, c.getGenres());
            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    // ── Supprimer un contenu (cascade sur Film/Serie) ─────────
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM Contenu WHERE idContenu = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Langues disponibles d'un contenu ──────────────────────
    public void printLangues(int idContenu) throws SQLException {
        String sql = """
            SELECT langue, typeDisponibilite FROM ContenuLangue
            WHERE idContenu = ? ORDER BY langue, typeDisponibilite
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idContenu);
            try (ResultSet rs = ps.executeQuery()) {
                System.out.println("  Langues disponibles :");
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    System.out.printf("    • %-15s [%s]%n", rs.getString("langue"), rs.getString("typeDisponibilite"));
                }
                if (!found) System.out.println("    (aucune langue renseignée)");
            }
        }
    }

    // ── Épisodes d'une série ───────────────────────────────────
    public void printEpisodes(int idContenu) throws SQLException {
        String sql = """
            SELECT e.idEpisode, sa.numero AS numSaison, e.numero AS numEp, e.titre, e.duree
            FROM Episode e
            JOIN Saison sa ON e.idSaison = sa.idSaison
            WHERE sa.idContenu = ?
            ORDER BY sa.numero, e.numero
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idContenu);
            try (ResultSet rs = ps.executeQuery()) {
                System.out.println("  Épisodes :");
                int lastSaison = -1;
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    int numS = rs.getInt("numSaison");
                    if (numS != lastSaison) {
                        System.out.printf("  ── Saison %d ─────────────────────────────────────%n", numS);
                        lastSaison = numS;
                    }
                    System.out.printf("    [%d] E%02d : %-40s (%d min)%n",
                        rs.getInt("idEpisode"), rs.getInt("numEp"),
                        rs.getString("titre"), rs.getInt("duree"));
                }
                if (!found) System.out.println("    (aucun épisode enregistré)");
            }
        }
    }

    // ── helpers privés ────────────────────────────────────────
    private int insertContenu(Connection conn, Contenu c, String type) throws SQLException {
        String sql = "INSERT INTO Contenu (titre, annee, duree, idPays, type) VALUES (?, ?, ?, ?, ?) RETURNING idContenu";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getTitre());
            ps.setInt(2, c.getAnnee());
            if (c.getDuree() != null) ps.setInt(3, c.getDuree()); else ps.setNull(3, Types.INTEGER);
            ps.setInt(4, c.getIdPays());
            ps.setString(5, type);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("Impossible de créer le contenu.");
    }

    /**
     * genres : chaîne de libellés séparés par des virgules.
     * Résout les ids et insère dans ContenuGenre.
     */
    private void insertGenres(Connection conn, int idContenu, String genres) throws SQLException {
        if (genres == null || genres.isBlank()) return;
        String findGenre = "SELECT idGenre FROM Genre WHERE libelle ILIKE ?";
        String insertCG  = "INSERT INTO ContenuGenre (idContenu, idGenre) VALUES (?, ?) ON CONFLICT DO NOTHING";
        for (String g : genres.split(",")) {
            String libelle = g.trim();
            try (PreparedStatement ps = conn.prepareStatement(findGenre)) {
                ps.setString(1, libelle);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        try (PreparedStatement ps2 = conn.prepareStatement(insertCG)) {
                            ps2.setInt(1, idContenu);
                            ps2.setInt(2, rs.getInt(1));
                            ps2.executeUpdate();
                        }
                    }
                }
            }
        }
    }

    private Contenu map(ResultSet rs) throws SQLException {
        Contenu c = new Contenu();
        c.setIdContenu(rs.getInt("idContenu"));
        c.setTitre(rs.getString("titre"));
        c.setAnnee(rs.getInt("annee"));
        int duree = rs.getInt("duree");
        c.setDuree(rs.wasNull() ? null : duree);
        c.setIdPays(rs.getInt("idPays"));
        c.setType(rs.getString("type"));
        c.setNomPays(rs.getString("nomPays"));
        c.setGenres(rs.getString("genres"));
        c.setRealisateur(rs.getString("realisateur"));
        c.setCreateur(rs.getString("createur"));
        int nbS = rs.getInt("nbSaisons");
        c.setNbSaisons(rs.wasNull() ? null : nbS);
        return c;
    }
}
