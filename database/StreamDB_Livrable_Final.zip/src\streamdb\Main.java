package streamdb;

import streamdb.ui.MenuCatalogue;
import streamdb.ui.MenuComptes;
import streamdb.ui.MenuPlans;
import streamdb.ui.MenuVisionnage;
import streamdb.ui.gui.StreamDBFrame;
import streamdb.util.ConsoleHelper;
import streamdb.util.DatabaseConnection;

import java.sql.SQLException;

import javax.swing.SwingUtilities;

/**
 * Point d'entree de l'application StreamDB.
 *
 * Par defaut, le projet lance l'interface graphique Swing.
 * Pour l'ancien mode console : java streamdb.Main --console
 */
public class Main {

    public static void main(String[] args) {
        if (args.length > 0 && "--console".equalsIgnoreCase(args[0])) {
            runConsole();
            return;
        }

        SwingUtilities.invokeLater(() -> {
            StreamDBFrame frame = new StreamDBFrame();
            frame.setVisible(true);
        });
    }

    private static void runConsole() {
        try {
            DatabaseConnection.getConnection();
        } catch (SQLException e) {
            System.err.println("ERREUR : impossible de se connecter a la base de donnees.");
            System.err.println("Verifiez PostgreSQL, la base streamdb, le mot de passe et le driver JDBC.");
            System.err.println("Detail : " + e.getMessage());
            System.exit(1);
        }

        System.out.println();
        System.out.println("============================================================");
        System.out.println(" StreamDB - Systeme de gestion d'une plateforme VOD");
        System.out.println(" Projet de modelisation de base de donnees - PostgreSQL");
        System.out.println("============================================================");
        System.out.println();

        MenuPlans menuPlans = new MenuPlans();
        MenuComptes menuComptes = new MenuComptes();
        MenuCatalogue menuCatalogue = new MenuCatalogue();
        MenuVisionnage menuVisionnage = new MenuVisionnage();

        while (true) {
            ConsoleHelper.printMenu("MENU PRINCIPAL - StreamDB", new String[]{
                "Gerer les plans d'abonnement",
                "Gerer les comptes et profils",
                "Catalogue films et series",
                "Espace profil : visionnage et Ma Liste"
            });

            int choix = ConsoleHelper.readInt("  Votre choix : ");
            switch (choix) {
                case 1 -> menuPlans.show();
                case 2 -> menuComptes.show();
                case 3 -> menuCatalogue.show();
                case 4 -> menuVisionnage.show();
                case 0 -> {
                    ConsoleHelper.printSeparator();
                    System.out.println("  A bientot sur StreamDB !");
                    ConsoleHelper.printSeparator();
                    DatabaseConnection.closeConnection();
                    System.exit(0);
                }
                default -> ConsoleHelper.error("Choix invalide, entrez un nombre entre 0 et 4.");
            }
        }
    }
}
