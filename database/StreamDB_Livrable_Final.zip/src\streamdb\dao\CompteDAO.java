package streamdb.dao;

import streamdb.model.Compte;
import streamdb.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CompteDAO {

    // ── Lire tous les comptes (avec libellé du plan) ───────────
    public List<Compte> findAll() throws SQLException {
        List<Compte> list = new ArrayList<>();
        String sql = """
            SELECT c.idCompte, c.email, c.motDePasse, c.dateInscription,
                   c.idPlan, p.libelle AS libellePlan
            FROM Compte c
            JOIN Plan p ON c.idPlan = p.idPlan
            ORDER BY c.idCompte
            """;
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    // ── Trouver un compte par id ───────────────────────────────
    public Compte findById(int id) throws SQLException {
        String sql = """
            SELECT c.idCompte, c.email, c.motDePasse, c.dateInscription,
                   c.idPlan, p.libelle AS libellePlan
            FROM Compte c
            JOIN Plan p ON c.idPlan = p.idPlan
            WHERE c.idCompte = ?
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    // ── Trouver par email (pour "connexion") ───────────────────
    public Compte findByEmail(String email) throws SQLException {
        String sql = """
            SELECT c.idCompte, c.email, c.motDePasse, c.dateInscription,
                   c.idPlan, p.libelle AS libellePlan
            FROM Compte c
            JOIN Plan p ON c.idPlan = p.idPlan
            WHERE c.email = ?
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    // ── Créer un compte ────────────────────────────────────────
    public boolean create(Compte c) throws SQLException {
        // Contrainte C2 : vérifier que le plan existe
        String sql = "INSERT INTO Compte (email, motDePasse, dateInscription, idPlan) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, c.getEmail());
            ps.setString(2, c.getMotDePasse());
            ps.setDate(3, Date.valueOf(c.getDateInscription() != null ? c.getDateInscription() : LocalDate.now()));
            ps.setInt(4, c.getIdPlan());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Mettre à jour le plan d'un compte ─────────────────────
    public boolean updatePlan(int idCompte, int idPlan) throws SQLException {
        String sql = "UPDATE Compte SET idPlan = ? WHERE idCompte = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idPlan);
            ps.setInt(2, idCompte);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Supprimer un compte ────────────────────────────────────
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM Compte WHERE idCompte = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Nombre de profils actuels d'un compte ─────────────────
    public int countProfils(int idCompte) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Profil WHERE idCompte = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idCompte);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return 0;
    }

    private Compte map(ResultSet rs) throws SQLException {
        Compte c = new Compte();
        c.setIdCompte(rs.getInt("idCompte"));
        c.setEmail(rs.getString("email"));
        c.setMotDePasse(rs.getString("motDePasse"));
        c.setDateInscription(rs.getDate("dateInscription").toLocalDate());
        c.setIdPlan(rs.getInt("idPlan"));
        c.setLibellePlan(rs.getString("libellePlan"));
        return c;
    }
}
