Placez ici le driver JDBC PostgreSQL si vous voulez lancer l'application depuis la ligne de commande.

Driver inclus :
postgresql-42.7.11.jar

Telechargement :
https://jdbc.postgresql.org/download/

Dans Eclipse, vous pouvez aussi faire :
Clic droit projet > Build Path > Configure Build Path > Libraries > Add External JARs.
