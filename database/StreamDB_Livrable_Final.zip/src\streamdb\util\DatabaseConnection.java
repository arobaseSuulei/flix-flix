package streamdb.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Gestion de la connexion a la base de donnees PostgreSQL.
 * Singleton : une seule connexion partagee dans toute l'application.
 */
public class DatabaseConnection {

    private static String url = readSetting(
        "STREAMDB_DB_URL",
        "streamdb.db.url",
        "jdbc:postgresql://localhost:5432/streamdb"
    );
    private static String user = readSetting("STREAMDB_DB_USER", "streamdb.db.user", "postgres");
    private static String password = readSetting("STREAMDB_DB_PASSWORD", "streamdb.db.password", "postgres");

    private static Connection instance = null;

    private DatabaseConnection() {}

    public static Connection getConnection() throws SQLException {
        if (instance == null || instance.isClosed()) {
            try {
                Class.forName("org.postgresql.Driver");
                instance = DriverManager.getConnection(url, user, password);
                instance.setAutoCommit(true);
                System.out.println("[DB] Connexion etablie avec succes.");
            } catch (ClassNotFoundException e) {
                throw new SQLException("Driver PostgreSQL introuvable. Ajoutez postgresql-42.x.jar au classpath.", e);
            }
        }
        return instance;
    }

    public static void closeConnection() {
        try {
            if (instance != null && !instance.isClosed()) {
                instance.close();
                System.out.println("[DB] Connexion fermee.");
            }
        } catch (SQLException e) {
            System.err.println("[DB] Erreur fermeture : " + e.getMessage());
        }
    }

    public static void configure(String newUrl, String newUser, String newPassword) {
        url = newUrl;
        user = newUser;
        password = newPassword;
        closeConnection();
    }

    public static Connection testConnection(String testUrl, String testUser, String testPassword) throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(testUrl, testUser, testPassword);
            connection.setAutoCommit(true);
            return connection;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver PostgreSQL introuvable. Ajoutez postgresql-42.x.jar au classpath.", e);
        }
    }

    public static String getUrl() {
        return url;
    }

    public static String getUser() {
        return user;
    }

    public static String getPassword() {
        return password;
    }

    private static String readSetting(String envName, String propertyName, String defaultValue) {
        String propertyValue = System.getProperty(propertyName);
        if (propertyValue != null && !propertyValue.isBlank()) {
            return propertyValue;
        }
        String envValue = System.getenv(envName);
        if (envValue != null && !envValue.isBlank()) {
            return envValue;
        }
        return defaultValue;
    }
}
