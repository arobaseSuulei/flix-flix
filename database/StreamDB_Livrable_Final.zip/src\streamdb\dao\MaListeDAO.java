package streamdb.dao;

import streamdb.model.Contenu;
import streamdb.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MaListeDAO {

    // ── Contenus sauvegardés par un profil ─────────────────────
    public List<Contenu> findByProfil(int idProfil) throws SQLException {
        List<Contenu> list = new ArrayList<>();
        String sql = """
            SELECT c.idContenu, c.titre, c.annee, c.duree, c.idPays, c.type,
                   py.nom AS nomPays,
                   STRING_AGG(DISTINCT g.libelle, ', ' ORDER BY g.libelle) AS genres,
                   f.realisateur,
                   s.createur, s.nbSaisons
            FROM MaListe ml
            JOIN Contenu c ON ml.idContenu = c.idContenu
            JOIN Pays py ON c.idPays = py.idPays
            LEFT JOIN ContenuGenre cg ON c.idContenu = cg.idContenu
            LEFT JOIN Genre g ON cg.idGenre = g.idGenre
            LEFT JOIN Film f ON c.idContenu = f.idContenu
            LEFT JOIN Serie s ON c.idContenu = s.idContenu
            WHERE ml.idProfil = ?
            GROUP BY c.idContenu, c.titre, c.annee, c.duree, c.idPays, c.type,
                     py.nom, f.realisateur, s.createur, s.nbSaisons
            ORDER BY ml.dateAjout DESC
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idProfil);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Contenu c = new Contenu();
                    c.setIdContenu(rs.getInt("idContenu"));
                    c.setTitre(rs.getString("titre"));
                    c.setAnnee(rs.getInt("annee"));
                    int duree = rs.getInt("duree");
                    c.setDuree(rs.wasNull() ? null : duree);
                    c.setIdPays(rs.getInt("idPays"));
                    c.setType(rs.getString("type"));
                    c.setNomPays(rs.getString("nomPays"));
                    c.setGenres(rs.getString("genres"));
                    c.setRealisateur(rs.getString("realisateur"));
                    c.setCreateur(rs.getString("createur"));
                    int nbS = rs.getInt("nbSaisons");
                    c.setNbSaisons(rs.wasNull() ? null : nbS);
                    list.add(c);
                }
            }
        }
        return list;
    }

    // ── Ajouter à Ma Liste ─────────────────────────────────────
    public boolean add(int idProfil, int idContenu) throws SQLException {
        String sql = "INSERT INTO MaListe (idProfil, idContenu, dateAjout) VALUES (?, ?, NOW()) ON CONFLICT DO NOTHING";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idProfil);
            ps.setInt(2, idContenu);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Retirer de Ma Liste ────────────────────────────────────
    public boolean remove(int idProfil, int idContenu) throws SQLException {
        String sql = "DELETE FROM MaListe WHERE idProfil = ? AND idContenu = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idProfil);
            ps.setInt(2, idContenu);
            return ps.executeUpdate() > 0;
        }
    }
}
