package streamdb.ui;

import streamdb.dao.ContenuDAO;
import streamdb.model.Contenu;
import streamdb.util.ConsoleHelper;

import java.sql.SQLException;
import java.util.List;

public class MenuCatalogue {

    private final ContenuDAO dao = new ContenuDAO();

    public void show() {
        while (true) {
            ConsoleHelper.printMenu("CATALOGUE — FILMS & SÉRIES", new String[]{
                "Afficher tout le catalogue",
                "Films uniquement",
                "Séries uniquement",
                "Rechercher par titre",
                "Voir les détails d'un contenu (langues + épisodes)",
                "Ajouter un film",
                "Ajouter une série",
                "Supprimer un contenu"
            });
            int choix = ConsoleHelper.readInt("  Votre choix : ");
            switch (choix) {
                case 1 -> afficher(dao::findAll, "CATALOGUE COMPLET");
                case 2 -> afficher(dao::findFilms, "FILMS");
                case 3 -> afficher(dao::findSeries, "SÉRIES");
                case 4 -> rechercher();
                case 5 -> details();
                case 6 -> ajouterFilm();
                case 7 -> ajouterSerie();
                case 8 -> supprimer();
                case 0 -> { return; }
                default -> ConsoleHelper.error("Choix invalide.");
            }
        }
    }

    @FunctionalInterface
    interface ContenuSupplier { List<Contenu> get() throws SQLException; }

    private void afficher(ContenuSupplier supplier, String titre) {
        try {
            List<Contenu> list = supplier.get();
            ConsoleHelper.printTitle(titre + " (" + list.size() + " résultats)");
            if (list.isEmpty()) ConsoleHelper.info("Aucun contenu.");
            else list.forEach(c -> System.out.println("  " + c));
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void rechercher() {
        String kw = ConsoleHelper.readLine("  Mot-clé à rechercher : ");
        try {
            List<Contenu> list = dao.findByTitre(kw);
            ConsoleHelper.printTitle("RÉSULTATS POUR \"" + kw + "\"");
            if (list.isEmpty()) ConsoleHelper.info("Aucun résultat.");
            else list.forEach(c -> System.out.println("  " + c));
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void details() {
        int id = ConsoleHelper.readInt("  ID du contenu : ");
        try {
            List<Contenu> all = dao.findAll();
            Contenu found = all.stream().filter(c -> c.getIdContenu() == id).findFirst().orElse(null);
            if (found == null) { ConsoleHelper.error("Contenu introuvable."); ConsoleHelper.pause(); return; }
            ConsoleHelper.printTitle("DÉTAILS : " + found.getTitre());
            System.out.println("  " + found);
            dao.printLangues(id);
            if ("serie".equals(found.getType())) dao.printEpisodes(id);
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void ajouterFilm() {
        ConsoleHelper.printTitle("AJOUTER UN FILM");
        Contenu c = saisirContenuCommun();
        c.setDuree(ConsoleHelper.readInt("  Durée (minutes) : "));
        c.setRealisateur(ConsoleHelper.readLine("  Réalisateur : "));
        try {
            if (dao.createFilm(c)) ConsoleHelper.ok("Film ajouté au catalogue !");
            else                   ConsoleHelper.error("Échec.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private void ajouterSerie() {
        ConsoleHelper.printTitle("AJOUTER UNE SÉRIE");
        Contenu c = saisirContenuCommun();
        c.setDuree(null);
        c.setCreateur(ConsoleHelper.readLine("  Créateur : "));
        c.setNbSaisons(ConsoleHelper.readInt("  Nombre de saisons : "));
        try {
            if (dao.createSerie(c)) ConsoleHelper.ok("Série ajoutée au catalogue !");
            else                    ConsoleHelper.error("Échec.");
        } catch (SQLException e) { ConsoleHelper.error(e.getMessage()); }
        ConsoleHelper.pause();
    }

    private Contenu saisirContenuCommun() {
        Contenu c = new Contenu();
        c.setTitre(ConsoleHelper.readLine("  Titre : "));
        c.setAnnee(ConsoleHelper.readInt("  Année de sortie : "));
        c.setIdPays(ConsoleHelper.readInt("  ID pays d'origine (1=USA, 2=France, 3=UK, 4=Corée, 5=Espagne) : "));
        c.setGenres(ConsoleHelper.readLine("  Genres (séparés par virgule, ex: Action, Thriller) : "));
        return c;
    }

    private void supprimer() {
        ConsoleHelper.printTitle("SUPPRIMER UN CONTENU");
        int id = ConsoleHelper.readInt("  ID du contenu à supprimer : ");
        boolean conf = ConsoleHelper.readBoolean("  Confirmer la suppression");
        if (!conf) { ConsoleHelper.info("Annulé."); ConsoleHelper.pause(); return; }
        try {
            if (dao.delete(id)) ConsoleHelper.ok("Contenu supprimé.");
            else                ConsoleHelper.error("Introuvable.");
        } catch (SQLException e) { ConsoleHelper.error("Impossible : " + e.getMessage()); }
        ConsoleHelper.pause();
    }
}
