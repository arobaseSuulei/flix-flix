-- ============================================================
--  StreamDB — Script PostgreSQL pour pgAdmin
--  Copiez-collez TOUT ce script dans le Query Tool de pgAdmin
--  puis cliquez sur le bouton "Exécuter" (F5)
-- ============================================================

-- Nettoyage si vous ré-exécutez (remet à zéro proprement)
DROP TABLE IF EXISTS MaListe         CASCADE;
DROP TABLE IF EXISTS Visionnage       CASCADE;
DROP TABLE IF EXISTS VisionnageFilm   CASCADE;
DROP TABLE IF EXISTS ContenuLangue    CASCADE;
DROP TABLE IF EXISTS ContenuGenre     CASCADE;
DROP TABLE IF EXISTS Episode          CASCADE;
DROP TABLE IF EXISTS Saison           CASCADE;
DROP TABLE IF EXISTS Serie            CASCADE;
DROP TABLE IF EXISTS Film             CASCADE;
DROP TABLE IF EXISTS Contenu          CASCADE;
DROP TABLE IF EXISTS Profil           CASCADE;
DROP TABLE IF EXISTS Compte           CASCADE;
DROP TABLE IF EXISTS Genre            CASCADE;
DROP TABLE IF EXISTS Pays             CASCADE;
DROP TABLE IF EXISTS Plan             CASCADE;

-- -----------------------------------------------
-- 1. Plan d'abonnement
-- -----------------------------------------------
CREATE TABLE Plan (
    idPlan       SERIAL       PRIMARY KEY,
    libelle      VARCHAR(50)  NOT NULL UNIQUE,
    prixMensuel  NUMERIC(6,2) NOT NULL CHECK (prixMensuel >= 0),
    qualiteMax   VARCHAR(10)  NOT NULL CHECK (qualiteMax IN ('SD', 'HD', '4K')),
    nbProfilsMax INTEGER      NOT NULL CHECK (nbProfilsMax BETWEEN 1 AND 5)
);

-- -----------------------------------------------
-- 2. Pays d'origine
-- -----------------------------------------------
CREATE TABLE Pays (
    idPays  SERIAL        PRIMARY KEY,
    nom     VARCHAR(100)  NOT NULL UNIQUE
);

-- -----------------------------------------------
-- 3. Genre
-- -----------------------------------------------
CREATE TABLE Genre (
    idGenre  SERIAL      PRIMARY KEY,
    libelle  VARCHAR(80) NOT NULL UNIQUE
);

-- -----------------------------------------------
-- 4. Compte client
-- -----------------------------------------------
CREATE TABLE Compte (
    idCompte        SERIAL        PRIMARY KEY,
    email           VARCHAR(255)  NOT NULL UNIQUE,
    motDePasse      VARCHAR(255)  NOT NULL,
    dateInscription DATE          NOT NULL DEFAULT CURRENT_DATE,
    idPlan          INTEGER       NOT NULL,
    FOREIGN KEY (idPlan) REFERENCES Plan(idPlan)
);

-- -----------------------------------------------
-- 5. Profil (appartient à un compte)
-- -----------------------------------------------
CREATE TABLE Profil (
    idProfil  SERIAL        PRIMARY KEY,
    pseudo    VARCHAR(100)  NOT NULL,
    avatar    VARCHAR(255),
    idCompte  INTEGER       NOT NULL,
    FOREIGN KEY (idCompte) REFERENCES Compte(idCompte) ON DELETE CASCADE
);

-- -----------------------------------------------
-- 6. Contenu — entité mère de la spécialisation ISA
-- -----------------------------------------------
CREATE TABLE Contenu (
    idContenu  SERIAL        PRIMARY KEY,
    titre      VARCHAR(255)  NOT NULL,
    annee      INTEGER       NOT NULL CHECK (annee BETWEEN 1888 AND 2100),
    duree      INTEGER       CHECK (duree > 0),
    idPays     INTEGER       NOT NULL,
    type       VARCHAR(10)   NOT NULL CHECK (type IN ('film', 'serie')),
    FOREIGN KEY (idPays) REFERENCES Pays(idPays)
);

-- -----------------------------------------------
-- 7. Film (sous-classe)
-- -----------------------------------------------
CREATE TABLE Film (
    idContenu    INTEGER       PRIMARY KEY,
    realisateur  VARCHAR(200)  NOT NULL,
    FOREIGN KEY (idContenu) REFERENCES Contenu(idContenu) ON DELETE CASCADE
);

-- -----------------------------------------------
-- 8. Série (sous-classe)
-- -----------------------------------------------
CREATE TABLE Serie (
    idContenu  INTEGER       PRIMARY KEY,
    createur   VARCHAR(200)  NOT NULL,
    nbSaisons  INTEGER       NOT NULL CHECK (nbSaisons > 0),
    FOREIGN KEY (idContenu) REFERENCES Contenu(idContenu) ON DELETE CASCADE
);

-- -----------------------------------------------
-- 9. Saison
-- -----------------------------------------------
CREATE TABLE Saison (
    idSaison   SERIAL   PRIMARY KEY,
    numero     INTEGER  NOT NULL CHECK (numero > 0),
    idContenu  INTEGER  NOT NULL,
    UNIQUE (idContenu, numero),
    FOREIGN KEY (idContenu) REFERENCES Serie(idContenu) ON DELETE CASCADE
);

-- -----------------------------------------------
-- 10. Episode
-- -----------------------------------------------
CREATE TABLE Episode (
    idEpisode  SERIAL        PRIMARY KEY,
    numero     INTEGER       NOT NULL CHECK (numero > 0),
    titre      VARCHAR(255)  NOT NULL,
    duree      INTEGER       NOT NULL CHECK (duree > 0),
    idSaison   INTEGER       NOT NULL,
    UNIQUE (idSaison, numero),
    FOREIGN KEY (idSaison) REFERENCES Saison(idSaison) ON DELETE CASCADE
);

-- -----------------------------------------------
-- 11. Contenu <-> Genre  (association N:M)
-- -----------------------------------------------
CREATE TABLE ContenuGenre (
    idContenu  INTEGER  NOT NULL,
    idGenre    INTEGER  NOT NULL,
    PRIMARY KEY (idContenu, idGenre),
    FOREIGN KEY (idContenu) REFERENCES Contenu(idContenu) ON DELETE CASCADE,
    FOREIGN KEY (idGenre)   REFERENCES Genre(idGenre)     ON DELETE CASCADE
);

-- -----------------------------------------------
-- 12. Langues disponibles
-- -----------------------------------------------
CREATE TABLE ContenuLangue (
    idContenu         INTEGER      NOT NULL,
    langue            VARCHAR(50)  NOT NULL,
    typeDisponibilite VARCHAR(20)  NOT NULL
        CHECK (typeDisponibilite IN ('audio', 'sous-titre')),
    PRIMARY KEY (idContenu, langue, typeDisponibilite),
    FOREIGN KEY (idContenu) REFERENCES Contenu(idContenu) ON DELETE CASCADE
);

-- -----------------------------------------------
-- 13. Visionnage d'un film
-- -----------------------------------------------
CREATE TABLE VisionnageFilm (
    idProfil    INTEGER   NOT NULL,
    idContenu   INTEGER   NOT NULL,
    dateDebut   TIMESTAMP NOT NULL DEFAULT NOW(),
    progression INTEGER   NOT NULL DEFAULT 0 CHECK (progression >= 0),
    PRIMARY KEY (idProfil, idContenu, dateDebut),
    FOREIGN KEY (idProfil)  REFERENCES Profil(idProfil)  ON DELETE CASCADE,
    FOREIGN KEY (idContenu) REFERENCES Film(idContenu)   ON DELETE CASCADE
);

-- -----------------------------------------------
-- 14. Visionnage d'un épisode
-- -----------------------------------------------
CREATE TABLE Visionnage (
    idProfil    INTEGER   NOT NULL,
    idEpisode   INTEGER   NOT NULL,
    dateDebut   TIMESTAMP NOT NULL DEFAULT NOW(),
    progression INTEGER   NOT NULL DEFAULT 0 CHECK (progression >= 0),
    PRIMARY KEY (idProfil, idEpisode, dateDebut),
    FOREIGN KEY (idProfil)  REFERENCES Profil(idProfil)   ON DELETE CASCADE,
    FOREIGN KEY (idEpisode) REFERENCES Episode(idEpisode) ON DELETE CASCADE
);

-- -----------------------------------------------
-- 15. Ma Liste
-- -----------------------------------------------
CREATE TABLE MaListe (
    idProfil   INTEGER   NOT NULL,
    idContenu  INTEGER   NOT NULL,
    dateAjout  TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (idProfil, idContenu),
    FOREIGN KEY (idProfil)  REFERENCES Profil(idProfil)   ON DELETE CASCADE,
    FOREIGN KEY (idContenu) REFERENCES Contenu(idContenu) ON DELETE CASCADE
);


-- ============================================================
--  JEU DE DONNÉES
-- ============================================================

-- Plans
INSERT INTO Plan (libelle, prixMensuel, qualiteMax, nbProfilsMax) VALUES
    ('Essentiel', 5.99,  'SD', 1),
    ('Standard',  13.99, 'HD', 2),
    ('Premium',   19.99, '4K', 5),
    ('Etudiant',   7.99, 'HD', 1),
    ('Famille',   24.99, '4K', 5);

-- Pays
INSERT INTO Pays (nom) VALUES
    ('États-Unis'),
    ('France'),
    ('Royaume-Uni'),
    ('Corée du Sud'),
    ('Espagne');

-- Genres
INSERT INTO Genre (libelle) VALUES
    ('Action'),
    ('Drame'),
    ('Comédie'),
    ('Thriller'),
    ('Science-fiction'),
    ('Horreur'),
    ('Romance'),
    ('Documentaire');

-- Comptes
INSERT INTO Compte (email, motDePasse, dateInscription, idPlan) VALUES
    ('alice@mail.com',  'hashed_pwd_1', '2023-01-15', 3),
    ('bob@mail.com',    'hashed_pwd_2', '2023-03-22', 2),
    ('claire@mail.com', 'hashed_pwd_3', '2024-06-01', 1),
    ('david@mail.com',  'hashed_pwd_4', '2024-09-10', 3),
    ('emma@mail.com',   'hashed_pwd_5', '2025-01-05', 2);

-- Profils
INSERT INTO Profil (pseudo, avatar, idCompte) VALUES
    ('Alice',      'avatar_alice.png',  1),
    ('Mini-Alice', 'avatar_kids.png',   1),
    ('Bob',        'avatar_bob.png',    2),
    ('Bob Films',  'avatar_cinema.png', 2),
    ('Claire',     'avatar_claire.png', 3),
    ('David',      'avatar_david.png',  4),
    ('Emma',       'avatar_emma.png',   5);

-- Contenus — films
INSERT INTO Contenu (titre, annee, duree, idPays, type) VALUES
    ('Inception',    2010, 148, 1, 'film'),
    ('Intouchables', 2011, 112, 2, 'film'),
    ('Parasite',     2019, 132, 4, 'film'),
    ('Dunkerque',    2017, 107, 3, 'film'),
    ('Interstellar', 2014, 169, 1, 'film');

-- Contenus — séries
INSERT INTO Contenu (titre, annee, duree, idPays, type) VALUES
    ('Stranger Things', 2016, NULL, 1, 'serie'),
    ('Casa de Papel',   2017, NULL, 5, 'serie'),
    ('Dark',            2017, NULL, 5, 'serie'),
    ('Squid Game',      2021, NULL, 4, 'serie'),
    ('Lupin',           2021, NULL, 2, 'serie');

-- Films (sous-classe)
INSERT INTO Film (idContenu, realisateur) VALUES
    (1, 'Christopher Nolan'),
    (2, 'Olivier Nakache, Eric Toledano'),
    (3, 'Bong Joon-ho'),
    (4, 'Christopher Nolan'),
    (5, 'Christopher Nolan');

-- Series (sous-classe)
INSERT INTO Serie (idContenu, createur, nbSaisons) VALUES
    (6,  'Matt Duffer, Ross Duffer',  4),
    (7,  'Alex Pina',                 5),
    (8,  'Baran bo Odar',             3),
    (9,  'Hwang Dong-hyuk',           2),
    (10, 'George Kay, Francois Uzan', 3);

-- Saisons
INSERT INTO Saison (numero, idContenu) VALUES
    (1, 6), (2, 6), (3, 6), (4, 6),
    (1, 7), (2, 7),
    (1, 9),
    (1, 10), (2, 10);

-- Episodes
INSERT INTO Episode (numero, titre, duree, idSaison) VALUES
    (1, 'Le Monde a l''envers',       47, 1),
    (2, 'La Barbe-Fleurie',           55, 1),
    (3, 'Holly jolly',                51, 1),
    (1, 'Le Garcon de retour',        48, 2),
    (2, 'Trick or Treat Freak',       56, 2),
    (1, 'Episode 1',                  70, 5),
    (2, 'Episode 2',                  50, 5),
    (3, 'Episode 3',                  49, 5),
    (1, 'Red Light Green Light',      60, 7),
    (2, 'L''Enfer c''est les autres', 63, 7),
    (3, 'L''Homme au parapluie',      56, 7),
    (1, 'Arsene',                     53, 8),
    (2, 'La Comtesse de Cagliostro',  47, 8);

-- Genres des contenus
INSERT INTO ContenuGenre (idContenu, idGenre) VALUES
    (1, 1), (1, 5),
    (2, 2), (2, 3),
    (3, 2), (3, 4),
    (4, 1), (4, 2),
    (5, 1), (5, 5),
    (6, 5), (6, 6),
    (7, 1), (7, 4),
    (8, 5), (8, 4),
    (9, 2), (9, 4),
    (10, 2),(10, 4);

-- Langues
INSERT INTO ContenuLangue (idContenu, langue, typeDisponibilite) VALUES
    (1,  'Anglais',  'audio'),
    (1,  'Francais', 'audio'),
    (1,  'Francais', 'sous-titre'),
    (2,  'Francais', 'audio'),
    (2,  'Anglais',  'sous-titre'),
    (3,  'Coreen',   'audio'),
    (3,  'Francais', 'sous-titre'),
    (3,  'Anglais',  'sous-titre'),
    (9,  'Coreen',   'audio'),
    (9,  'Francais', 'sous-titre'),
    (10, 'Francais', 'audio'),
    (10, 'Anglais',  'sous-titre');

-- Visionnages films
INSERT INTO VisionnageFilm (idProfil, idContenu, dateDebut, progression) VALUES
    (1, 1, '2025-01-10 20:00:00', 8880),
    (1, 2, '2025-01-15 21:00:00', 3200),
    (3, 3, '2025-02-01 19:30:00', 7920),
    (6, 5, '2025-03-05 22:00:00', 5400),
    (7, 4, '2025-03-10 18:00:00', 6420);

-- Visionnages episodes
INSERT INTO Visionnage (idProfil, idEpisode, dateDebut, progression) VALUES
    (1, 1,  '2025-01-20 20:00:00', 2820),
    (1, 2,  '2025-01-21 20:00:00', 3300),
    (3, 9,  '2025-02-10 21:00:00', 3600),
    (3, 10, '2025-02-10 22:01:00', 1800),
    (6, 6,  '2025-03-01 20:00:00', 4200),
    (7, 12, '2025-03-15 21:00:00', 3180),
    (7, 13, '2025-03-15 22:00:00', 900);

-- Ma Liste
INSERT INTO MaListe (idProfil, idContenu, dateAjout) VALUES
    (1, 6,  '2025-01-19 10:00:00'),
    (1, 9,  '2025-01-22 11:00:00'),
    (3, 5,  '2025-02-05 09:00:00'),
    (6, 8,  '2025-03-02 14:00:00'),
    (7, 10, '2025-03-14 20:00:00');


-- ============================================================
--  VERIFICATION — exécutez ces SELECT pour tout contrôler
-- ============================================================

SELECT 'Plan'           AS table_name, COUNT(*) AS nb_lignes FROM Plan
UNION ALL
SELECT 'Pays',          COUNT(*) FROM Pays
UNION ALL
SELECT 'Genre',         COUNT(*) FROM Genre
UNION ALL
SELECT 'Compte',        COUNT(*) FROM Compte
UNION ALL
SELECT 'Profil',        COUNT(*) FROM Profil
UNION ALL
SELECT 'Contenu',       COUNT(*) FROM Contenu
UNION ALL
SELECT 'Film',          COUNT(*) FROM Film
UNION ALL
SELECT 'Serie',         COUNT(*) FROM Serie
UNION ALL
SELECT 'Saison',        COUNT(*) FROM Saison
UNION ALL
SELECT 'Episode',       COUNT(*) FROM Episode
UNION ALL
SELECT 'ContenuGenre',  COUNT(*) FROM ContenuGenre
UNION ALL
SELECT 'ContenuLangue', COUNT(*) FROM ContenuLangue
UNION ALL
SELECT 'VisionnageFilm',COUNT(*) FROM VisionnageFilm
UNION ALL
SELECT 'Visionnage',    COUNT(*) FROM Visionnage
UNION ALL
SELECT 'MaListe',       COUNT(*) FROM MaListe;
