package streamdb.dao;

import streamdb.model.Visionnage;
import streamdb.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VisionnageDAO {

    // ── Historique complet d'un profil (films + épisodes) ─────
    public List<Visionnage> findByProfil(int idProfil) throws SQLException {
        List<Visionnage> list = new ArrayList<>();

        // Films
        String sqlFilms = """
            SELECT vf.idProfil, vf.idContenu AS idCible, vf.dateDebut, vf.progression,
                   'film' AS typeCible,
                   c.titre AS titreAffiche
            FROM VisionnageFilm vf
            JOIN Contenu c ON vf.idContenu = c.idContenu
            WHERE vf.idProfil = ?
            """;
        // Épisodes
        String sqlEps = """
            SELECT v.idProfil, v.idEpisode AS idCible, v.dateDebut, v.progression,
                   'episode' AS typeCible,
                   c.titre || ' — S' || LPAD(sa.numero::text,2,'0') || 'E' ||
                   LPAD(e.numero::text,2,'0') || ' : ' || e.titre AS titreAffiche
            FROM Visionnage v
            JOIN Episode e ON v.idEpisode = e.idEpisode
            JOIN Saison sa ON e.idSaison = sa.idSaison
            JOIN Contenu c ON sa.idContenu = c.idContenu
            WHERE v.idProfil = ?
            """;

        for (String sql : new String[]{sqlFilms, sqlEps}) {
            try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
                ps.setInt(1, idProfil);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) list.add(mapVisionnage(rs));
                }
            }
        }
        // Tri par date décroissante
        list.sort((a, b) -> b.getDateDebut().compareTo(a.getDateDebut()));
        return list;
    }

    // ── Enregistrer/mettre à jour un visionnage de film ───────
    public boolean upsertFilm(int idProfil, int idContenu, int progression) throws SQLException {
        String sql = """
            INSERT INTO VisionnageFilm (idProfil, idContenu, dateDebut, progression)
            VALUES (?, ?, NOW(), ?)
            ON CONFLICT (idProfil, idContenu, dateDebut) DO UPDATE SET progression = EXCLUDED.progression
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idProfil);
            ps.setInt(2, idContenu);
            ps.setInt(3, progression);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Enregistrer/mettre à jour un visionnage d'épisode ─────
    public boolean upsertEpisode(int idProfil, int idEpisode, int progression) throws SQLException {
        String sql = """
            INSERT INTO Visionnage (idProfil, idEpisode, dateDebut, progression)
            VALUES (?, ?, NOW(), ?)
            ON CONFLICT (idProfil, idEpisode, dateDebut) DO UPDATE SET progression = EXCLUDED.progression
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idProfil);
            ps.setInt(2, idEpisode);
            ps.setInt(3, progression);
            return ps.executeUpdate() > 0;
        }
    }

    private Visionnage mapVisionnage(ResultSet rs) throws SQLException {
        Visionnage v = new Visionnage();
        v.setIdProfil(rs.getInt("idProfil"));
        v.setIdCible(rs.getInt("idCible"));
        v.setDateDebut(rs.getTimestamp("dateDebut").toLocalDateTime());
        v.setProgression(rs.getInt("progression"));
        v.setTypeCible(rs.getString("typeCible"));
        v.setTitreAffiche(rs.getString("titreAffiche"));
        return v;
    }
}
