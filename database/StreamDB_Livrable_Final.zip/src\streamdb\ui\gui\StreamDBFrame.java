package streamdb.ui.gui;

import streamdb.dao.CompteDAO;
import streamdb.dao.ContenuDAO;
import streamdb.dao.MaListeDAO;
import streamdb.dao.PlanDAO;
import streamdb.dao.ProfilDAO;
import streamdb.dao.VisionnageDAO;
import streamdb.model.Compte;
import streamdb.model.Contenu;
import streamdb.model.Plan;
import streamdb.model.Profil;
import streamdb.model.Visionnage;
import streamdb.util.DatabaseConnection;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 * Interface graphique Swing pour la demonstration StreamDB.
 */
public class StreamDBFrame extends JFrame {

    private static final Color BG = new Color(245, 247, 251);
    private static final Color PANEL = Color.WHITE;
    private static final Color SIDEBAR = new Color(17, 24, 39);
    private static final Color TEXT = new Color(31, 41, 55);
    private static final Color MUTED = new Color(107, 114, 128);
    private static final Color ACCENT = new Color(34, 197, 94);
    private static final Color BLUE = new Color(37, 99, 235);
    private static final Color AMBER = new Color(245, 158, 11);
    private static final Color RED = new Color(220, 38, 38);

    private final PlanDAO planDAO = new PlanDAO();
    private final CompteDAO compteDAO = new CompteDAO();
    private final ProfilDAO profilDAO = new ProfilDAO();
    private final ContenuDAO contenuDAO = new ContenuDAO();
    private final MaListeDAO maListeDAO = new MaListeDAO();
    private final VisionnageDAO visionnageDAO = new VisionnageDAO();

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cards = new JPanel(cardLayout);
    private final JLabel statusLabel = new JLabel("Pret.");
    private final Map<String, JLabel> statValues = new LinkedHashMap<>();

    private JTable recentTable;
    private JTable catalogueTable;
    private JTable planTable;
    private JTable compteTable;
    private JTable profilTable;
    private JTable historyTable;
    private JTable myListTable;
    private JTable demoTable;

    private JTextField searchField;
    private JComboBox<String> typeFilter;
    private JComboBox<IdLabel> accountPlanCombo;
    private JComboBox<IdLabel> profileAccountCombo;
    private JComboBox<IdLabel> historyProfileCombo;

    private JTextField planLabelField;
    private JTextField planPriceField;
    private JComboBox<String> planQualityCombo;
    private JTextField planProfileMaxField;

    private JTextField accountEmailField;
    private JTextField accountPasswordField;

    private JTextField profilePseudoField;
    private JTextField profileAvatarField;
    private JTextField myListContentIdField;

    private JTextField dbUrlField;
    private JTextField dbUserField;
    private JPasswordField dbPasswordField;
    private JLabel dbStatusLabel;

    public StreamDBFrame() {
        super("StreamDB - Plateforme VOD");
        configureLookAndFeel();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(1180, 720));
        setContentPane(buildRoot());
        pack();
        setLocationRelativeTo(null);
        showCard("connexion");
    }

    private JPanel buildRoot() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        root.add(buildSidebar(), BorderLayout.WEST);
        root.add(buildMainArea(), BorderLayout.CENTER);
        return root;
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(230, 720));
        sidebar.setBackground(SIDEBAR);
        sidebar.setBorder(new EmptyBorder(24, 20, 24, 20));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("StreamDB");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel("VOD + PostgreSQL");
        subtitle.setForeground(new Color(156, 163, 175));
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        sidebar.add(title);
        sidebar.add(subtitle);
        sidebar.add(Box.createVerticalStrut(30));
        sidebar.add(navButton("Connexion DB", "connexion"));
        sidebar.add(navButton("Dashboard", "dashboard"));
        sidebar.add(navButton("Catalogue", "catalogue"));
        sidebar.add(navButton("Plans", "plans"));
        sidebar.add(navButton("Comptes", "comptes"));
        sidebar.add(navButton("Profils", "profils"));
        sidebar.add(navButton("Requetes demo", "demo"));
        sidebar.add(Box.createVerticalGlue());

        JTextArea hint = new JTextArea("Mode console :\njava streamdb.Main --console");
        hint.setEditable(false);
        hint.setLineWrap(true);
        hint.setWrapStyleWord(true);
        hint.setForeground(new Color(209, 213, 219));
        hint.setBackground(SIDEBAR);
        hint.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        hint.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(55, 65, 81)));
        hint.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(hint);

        return sidebar;
    }

    private JButton navButton(String label, String card) {
        JButton button = new JButton(label);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(31, 41, 55));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorder(new EmptyBorder(10, 14, 10, 14));
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(BLUE);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(31, 41, 55));
            }
        });
        button.addActionListener(e -> showCard(card));
        return button;
    }

    private JPanel buildMainArea() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BG);
        main.setBorder(new EmptyBorder(20, 22, 20, 22));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel title = new JLabel("Projet StreamDB");
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(TEXT);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        statusLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        top.add(title, BorderLayout.WEST);
        top.add(statusLabel, BorderLayout.EAST);

        cards.setOpaque(false);
        cards.add(buildConnectionPanel(), "connexion");
        cards.add(buildDashboardPanel(), "dashboard");
        cards.add(buildCataloguePanel(), "catalogue");
        cards.add(buildPlansPanel(), "plans");
        cards.add(buildComptesPanel(), "comptes");
        cards.add(buildProfilsPanel(), "profils");
        cards.add(buildDemoPanel(), "demo");

        main.add(top, BorderLayout.NORTH);
        main.add(cards, BorderLayout.CENTER);
        return main;
    }

    private JPanel buildConnectionPanel() {
        JPanel panel = page();
        panel.add(heading("Connexion a PostgreSQL"), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 16));
        center.setOpaque(false);

        AnimatedBanner banner = new AnimatedBanner();
        banner.setPreferredSize(new Dimension(900, 130));
        center.add(banner, BorderLayout.NORTH);

        JPanel content = new JPanel(new GridLayout(1, 2, 16, 0));
        content.setOpaque(false);

        JPanel form = cardPanel(new GridBagLayout());
        GridBagConstraints c = gbc();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;

        dbUrlField = new JTextField(DatabaseConnection.getUrl(), 30);
        dbUserField = new JTextField(DatabaseConnection.getUser(), 18);
        dbPasswordField = new JPasswordField(DatabaseConnection.getPassword(), 18);
        dbStatusLabel = new JLabel("Renseigne les parametres puis clique sur Tester.");
        dbStatusLabel.setForeground(MUTED);
        dbStatusLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));

        addWideFormRow(form, c, 0, "URL JDBC", dbUrlField);
        addWideFormRow(form, c, 1, "Utilisateur", dbUserField);
        addWideFormRow(form, c, 2, "Mot de passe", dbPasswordField);

        JButton test = primaryButton("Tester et utiliser cette connexion");
        test.addActionListener(e -> testAndApplyConnection());
        JButton findPort = secondaryButton("Trouver le bon port");
        findPort.addActionListener(e -> findDatabasePort());
        c.gridx = 1;
        c.gridy = 3;
        c.insets = new Insets(12, 6, 6, 6);
        form.add(test, c);
        c.gridy = 4;
        c.insets = new Insets(6, 6, 6, 6);
        form.add(findPort, c);
        c.gridy = 4;
        c.insets = new Insets(6, 6, 6, 6);
        c.gridy = 5;
        form.add(dbStatusLabel, c);

        JTextArea guide = new JTextArea("""
            Important :

            pgAdmin est seulement l'outil qui permet de voir PostgreSQL.
            L'application Java se connecte au serveur PostgreSQL, puis a la base :

            streamdb

            A verifier dans pgAdmin :
            1. Servers > PostgreSQL > Databases.
            2. La base streamdb existe.
            3. Query Tool sur streamdb.
            4. Executer : SHOW port;
            5. Mettre ce port dans l'URL JDBC.
            6. Executer sql/streamdb_pgadmin.sql si les tables manquent.

            Si ton mot de passe PostgreSQL n'est pas postgres,
            mets ton vrai mot de passe dans le champ de gauche.
            """);
        guide.setEditable(false);
        guide.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        guide.setLineWrap(true);
        guide.setWrapStyleWord(true);
        guide.setForeground(TEXT);
        guide.setBackground(PANEL);
        guide.setBorder(new EmptyBorder(10, 12, 10, 12));

        content.add(form);
        JPanel guideCard = cardPanel(new BorderLayout());
        guideCard.add(sectionTitle("Pourquoi la base n'apparait pas ?"), BorderLayout.NORTH);
        guideCard.add(guide, BorderLayout.CENTER);
        content.add(guideCard);

        center.add(content, BorderLayout.CENTER);
        panel.add(center, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildDashboardPanel() {
        JPanel panel = page();
        JLabel heading = heading("Vue generale");
        panel.add(heading, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 18));
        center.setOpaque(false);

        JPanel stats = new JPanel(new GridLayout(2, 4, 14, 14));
        stats.setOpaque(false);
        addStat(stats, "plans", "Plans", BLUE);
        addStat(stats, "comptes", "Comptes", ACCENT);
        addStat(stats, "profils", "Profils", AMBER);
        addStat(stats, "contenus", "Contenus", RED);
        addStat(stats, "films", "Films", BLUE);
        addStat(stats, "series", "Series", ACCENT);
        addStat(stats, "episodes", "Episodes", AMBER);
        addStat(stats, "vues", "Visionnages", RED);

        recentTable = table("Date", "Profil", "Type", "Titre", "Progression");

        JPanel bottom = cardPanel(new BorderLayout());
        bottom.add(sectionTitle("Derniers visionnages"), BorderLayout.NORTH);
        bottom.add(new JScrollPane(recentTable), BorderLayout.CENTER);

        center.add(stats, BorderLayout.NORTH);
        center.add(bottom, BorderLayout.CENTER);
        panel.add(center, BorderLayout.CENTER);

        JButton refresh = primaryButton("Actualiser");
        refresh.addActionListener(e -> refreshDashboard());
        panel.add(buttonBar(refresh), BorderLayout.SOUTH);
        return panel;
    }

    private JPanel buildCataloguePanel() {
        JPanel panel = page();
        panel.add(heading("Catalogue"), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 14));
        center.setOpaque(false);

        JPanel filters = cardPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        searchField = new JTextField(28);
        typeFilter = new JComboBox<>(new String[]{"Tous", "Films", "Series"});
        JButton search = primaryButton("Rechercher");
        search.addActionListener(e -> refreshCatalogue());
        filters.add(new JLabel("Titre"));
        filters.add(searchField);
        filters.add(new JLabel("Type"));
        filters.add(typeFilter);
        filters.add(search);

        catalogueTable = table("ID", "Type", "Titre", "Annee", "Pays", "Genres", "Details");
        center.add(filters, BorderLayout.NORTH);
        center.add(new JScrollPane(catalogueTable), BorderLayout.CENTER);
        panel.add(center, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildPlansPanel() {
        JPanel panel = page();
        panel.add(heading("Plans d'abonnement"), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 14));
        center.setOpaque(false);
        planTable = table("ID", "Libelle", "Prix mensuel", "Qualite max", "Profils max");
        center.add(new JScrollPane(planTable), BorderLayout.CENTER);

        JPanel form = cardPanel(new GridBagLayout());
        GridBagConstraints c = gbc();
        planLabelField = new JTextField(14);
        planPriceField = new JTextField(8);
        planQualityCombo = new JComboBox<>(new String[]{"SD", "HD", "4K"});
        planProfileMaxField = new JTextField(5);
        JButton add = primaryButton("Ajouter");
        add.addActionListener(e -> createPlan());
        addFormRow(form, c, 0, "Libelle", planLabelField);
        addFormRow(form, c, 1, "Prix", planPriceField);
        addFormRow(form, c, 2, "Qualite", planQualityCombo);
        addFormRow(form, c, 3, "Max profils", planProfileMaxField);
        c.gridx = 8;
        c.gridy = 0;
        c.gridheight = 2;
        form.add(add, c);

        center.add(form, BorderLayout.SOUTH);
        panel.add(center, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildComptesPanel() {
        JPanel panel = page();
        panel.add(heading("Comptes clients"), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 14));
        center.setOpaque(false);
        compteTable = table("ID", "Email", "Date inscription", "Plan");
        center.add(new JScrollPane(compteTable), BorderLayout.CENTER);

        JPanel form = cardPanel(new GridBagLayout());
        GridBagConstraints c = gbc();
        accountEmailField = new JTextField(20);
        accountPasswordField = new JTextField(14);
        accountPlanCombo = new JComboBox<>();
        JButton add = primaryButton("Creer compte");
        add.addActionListener(e -> createCompte());
        addFormRow(form, c, 0, "Email", accountEmailField);
        addFormRow(form, c, 1, "Mot de passe", accountPasswordField);
        addFormRow(form, c, 2, "Plan", accountPlanCombo);
        c.gridx = 6;
        c.gridy = 0;
        c.gridheight = 2;
        form.add(add, c);

        center.add(form, BorderLayout.SOUTH);
        panel.add(center, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildProfilsPanel() {
        JPanel panel = page();
        panel.add(heading("Profils, Ma Liste et historique"), BorderLayout.NORTH);

        JPanel center = new JPanel(new GridLayout(1, 2, 14, 0));
        center.setOpaque(false);

        JPanel left = cardPanel(new BorderLayout(0, 12));
        JPanel accountLine = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        accountLine.setOpaque(false);
        profileAccountCombo = new JComboBox<>();
        profileAccountCombo.addActionListener(e -> refreshProfilesForSelectedAccount());
        accountLine.add(new JLabel("Compte"));
        accountLine.add(profileAccountCombo);
        left.add(accountLine, BorderLayout.NORTH);
        profilTable = table("ID", "Pseudo", "Avatar", "Compte");
        left.add(new JScrollPane(profilTable), BorderLayout.CENTER);

        JPanel profileForm = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        profileForm.setOpaque(false);
        profilePseudoField = new JTextField(12);
        profileAvatarField = new JTextField(12);
        JButton addProfile = primaryButton("Ajouter profil");
        addProfile.addActionListener(e -> createProfil());
        profileForm.add(new JLabel("Pseudo"));
        profileForm.add(profilePseudoField);
        profileForm.add(new JLabel("Avatar"));
        profileForm.add(profileAvatarField);
        profileForm.add(addProfile);
        left.add(profileForm, BorderLayout.SOUTH);

        JPanel right = cardPanel(new BorderLayout(0, 12));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        top.setOpaque(false);
        historyProfileCombo = new JComboBox<>();
        JButton refresh = primaryButton("Charger");
        refresh.addActionListener(e -> refreshProfileWorkspace());
        myListContentIdField = new JTextField(6);
        JButton addList = secondaryButton("Ajouter a Ma Liste");
        addList.addActionListener(e -> addSelectedContentToList());
        JButton removeList = secondaryButton("Retirer");
        removeList.addActionListener(e -> removeSelectedContentFromList());
        top.add(new JLabel("Profil"));
        top.add(historyProfileCombo);
        top.add(refresh);
        top.add(new JLabel("ID contenu"));
        top.add(myListContentIdField);
        top.add(addList);
        top.add(removeList);
        right.add(top, BorderLayout.NORTH);

        JPanel tables = new JPanel(new GridLayout(2, 1, 0, 12));
        tables.setOpaque(false);
        historyTable = table("Date", "Type", "Titre", "Progression");
        myListTable = table("ID", "Type", "Titre", "Annee", "Genres");
        tables.add(wrappedTable("Historique", historyTable));
        tables.add(wrappedTable("Ma Liste", myListTable));
        right.add(tables, BorderLayout.CENTER);

        center.add(left);
        center.add(right);
        panel.add(center, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildDemoPanel() {
        JPanel panel = page();
        panel.add(heading("Requetes utiles pour la soutenance"), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 14));
        center.setOpaque(false);

        JPanel actions = cardPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JButton q1 = primaryButton("Comptage tables");
        JButton q2 = secondaryButton("Catalogue detaille");
        JButton q3 = secondaryButton("Profils par compte");
        JButton q4 = secondaryButton("Contraintes ISA");
        q1.addActionListener(e -> runDemoQuery("""
            SELECT 'Plan' AS relation, COUNT(*) AS tuples FROM Plan
            UNION ALL SELECT 'Pays', COUNT(*) FROM Pays
            UNION ALL SELECT 'Genre', COUNT(*) FROM Genre
            UNION ALL SELECT 'Compte', COUNT(*) FROM Compte
            UNION ALL SELECT 'Profil', COUNT(*) FROM Profil
            UNION ALL SELECT 'Contenu', COUNT(*) FROM Contenu
            UNION ALL SELECT 'Film', COUNT(*) FROM Film
            UNION ALL SELECT 'Serie', COUNT(*) FROM Serie
            UNION ALL SELECT 'Saison', COUNT(*) FROM Saison
            UNION ALL SELECT 'Episode', COUNT(*) FROM Episode
            UNION ALL SELECT 'ContenuGenre', COUNT(*) FROM ContenuGenre
            UNION ALL SELECT 'ContenuLangue', COUNT(*) FROM ContenuLangue
            UNION ALL SELECT 'VisionnageFilm', COUNT(*) FROM VisionnageFilm
            UNION ALL SELECT 'Visionnage', COUNT(*) FROM Visionnage
            UNION ALL SELECT 'MaListe', COUNT(*) FROM MaListe
            ORDER BY relation
            """));
        q2.addActionListener(e -> runDemoQuery("""
            SELECT c.idContenu, c.type, c.titre, c.annee, p.nom AS pays,
                   COALESCE(STRING_AGG(DISTINCT g.libelle, ', ' ORDER BY g.libelle), '-') AS genres
            FROM Contenu c
            JOIN Pays p ON p.idPays = c.idPays
            LEFT JOIN ContenuGenre cg ON cg.idContenu = c.idContenu
            LEFT JOIN Genre g ON g.idGenre = cg.idGenre
            GROUP BY c.idContenu, c.type, c.titre, c.annee, p.nom
            ORDER BY c.type, c.titre
            """));
        q3.addActionListener(e -> runDemoQuery("""
            SELECT c.email, pl.libelle AS plan, pl.nbProfilsMax,
                   COUNT(pr.idProfil) AS nbProfils
            FROM Compte c
            JOIN Plan pl ON pl.idPlan = c.idPlan
            LEFT JOIN Profil pr ON pr.idCompte = c.idCompte
            GROUP BY c.email, pl.libelle, pl.nbProfilsMax
            ORDER BY c.email
            """));
        q4.addActionListener(e -> runDemoQuery("""
            SELECT c.idContenu, c.titre, c.type,
                   CASE WHEN f.idContenu IS NOT NULL THEN 'Film' ELSE '-' END AS ligneFilm,
                   CASE WHEN s.idContenu IS NOT NULL THEN 'Serie' ELSE '-' END AS ligneSerie
            FROM Contenu c
            LEFT JOIN Film f ON f.idContenu = c.idContenu
            LEFT JOIN Serie s ON s.idContenu = c.idContenu
            ORDER BY c.idContenu
            """));
        actions.add(q1);
        actions.add(q2);
        actions.add(q3);
        actions.add(q4);

        demoTable = table("Resultat");
        center.add(actions, BorderLayout.NORTH);
        center.add(new JScrollPane(demoTable), BorderLayout.CENTER);
        panel.add(center, BorderLayout.CENTER);
        return panel;
    }

    private void showCard(String card) {
        cardLayout.show(cards, card);
        switch (card) {
            case "connexion" -> setStatus("Configure la connexion PostgreSQL.", true);
            case "dashboard" -> refreshDashboard();
            case "catalogue" -> refreshCatalogue();
            case "plans" -> refreshPlans();
            case "comptes" -> refreshComptes();
            case "profils" -> refreshProfilScreen();
            case "demo" -> runDemoQuery("SELECT CURRENT_DATABASE() AS base, CURRENT_USER AS utilisateur, NOW() AS date_execution");
            default -> setStatus("Pret.", true);
        }
    }

    private void testAndApplyConnection() {
        String url = dbUrlField.getText().trim();
        String user = dbUserField.getText().trim();
        String password = new String(dbPasswordField.getPassword());
        dbStatusLabel.setText("Test en cours...");
        dbStatusLabel.setForeground(AMBER);
        try (Connection ignored = DatabaseConnection.testConnection(url, user, password)) {
            DatabaseConnection.configure(url, user, password);
            dbStatusLabel.setText("Connexion reussie. Dashboard charge.");
            dbStatusLabel.setForeground(new Color(22, 163, 74));
            setStatus("Connecte a " + url, true);
            showCard("dashboard");
        } catch (SQLException e) {
            String message = explainConnectionError(e);
            dbStatusLabel.setText(message);
            dbStatusLabel.setForeground(RED);
            setStatus(message, false);
            JOptionPane.showMessageDialog(this, message, "Connexion impossible", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void findDatabasePort() {
        String currentUrl = dbUrlField.getText().trim();
        String host = extractHost(currentUrl);
        String database = extractDatabaseName(currentUrl);
        String user = dbUserField.getText().trim();
        String password = new String(dbPasswordField.getPassword());
        int[] ports = {5432, 5433, 5434, 5435, 5436, 5437, 5438, 5439};

        dbStatusLabel.setText("Recherche de " + database + " sur " + host + "...");
        dbStatusLabel.setForeground(AMBER);

        for (int port : ports) {
            String postgresUrl = buildJdbcUrl(host, port, "postgres");
            try (Connection connection = DatabaseConnection.testConnection(postgresUrl, user, password);
                 PreparedStatement ps = connection.prepareStatement(
                     "SELECT 1 FROM pg_database WHERE datname = ?"
                 )) {
                ps.setString(1, database);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String foundUrl = buildJdbcUrl(host, port, database);
                        dbUrlField.setText(foundUrl);
                        dbStatusLabel.setText("Base " + database + " trouvee sur le port " + port + ".");
                        dbStatusLabel.setForeground(new Color(22, 163, 74));
                        setStatus("Port detecte : " + port, true);
                        return;
                    }
                }
            } catch (SQLException ignored) {
                // Le port ne repond pas, le mot de passe est refuse, ou le serveur n'est pas ce cluster.
            }
        }

        String message = "Base " + database + " non trouvee sur les ports 5432 a 5439 avec cet utilisateur.";
        dbStatusLabel.setText(message);
        dbStatusLabel.setForeground(RED);
        setStatus(message, false);
    }

    private String extractHost(String jdbcUrl) {
        int start = jdbcUrl.indexOf("//");
        if (start < 0) {
            return "localhost";
        }
        start += 2;
        int colon = jdbcUrl.indexOf(':', start);
        int slash = jdbcUrl.indexOf('/', start);
        if (colon > start) {
            return jdbcUrl.substring(start, colon);
        }
        if (slash > start) {
            return jdbcUrl.substring(start, slash);
        }
        return "localhost";
    }

    private String extractDatabaseName(String jdbcUrl) {
        int slash = jdbcUrl.lastIndexOf('/');
        if (slash < 0 || slash == jdbcUrl.length() - 1) {
            return "streamdb";
        }
        int query = jdbcUrl.indexOf('?', slash);
        if (query > slash) {
            return jdbcUrl.substring(slash + 1, query);
        }
        return jdbcUrl.substring(slash + 1);
    }

    private String buildJdbcUrl(String host, int port, String database) {
        return "jdbc:postgresql://" + host + ":" + port + "/" + database;
    }

    private String explainConnectionError(SQLException e) {
        String message = e.getMessage();
        if (message == null) {
            return "Connexion impossible : erreur inconnue.";
        }
        String lower = message.toLowerCase();
        if (lower.contains("password authentication failed")) {
            return "Mot de passe PostgreSQL incorrect pour l'utilisateur indique.";
        }
        if (lower.contains("connection refused") || lower.contains("connexion refuse")) {
            return "PostgreSQL ne repond pas sur ce port. Demarre le service ou mets le port de pgAdmin.";
        }
        if (lower.contains("database") && lower.contains("does not exist")) {
            return "La base streamdb n'existe pas sur ce port. Clique sur Trouver le bon port ou utilise SHOW port; dans pgAdmin.";
        }
        if (lower.contains("no suitable driver") || lower.contains("driver postgresql introuvable")) {
            return "Driver JDBC manquant dans Eclipse : ajoute lib/postgresql-42.7.11.jar au Build Path.";
        }
        return "Connexion impossible : " + message;
    }

    private void refreshDashboard() {
        try {
            animateStat("plans", scalar("SELECT COUNT(*) FROM Plan"));
            animateStat("comptes", scalar("SELECT COUNT(*) FROM Compte"));
            animateStat("profils", scalar("SELECT COUNT(*) FROM Profil"));
            animateStat("contenus", scalar("SELECT COUNT(*) FROM Contenu"));
            animateStat("films", scalar("SELECT COUNT(*) FROM Film"));
            animateStat("series", scalar("SELECT COUNT(*) FROM Serie"));
            animateStat("episodes", scalar("SELECT COUNT(*) FROM Episode"));
            animateStat("vues", scalar("SELECT (SELECT COUNT(*) FROM VisionnageFilm) + (SELECT COUNT(*) FROM Visionnage)"));
            loadResultSet(recentTable, """
                SELECT dateDebut AS date, profil, type, titre, progression
                FROM (
                    SELECT vf.dateDebut, pr.pseudo AS profil, 'film' AS type,
                           c.titre, vf.progression
                    FROM VisionnageFilm vf
                    JOIN Profil pr ON pr.idProfil = vf.idProfil
                    JOIN Contenu c ON c.idContenu = vf.idContenu
                    UNION ALL
                    SELECT v.dateDebut, pr.pseudo, 'episode',
                           c.titre || ' S' || s.numero || 'E' || e.numero || ' - ' || e.titre,
                           v.progression
                    FROM Visionnage v
                    JOIN Profil pr ON pr.idProfil = v.idProfil
                    JOIN Episode e ON e.idEpisode = v.idEpisode
                    JOIN Saison s ON s.idSaison = e.idSaison
                    JOIN Contenu c ON c.idContenu = s.idContenu
                ) x
                ORDER BY dateDebut DESC
                LIMIT 10
                """);
            setStatus("Connecte a PostgreSQL.", true);
        } catch (SQLException e) {
            clearStats();
            emptyTable(recentTable);
            String message = explainConnectionError(e);
            setStatus(message, false);
            if (dbStatusLabel != null) {
                dbStatusLabel.setText(message);
                dbStatusLabel.setForeground(RED);
            }
            cardLayout.show(cards, "connexion");
        }
    }

    private void refreshCatalogue() {
        try {
            String filter = (String) typeFilter.getSelectedItem();
            String keyword = searchField.getText().trim();
            StringBuilder sql = new StringBuilder("""
                SELECT c.idContenu AS id, c.type, c.titre, c.annee, py.nom AS pays,
                       COALESCE(STRING_AGG(DISTINCT g.libelle, ', ' ORDER BY g.libelle), '-') AS genres,
                       COALESCE(f.realisateur, s.createur || ' - ' || s.nbSaisons || ' saison(s)') AS details
                FROM Contenu c
                JOIN Pays py ON c.idPays = py.idPays
                LEFT JOIN ContenuGenre cg ON c.idContenu = cg.idContenu
                LEFT JOIN Genre g ON cg.idGenre = g.idGenre
                LEFT JOIN Film f ON c.idContenu = f.idContenu
                LEFT JOIN Serie s ON c.idContenu = s.idContenu
                WHERE 1=1
                """);
            if (!keyword.isEmpty()) {
                sql.append(" AND c.titre ILIKE ? ");
            }
            if ("Films".equals(filter)) {
                sql.append(" AND c.type = 'film' ");
            } else if ("Series".equals(filter)) {
                sql.append(" AND c.type = 'serie' ");
            }
            sql.append("""
                GROUP BY c.idContenu, c.type, c.titre, c.annee, py.nom,
                         f.realisateur, s.createur, s.nbSaisons
                ORDER BY c.type, c.titre
                """);
            if (keyword.isEmpty()) {
                loadResultSet(catalogueTable, sql.toString());
            } else {
                loadResultSet(catalogueTable, sql.toString(), "%" + keyword + "%");
            }
            setStatus("Catalogue actualise.", true);
        } catch (SQLException e) {
            emptyTable(catalogueTable);
            setStatus("Erreur catalogue : " + e.getMessage(), false);
        }
    }

    private void refreshPlans() {
        try {
            DefaultTableModel model = model(planTable);
            model.setRowCount(0);
            for (Plan p : planDAO.findAll()) {
                model.addRow(new Object[]{
                    p.getIdPlan(), p.getLibelle(), String.format("%.2f", p.getPrixMensuel()),
                    p.getQualiteMax(), p.getNbProfilsMax()
                });
            }
            refreshPlanChoices();
            setStatus("Plans actualises.", true);
        } catch (SQLException e) {
            emptyTable(planTable);
            setStatus("Erreur plans : " + e.getMessage(), false);
        }
    }

    private void refreshComptes() {
        try {
            refreshPlanChoices();
            DefaultTableModel model = model(compteTable);
            model.setRowCount(0);
            for (Compte compte : compteDAO.findAll()) {
                model.addRow(new Object[]{
                    compte.getIdCompte(), compte.getEmail(),
                    compte.getDateInscription(), compte.getLibellePlan()
                });
            }
            setStatus("Comptes actualises.", true);
        } catch (SQLException e) {
            emptyTable(compteTable);
            setStatus("Erreur comptes : " + e.getMessage(), false);
        }
    }

    private void refreshProfilScreen() {
        try {
            refreshAccountChoices();
            refreshProfileChoices();
            refreshProfilesForSelectedAccount();
            refreshProfileWorkspace();
            setStatus("Profils actualises.", true);
        } catch (SQLException e) {
            emptyTable(profilTable);
            emptyTable(historyTable);
            emptyTable(myListTable);
            setStatus("Erreur profils : " + e.getMessage(), false);
        }
    }

    private void refreshProfilesForSelectedAccount() {
        IdLabel account = (IdLabel) profileAccountCombo.getSelectedItem();
        DefaultTableModel model = model(profilTable);
        model.setRowCount(0);
        if (account == null) {
            return;
        }
        try {
            for (Profil p : profilDAO.findByCompte(account.id())) {
                model.addRow(new Object[]{p.getIdProfil(), p.getPseudo(), p.getAvatar(), p.getIdCompte()});
            }
        } catch (SQLException e) {
            setStatus("Erreur profils : " + e.getMessage(), false);
        }
    }

    private void refreshProfileWorkspace() {
        IdLabel profile = (IdLabel) historyProfileCombo.getSelectedItem();
        emptyTable(historyTable);
        emptyTable(myListTable);
        if (profile == null) {
            return;
        }
        try {
            DefaultTableModel h = model(historyTable);
            for (Visionnage v : visionnageDAO.findByProfil(profile.id())) {
                h.addRow(new Object[]{
                    v.getDateDebut(), v.getTypeCible(), v.getTitreAffiche(), v.progressionFormatted()
                });
            }
            DefaultTableModel list = model(myListTable);
            for (Contenu c : maListeDAO.findByProfil(profile.id())) {
                list.addRow(new Object[]{
                    c.getIdContenu(), c.getType(), c.getTitre(), c.getAnnee(), c.getGenres()
                });
            }
        } catch (SQLException e) {
            setStatus("Erreur espace profil : " + e.getMessage(), false);
        }
    }

    private void createPlan() {
        try {
            String libelle = planLabelField.getText().trim();
            double prix = Double.parseDouble(planPriceField.getText().trim().replace(',', '.'));
            int max = Integer.parseInt(planProfileMaxField.getText().trim());
            String qualite = (String) planQualityCombo.getSelectedItem();
            if (libelle.isEmpty()) {
                throw new IllegalArgumentException("Le libelle est obligatoire.");
            }
            planDAO.create(new Plan(0, libelle, prix, qualite, max));
            planLabelField.setText("");
            planPriceField.setText("");
            planProfileMaxField.setText("");
            refreshPlans();
            JOptionPane.showMessageDialog(this, "Plan ajoute avec succes.");
        } catch (Exception e) {
            alert("Impossible d'ajouter le plan", e);
        }
    }

    private void createCompte() {
        try {
            IdLabel plan = (IdLabel) accountPlanCombo.getSelectedItem();
            if (plan == null) {
                throw new IllegalArgumentException("Selectionnez un plan.");
            }
            String email = accountEmailField.getText().trim();
            String password = accountPasswordField.getText().trim();
            if (email.isEmpty()) {
                throw new IllegalArgumentException("L'email est obligatoire.");
            }
            if (password.isEmpty()) {
                password = "demo_password";
            }
            Compte compte = new Compte(0, email, password, LocalDate.now(), plan.id());
            compteDAO.create(compte);
            accountEmailField.setText("");
            accountPasswordField.setText("");
            refreshComptes();
            JOptionPane.showMessageDialog(this, "Compte cree avec succes.");
        } catch (Exception e) {
            alert("Impossible de creer le compte", e);
        }
    }

    private void createProfil() {
        try {
            IdLabel account = (IdLabel) profileAccountCombo.getSelectedItem();
            if (account == null) {
                throw new IllegalArgumentException("Selectionnez un compte.");
            }
            String pseudo = profilePseudoField.getText().trim();
            if (pseudo.isEmpty()) {
                throw new IllegalArgumentException("Le pseudo est obligatoire.");
            }
            int max = scalar("""
                SELECT p.nbProfilsMax
                FROM Compte c
                JOIN Plan p ON p.idPlan = c.idPlan
                WHERE c.idCompte = ?
                """, account.id());
            int id = profilDAO.create(new Profil(0, pseudo, profileAvatarField.getText().trim(), account.id()), max);
            if (id == -1) {
                throw new IllegalStateException("Limite de profils atteinte pour ce plan.");
            }
            profilePseudoField.setText("");
            profileAvatarField.setText("");
            refreshProfilScreen();
            JOptionPane.showMessageDialog(this, "Profil cree avec succes.");
        } catch (Exception e) {
            alert("Impossible de creer le profil", e);
        }
    }

    private void addSelectedContentToList() {
        try {
            IdLabel profile = (IdLabel) historyProfileCombo.getSelectedItem();
            if (profile == null) {
                throw new IllegalArgumentException("Selectionnez un profil.");
            }
            int idContenu = Integer.parseInt(myListContentIdField.getText().trim());
            maListeDAO.add(profile.id(), idContenu);
            refreshProfileWorkspace();
            JOptionPane.showMessageDialog(this, "Contenu ajoute a Ma Liste.");
        } catch (Exception e) {
            alert("Impossible d'ajouter a Ma Liste", e);
        }
    }

    private void removeSelectedContentFromList() {
        try {
            IdLabel profile = (IdLabel) historyProfileCombo.getSelectedItem();
            if (profile == null) {
                throw new IllegalArgumentException("Selectionnez un profil.");
            }
            int idContenu = Integer.parseInt(myListContentIdField.getText().trim());
            maListeDAO.remove(profile.id(), idContenu);
            refreshProfileWorkspace();
            JOptionPane.showMessageDialog(this, "Contenu retire de Ma Liste.");
        } catch (Exception e) {
            alert("Impossible de retirer de Ma Liste", e);
        }
    }

    private void runDemoQuery(String sql) {
        try {
            loadResultSet(demoTable, sql);
            setStatus("Requete executee.", true);
        } catch (SQLException e) {
            emptyTable(demoTable);
            setStatus("Erreur requete : " + e.getMessage(), false);
        }
    }

    private void refreshPlanChoices() throws SQLException {
        if (accountPlanCombo == null) {
            return;
        }
        DefaultComboBoxModel<IdLabel> model = new DefaultComboBoxModel<>();
        for (Plan p : planDAO.findAll()) {
            model.addElement(new IdLabel(p.getIdPlan(), p.getLibelle()));
        }
        accountPlanCombo.setModel(model);
    }

    private void refreshAccountChoices() throws SQLException {
        DefaultComboBoxModel<IdLabel> model = new DefaultComboBoxModel<>();
        for (Compte c : compteDAO.findAll()) {
            model.addElement(new IdLabel(c.getIdCompte(), c.getEmail()));
        }
        profileAccountCombo.setModel(model);
    }

    private void refreshProfileChoices() throws SQLException {
        DefaultComboBoxModel<IdLabel> model = new DefaultComboBoxModel<>();
        try (PreparedStatement ps = connection().prepareStatement("""
            SELECT pr.idProfil, pr.pseudo || ' - ' || c.email AS label
            FROM Profil pr
            JOIN Compte c ON c.idCompte = pr.idCompte
            ORDER BY pr.idProfil
            """);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                model.addElement(new IdLabel(rs.getInt(1), rs.getString(2)));
            }
        }
        historyProfileCombo.setModel(model);
    }

    private int scalar(String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = connection().prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }

    private void loadResultSet(JTable table, String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = connection().prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                DefaultTableModel model = new DefaultTableModel() {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false;
                    }
                };
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    model.addColumn(meta.getColumnLabel(i));
                }
                while (rs.next()) {
                    Object[] row = new Object[meta.getColumnCount()];
                    for (int i = 1; i <= meta.getColumnCount(); i++) {
                        row[i - 1] = rs.getObject(i);
                    }
                    model.addRow(row);
                }
                table.setModel(model);
                styleTable(table);
            }
        }
    }

    private Connection connection() throws SQLException {
        return DatabaseConnection.getConnection();
    }

    private void clearStats() {
        for (JLabel value : statValues.values()) {
            value.setText("-");
        }
    }

    private void animateStat(String key, int target) {
        JLabel label = statValues.get(key);
        if (label == null) {
            return;
        }
        Timer timer = new Timer(22, null);
        final int[] value = {0};
        int step = Math.max(1, target / 18);
        timer.addActionListener(e -> {
            value[0] += step;
            if (value[0] >= target) {
                label.setText(String.valueOf(target));
                timer.stop();
            } else {
                label.setText(String.valueOf(value[0]));
            }
        });
        timer.start();
    }

    private void emptyTable(JTable table) {
        if (table == null) {
            return;
        }
        model(table).setRowCount(0);
    }

    private JPanel page() {
        JPanel panel = new JPanel(new BorderLayout(0, 18));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(18, 0, 0, 0));
        return panel;
    }

    private JLabel heading(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 22));
        label.setForeground(TEXT);
        return label;
    }

    private JLabel sectionTitle(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label.setForeground(TEXT);
        label.setBorder(new EmptyBorder(0, 0, 10, 0));
        return label;
    }

    private void addStat(JPanel parent, String key, String label, Color accent) {
        JPanel card = new AnimatedStatCard(accent);
        card.setLayout(new BorderLayout());
        card.setBorder(new EmptyBorder(16, 16, 16, 16));
        JLabel value = new JLabel("-");
        value.setFont(new Font("Segoe UI", Font.BOLD, 34));
        value.setForeground(accent);
        JLabel name = new JLabel(label);
        name.setFont(new Font("Segoe UI", Font.BOLD, 14));
        name.setForeground(TEXT);
        card.add(value, BorderLayout.CENTER);
        card.add(name, BorderLayout.SOUTH);
        parent.add(card);
        statValues.put(key, value);
    }

    private JPanel cardPanel(java.awt.LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(PANEL);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(229, 231, 235)),
            new EmptyBorder(16, 16, 16, 16)
        ));
        return panel;
    }

    private JPanel wrappedTable(String title, JTable table) {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setOpaque(false);
        panel.add(sectionTitle(title), BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buttonBar(JButton button) {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bar.setOpaque(false);
        bar.add(button);
        return bar;
    }

    private JTable table(String... columns) {
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        styleTable(table);
        return table;
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.setGridColor(new Color(229, 231, 235));
        table.setShowVerticalLines(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setForeground(TEXT);
        table.setBackground(Color.WHITE);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 12));
        header.setForeground(new Color(55, 65, 81));
        header.setBackground(new Color(243, 244, 246));
        header.setPreferredSize(new Dimension(header.getWidth(), 34));

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setBorder(new EmptyBorder(0, 8, 0, 8));
        table.setDefaultRenderer(Object.class, renderer);
    }

    private JButton primaryButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(BLUE);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorder(new EmptyBorder(9, 14, 9, 14));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(29, 78, 216));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BLUE);
            }
        });
        return button;
    }

    private JButton secondaryButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(TEXT);
        button.setBackground(new Color(229, 231, 235));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorder(new EmptyBorder(9, 14, 9, 14));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(209, 213, 219));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(229, 231, 235));
            }
        });
        return button;
    }

    private GridBagConstraints gbc() {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 6, 5, 6);
        c.anchor = GridBagConstraints.WEST;
        return c;
    }

    private void addFormRow(JPanel form, GridBagConstraints c, int pairIndex, String label, Component field) {
        c.gridx = pairIndex * 2;
        c.gridy = 0;
        c.gridheight = 1;
        c.weightx = 0;
        form.add(new JLabel(label), c);
        c.gridx = pairIndex * 2 + 1;
        c.weightx = 1;
        form.add(field, c);
    }

    private void addWideFormRow(JPanel form, GridBagConstraints c, int row, String label, Component field) {
        c.gridx = 0;
        c.gridy = row;
        c.gridheight = 1;
        c.weightx = 0;
        c.insets = new Insets(8, 6, 8, 10);
        form.add(new JLabel(label), c);
        c.gridx = 1;
        c.weightx = 1;
        c.insets = new Insets(8, 6, 8, 6);
        form.add(field, c);
    }

    private DefaultTableModel model(JTable table) {
        return (DefaultTableModel) table.getModel();
    }

    private void setStatus(String message, boolean ok) {
        statusLabel.setText(message);
        statusLabel.setForeground(ok ? new Color(22, 163, 74) : RED);
    }

    private void alert(String title, Exception e) {
        setStatus(title + " : " + e.getMessage(), false);
        JOptionPane.showMessageDialog(this, e.getMessage(), title, JOptionPane.ERROR_MESSAGE);
    }

    private void configureLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Swing garde son look and feel par defaut.
        }
    }

    private class AnimatedBanner extends JPanel {
        private int phase = 0;

        AnimatedBanner() {
            setOpaque(false);
            Timer timer = new Timer(45, e -> {
                phase = (phase + 2) % 360;
                repaint();
            });
            timer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gradient = new GradientPaint(0, 0, new Color(15, 23, 42), w, h, new Color(37, 99, 235));
            g2.setPaint(gradient);
            g2.fillRoundRect(0, 0, w, h, 18, 18);

            for (int i = 0; i < 6; i++) {
                int x = (phase * (i + 1) + i * 145) % Math.max(1, w);
                int y = 20 + (i * 17) % Math.max(1, h - 30);
                g2.setColor(new Color(255, 255, 255, 30 + i * 12));
                g2.fillOval(x - 35, y, 70, 70);
            }

            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 27));
            g2.drawString("StreamDB se connecte a PostgreSQL", 28, 48);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
            g2.setColor(new Color(219, 234, 254));
            g2.drawString("Teste la base streamdb ici, puis ouvre le Dashboard quand la connexion est verte.", 30, 78);
            g2.setColor(new Color(34, 197, 94));
            g2.fillRoundRect(30, 96, 150 + (phase % 90), 8, 8, 8);
            g2.dispose();
        }
    }

    private class AnimatedStatCard extends JPanel {
        private final Color accent;
        private int glow = 0;

        AnimatedStatCard(Color accent) {
            this.accent = accent;
            setOpaque(false);
            Timer timer = new Timer(60, e -> {
                glow = (glow + 5) % 100;
                repaint();
            });
            timer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(PANEL);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
            int alpha = 25 + Math.abs(50 - glow);
            g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), Math.min(85, alpha)));
            g2.fillRoundRect(0, 0, getWidth() - 1, 5, 12, 12);
            g2.setColor(new Color(229, 231, 235));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private record IdLabel(int id, String label) {
        @Override
        public String toString() {
            return label + " (#" + id + ")";
        }
    }
}
