============================================================
STREAMDB - Projet de modelisation de base de donnees
Application Java + PostgreSQL + interface Swing
============================================================

1. CONTENU DU LIVRABLE
----------------------
src/                         Code source Java
sql/streamdb_pgadmin.sql      Script complet : DROP + CREATE TABLE + INSERT + verification
sql/demo_queries.sql          Requetes utiles pour la soutenance
rapport_streamdb.pdf          Rapport concis du projet
lib/README_DRIVER.txt         Indication pour ajouter le driver JDBC PostgreSQL

2. PREREQUIS
------------
- JDK 17 ou plus recent
- PostgreSQL
- pgAdmin
- Eclipse IDE for Java Developers
- Driver JDBC PostgreSQL : postgresql-42.7.11.jar

Lien driver officiel :
https://jdbc.postgresql.org/download/

3. PREPARER LA BASE DANS PGADMIN
--------------------------------
1) Ouvrir pgAdmin.
2) Creer une base nommee :
   streamdb
3) Clic droit sur la base streamdb > Query Tool.
4) Ouvrir le fichier :
   sql/streamdb_pgadmin.sql
5) Executer tout le script avec F5.
6) Verifier que le dernier SELECT affiche au moins 5 lignes par relation.

Remarque : le script remet les tables a zero avec DROP TABLE IF EXISTS.
Il est donc possible de le relancer proprement pendant les tests.

4. CONFIGURER LE MOT DE PASSE POSTGRESQL
----------------------------------------
Par defaut, l'application utilise :
URL      : jdbc:postgresql://localhost:5432/streamdb
USER     : postgres
PASSWORD : postgres

Si ton mot de passe est different, tu as deux options.

Option A - modifier dans Eclipse :
Ouvrir src/streamdb/util/DatabaseConnection.java et remplacer la valeur par defaut.

Option B - garder le code intact et utiliser des variables d'environnement :
STREAMDB_DB_URL=jdbc:postgresql://localhost:5432/streamdb
STREAMDB_DB_USER=postgres
STREAMDB_DB_PASSWORD=ton_mot_de_passe

5. IMPORTER DANS ECLIPSE
------------------------
1) Eclipse > File > Import.
2) General > Existing Projects into Workspace.
3) Selectionner le dossier StreamDB_Livrable_Final.
4) Cocher le projet StreamDB puis Finish.
5) Ajouter le driver JDBC :
   Clic droit sur le projet > Build Path > Configure Build Path
   > Libraries > Classpath > Add External JARs
   > choisir lib/postgresql-42.7.11.jar.
6) Lancer :
   Clic droit sur src/streamdb/Main.java
   > Run As > Java Application.

Par defaut, l'interface graphique Swing s'ouvre.
Elle commence maintenant par l'ecran "Connexion DB" :
- URL conseillee : jdbc:postgresql://localhost:5432/streamdb
- Utilisateur : postgres
- Mot de passe : ton mot de passe PostgreSQL

Clique sur "Tester et utiliser cette connexion". Si la connexion est verte,
le Dashboard s'ouvre et les donnees de PostgreSQL apparaissent.

Si l'application dit que la base streamdb n'existe pas alors qu'elle apparait
dans pgAdmin, c'est presque toujours un probleme de port. Lance dans pgAdmin :
SHOW port;
Puis remplace le port dans l'URL JDBC, par exemple :
jdbc:postgresql://localhost:5434/streamdb

Tu peux aussi cliquer sur "Trouver le bon port" dans l'application : elle
teste les ports PostgreSQL courants de 5432 a 5439.

Attention : pgAdmin n'est pas la base de donnees. pgAdmin est seulement
l'outil graphique qui permet de voir PostgreSQL. L'application se connecte
au serveur PostgreSQL et a la base nommee streamdb.

6. LANCER EN MODE CONSOLE
-------------------------
Dans Eclipse :
Run Configurations > Arguments > Program arguments :
--console

En ligne de commande Ubuntu :
javac -encoding UTF-8 -d bin $(find src -name "*.java")
java -cp "bin:lib/postgresql-42.7.11.jar" streamdb.Main

Mode console Ubuntu :
java -cp "bin:lib/postgresql-42.7.11.jar" streamdb.Main --console

7. SCENARIO DE DEMONSTRATION POUR LA VIDEO
------------------------------------------
Duree conseillee : 4 minutes.

1) Presenter le contexte :
   StreamDB est une plateforme VOD avec comptes, profils, films, series,
   saisons, episodes, genres, langues, visionnages et Ma Liste.

2) Dans pgAdmin :
   Executer sql/streamdb_pgadmin.sql.
   Montrer le SELECT final de verification des cardinalites.

3) Dans l'application :
   - Ouvrir l'interface Swing.
   - Montrer le Dashboard.
   - Aller dans Catalogue et rechercher "Inception" ou filtrer les series.
   - Aller dans Profils, charger un profil et montrer Historique + Ma Liste.
   - Aller dans Requetes demo et lancer "Contraintes ISA".

4) Conclure :
   Expliquer que les contraintes principales sont traduites par les PK, FK,
   UNIQUE, CHECK et par la decomposition Film/Serie, Saison/Episode.

8. CE QU'IL FAUT FOURNIR A LA PROF
----------------------------------
Archive ZIP contenant :
- src/
- sql/streamdb_pgadmin.sql
- sql/demo_queries.sql
- README.txt
- rapport_streamdb.pdf
- lien de la video YouTube ou plateforme equivalente

Le code source suffit pour la correction. Le dossier out/ ou bin/ n'est pas
obligatoire, car il peut etre regenere par Eclipse ou javac.
