package streamdb.util;

import java.util.Scanner;

/**
 * Utilitaire pour la lecture sécurisée des entrées console.
 */
public class ConsoleHelper {

    private static final Scanner scanner = new Scanner(System.in);

    public static String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    public static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("  ⚠  Veuillez entrer un nombre entier.");
            }
        }
    }

    public static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Double.parseDouble(line.replace(",", "."));
            } catch (NumberFormatException e) {
                System.out.println("  ⚠  Veuillez entrer un nombre décimal (ex: 13.99).");
            }
        }
    }

    public static boolean readBoolean(String prompt) {
        while (true) {
            System.out.print(prompt + " (o/n) : ");
            String line = scanner.nextLine().trim().toLowerCase();
            if (line.equals("o") || line.equals("oui") || line.equals("y") || line.equals("yes")) return true;
            if (line.equals("n") || line.equals("non") || line.equals("no")) return false;
            System.out.println("  ⚠  Répondez par 'o' (oui) ou 'n' (non).");
        }
    }

    public static void pause() {
        System.out.print("\n  Appuyez sur Entrée pour continuer...");
        scanner.nextLine();
    }

    public static void printSeparator() {
        System.out.println("  " + "─".repeat(60));
    }

    public static void printTitle(String title) {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════════════════════╗");
        System.out.printf ("  ║  %-56s  ║%n", title);
        System.out.println("  ╚══════════════════════════════════════════════════════════╝");
    }

    public static void printMenu(String title, String[] options) {
        System.out.println();
        System.out.println("  ┌─ " + title + " " + "─".repeat(Math.max(0, 54 - title.length())) + "┐");
        for (int i = 0; i < options.length; i++) {
            System.out.printf("  │  [%2d] %-52s │%n", i + 1, options[i]);
        }
        System.out.println("  │  [ 0] Retour / Quitter" + " ".repeat(38) + "│");
        System.out.println("  └" + "─".repeat(62) + "┘");
    }

    public static void ok(String msg)    { System.out.println("  ✔  " + msg); }
    public static void error(String msg) { System.out.println("  ✘  ERREUR : " + msg); }
    public static void info(String msg)  { System.out.println("  ℹ  " + msg); }
}
