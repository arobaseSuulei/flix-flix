package streamdb.model;

public class Plan {
    private int    idPlan;
    private String libelle;
    private double prixMensuel;
    private String qualiteMax;
    private int    nbProfilsMax;

    public Plan() {}

    public Plan(int idPlan, String libelle, double prixMensuel, String qualiteMax, int nbProfilsMax) {
        this.idPlan       = idPlan;
        this.libelle      = libelle;
        this.prixMensuel  = prixMensuel;
        this.qualiteMax   = qualiteMax;
        this.nbProfilsMax = nbProfilsMax;
    }

    // ── Getters / Setters ──────────────────────────────────────
    public int    getIdPlan()       { return idPlan; }
    public String getLibelle()      { return libelle; }
    public double getPrixMensuel()  { return prixMensuel; }
    public String getQualiteMax()   { return qualiteMax; }
    public int    getNbProfilsMax() { return nbProfilsMax; }

    public void setIdPlan(int idPlan)             { this.idPlan = idPlan; }
    public void setLibelle(String libelle)         { this.libelle = libelle; }
    public void setPrixMensuel(double prixMensuel) { this.prixMensuel = prixMensuel; }
    public void setQualiteMax(String qualiteMax)   { this.qualiteMax = qualiteMax; }
    public void setNbProfilsMax(int nbProfilsMax)  { this.nbProfilsMax = nbProfilsMax; }

    @Override
    public String toString() {
        return String.format("[%d] %-12s | %.2f €/mois | Qualité : %-4s | Max profils : %d",
                idPlan, libelle, prixMensuel, qualiteMax, nbProfilsMax);
    }
}
