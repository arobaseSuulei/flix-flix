package streamdb.model;

public class Contenu {
    private int    idContenu;
    private String titre;
    private int    annee;
    private Integer duree;   // null pour les séries
    private int    idPays;
    private String type;     // "film" ou "serie"
    private String nomPays;  // enrichi par jointure
    private String genres;   // enrichi par jointure (liste séparée par virgules)

    // Champs spécifiques Film
    private String realisateur;

    // Champs spécifiques Série
    private String createur;
    private Integer nbSaisons;

    public Contenu() {}

    // ── Getters / Setters ──────────────────────────────────────
    public int     getIdContenu()   { return idContenu; }
    public String  getTitre()       { return titre; }
    public int     getAnnee()       { return annee; }
    public Integer getDuree()       { return duree; }
    public int     getIdPays()      { return idPays; }
    public String  getType()        { return type; }
    public String  getNomPays()     { return nomPays; }
    public String  getGenres()      { return genres; }
    public String  getRealisateur() { return realisateur; }
    public String  getCreateur()    { return createur; }
    public Integer getNbSaisons()   { return nbSaisons; }

    public void setIdContenu(int v)      { this.idContenu = v; }
    public void setTitre(String v)       { this.titre = v; }
    public void setAnnee(int v)          { this.annee = v; }
    public void setDuree(Integer v)      { this.duree = v; }
    public void setIdPays(int v)         { this.idPays = v; }
    public void setType(String v)        { this.type = v; }
    public void setNomPays(String v)     { this.nomPays = v; }
    public void setGenres(String v)      { this.genres = v; }
    public void setRealisateur(String v) { this.realisateur = v; }
    public void setCreateur(String v)    { this.createur = v; }
    public void setNbSaisons(Integer v)  { this.nbSaisons = v; }

    @Override
    public String toString() {
        String typeLabel = "film".equals(type) ? "🎬 Film " : "📺 Série";
        String extra = "film".equals(type)
            ? "Réal. : " + (realisateur != null ? realisateur : "?") + " | " + (duree != null ? duree + " min" : "")
            : "Créateur : " + (createur != null ? createur : "?") + " | " + (nbSaisons != null ? nbSaisons + " saison(s)" : "");
        return String.format("[%3d] %s %-40s (%d) | %s | %s | Genres : %s",
                idContenu, typeLabel, titre, annee,
                nomPays != null ? nomPays : "?",
                extra,
                genres != null ? genres : "?");
    }
}
