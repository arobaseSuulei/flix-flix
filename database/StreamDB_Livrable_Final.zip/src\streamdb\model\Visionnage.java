package streamdb.model;

import java.time.LocalDateTime;

public class Visionnage {
    private int            idProfil;
    private int            idCible;      // idEpisode ou idContenu(film)
    private LocalDateTime  dateDebut;
    private int            progression;  // en secondes
    private String         typeCible;    // "episode" ou "film"
    private String         titreAffiche; // enrichi

    public Visionnage() {}

    public int           getIdProfil()    { return idProfil; }
    public int           getIdCible()     { return idCible; }
    public LocalDateTime getDateDebut()   { return dateDebut; }
    public int           getProgression() { return progression; }
    public String        getTypeCible()   { return typeCible; }
    public String        getTitreAffiche(){ return titreAffiche; }

    public void setIdProfil(int v)           { this.idProfil = v; }
    public void setIdCible(int v)            { this.idCible = v; }
    public void setDateDebut(LocalDateTime v){ this.dateDebut = v; }
    public void setProgression(int v)        { this.progression = v; }
    public void setTypeCible(String v)       { this.typeCible = v; }
    public void setTitreAffiche(String v)    { this.titreAffiche = v; }

    /** Convertit les secondes en HH:MM:SS */
    public String progressionFormatted() {
        int h = progression / 3600;
        int m = (progression % 3600) / 60;
        int s = progression % 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    @Override
    public String toString() {
        return String.format("%-8s | %-45s | %s | Progression : %s",
                typeCible, titreAffiche != null ? titreAffiche : "?",
                dateDebut != null ? dateDebut.toLocalDate() : "?",
                progressionFormatted());
    }
}
