package streamdb.dao;

import streamdb.model.Profil;
import streamdb.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProfilDAO {

    public List<Profil> findByCompte(int idCompte) throws SQLException {
        List<Profil> list = new ArrayList<>();
        String sql = "SELECT idProfil, pseudo, avatar, idCompte FROM Profil WHERE idCompte = ? ORDER BY idProfil";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idCompte);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public Profil findById(int id) throws SQLException {
        String sql = "SELECT idProfil, pseudo, avatar, idCompte FROM Profil WHERE idProfil = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    /**
     * Création avec vérification de la contrainte C3 :
     * un compte ne peut pas dépasser nbProfilsMax profils.
     * Retourne -1 si la limite est atteinte, sinon l'id généré.
     */
    public int create(Profil p, int nbProfilsMax) throws SQLException {
        // Vérification contrainte C3
        String countSql = "SELECT COUNT(*) FROM Profil WHERE idCompte = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(countSql)) {
            ps.setInt(1, p.getIdCompte());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && rs.getInt(1) >= nbProfilsMax) return -1;
            }
        }
        String sql = "INSERT INTO Profil (pseudo, avatar, idCompte) VALUES (?, ?, ?) RETURNING idProfil";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, p.getPseudo());
            ps.setString(2, p.getAvatar());
            ps.setInt(3, p.getIdCompte());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    public boolean update(Profil p) throws SQLException {
        String sql = "UPDATE Profil SET pseudo=?, avatar=? WHERE idProfil=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, p.getPseudo());
            ps.setString(2, p.getAvatar());
            ps.setInt(3, p.getIdProfil());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM Profil WHERE idProfil = ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Profil map(ResultSet rs) throws SQLException {
        return new Profil(
            rs.getInt("idProfil"),
            rs.getString("pseudo"),
            rs.getString("avatar"),
            rs.getInt("idCompte")
        );
    }
}
